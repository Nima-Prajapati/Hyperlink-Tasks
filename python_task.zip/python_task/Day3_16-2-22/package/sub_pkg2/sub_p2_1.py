# Python task (16 Feb, 2022)
import package.sub_pkg1.sub_p1_1

print("Import : ",package.sub_pkg1.sub_p1_1.add(2,3))

from package.sub_pkg1.sub_p1_1 import *
print("From : ",add(2,3))
print("Multiplication : ",mul(2,3))

S1=Student()
S1.getStudentDetails()
print("Result : ")
S1.printResult()
