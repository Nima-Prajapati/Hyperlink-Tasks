# Python task (16 Feb, 2022)
#
# Task 1:
#
# - Global Keyword
# - Module
# - Package

#Global Keyword
def add():
	a = 10
	def fun2():
		global a
		a = 20

	print("a = ",a) #10
	fun2()
	print("a = ",a) #10

add()
print("a = ",a) #20

#Global Keyword
x = 15
def change():
	# using a global keyword
	global x
	# increment value of a by 5
	x = x + 5
	print("Value of x inside a function :", x) #20
change()
print("Value of x outside a function :", x) #20


# import con
from con import *
a = add(10,20)
print("Addition of 10 and 20 is :",a)

import math
print("Import pi from math is :",math.pi)

from math import pi,e
print("import pi :",pi)
print("import e : ",e)

import sys
print(sys.path)

# import imp
# imp.reload(math)

import con
#Creating objects
emp = con.Employee("Reshma", "Developer")
emp.show()

con.fib(100)

std = con.getStudentDetails()


x=1
y=1
def function1(x,y):
	x = globals()['x']+x     #globals() is use for acccess global value with same var name
	print(x)

function1(50,50)


















# Using globals() to access global variables inside the function
# total = 100
# def func3():
#     listOfGlobals = globals()
#     listOfGlobals['total'] = 15
#     total = 22
#     print('Local Total = ', total)
# print('Total = ', total)
# func3()
# print('Total = ', total)
# op:Total =  15
# Local Total =  22
# Total =  11














