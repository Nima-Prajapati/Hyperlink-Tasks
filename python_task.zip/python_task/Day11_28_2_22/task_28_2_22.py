"""
Today's python task (28 Feb, 2022):

Python OOPs concept

Task 1: Class - Objects
Task 2: Inheritance
Task 3: Encapsulation
Task 4: Polymorphism
"""

# Task 1: Class - Objects
"""
class is collection of data member,member function,constructor etc.class is blue print
object is instance of class
"""
class Person:
    # class attribute
    name = 'abc'
    age = 20

    # instance attribute
    def __init__(self,gender):
        print("Init called")
        print("Hello")
        self.gender = gender

    # instance method
    def study(self,standered):
        return f"{self.name} study in {standered}"

obj1 = Person('Female')

print('{}'.format(obj1.gender))
print(f"Name and Age are : {obj1.name,obj1.age}")
print('{} - {}'.format(obj1.name, obj1.age))
print(f"Name is : {obj1.__class__.name}")
print(obj1.study(12))
print(Person.age)
print("-"*50)
# op:Init called
# Hello
# Female
# Name and Age are : ('abc', 20)
# abc - 20
# Name is : abc
# abc study in 12
# 20


# Task 2: Inheritance
"""
It's provide reusability of code,Child class (extends) access 
"""
# # Parent class
# class Person(object):
#     # Constructor
#     def __init__(self, name):
#         self.name = name
#
#     # To get name
#     def getName(self):
#         return self.name
#
#     # To check if this person is an employee
#     def isEmployee(self):
#         print("Parent isEmployee..")
#         # return False
#
# # Inherited or Subclass (Note Person in bracket)
# class Employee(Person):
#
#     # Here we return true
#     def isEmployee(self):
#         print("child isEmployee...")
#         return True
#
# # Driver code
# emp = Person("abc")  # An Object of Person
# print(emp.getName(), emp.isEmployee())
# emp = Employee("abc2")  # An Object of Employee
# print(emp.getName(), emp.isEmployee())


# print('-'*100)
print("--------Inharitance------------")
print('-'*50)

class price:
    def rs(self,rupee,name):
        print(name,"car have this price ",rupee)

class cars:
    def engine(self,name):
        print("This car",name, "have engine")

    def color(self,colors):
        print("This car hav",colors)

class audi(cars,price):
    def name(self):

        print("My name is audi")

class bmw(cars,price):
    def name(self):
         print("my name is bmw")

abij=audi()
abij.engine("audi")
abij.color("red")
abij.rs(50000,'audi')

print("-"*50)

bobj=bmw()
bobj.engine("BMW")
bobj.color("black")
bobj.rs(100000,"BMW")
print("-"*50)
# op:This car audi have engine
# This car hav red
# audi car have this price  50000
# --------------------------------------------------
# This car BMW have engine
# This car hav black
# BMW car have this price  100000


# Task 3: Encapsulation
# -------------------------------ENCAPSULATION--------------------------------------
# class Employee:
#   def __init__(self, name, salary):
#     # public data member
#     self.name = name
#     # private member
#     self.__salary = salary
#
#
# # creating object of a class
# emp = Employee('Jessa', 10000)
#
# # accessing private data members
# print('Salary:', emp.__salary)
# # AttributeError: 'Employee' object has no attribute '__salary'

class Employee:
  def __init__(self, name, salary):
    # public data member
    self.name = name
    # private member
    self.__salary = salary

  # public instance methods
  def show(self):
    # private members are accessible from a class
    print("Name: ", self.name, '\nSalary:', self.__salary)

emp = Employee('joey', 10000)
emp.show()
print("-"*50)
# op:Name:  joey
# Salary: 10000


class Employee:
  # constructor
  def __init__(self, name, salary):
    self.name = name
    self.__salary = salary

# creating object of a class
emp = Employee('monica', 10000)

print('Name:', emp.name)
# direct access to private member using name mangling
print('Salary:', emp._Employee__salary)
print("-"*50)
# op:Name: monica
# Salary: 10000


# base class
class Company:
    def __init__(self):
        # Protected member
        self._project = "NLP"

# child class
class Employee(Company):
    def __init__(self, name):
        self.name = name
        Company.__init__(self)

    def show(self):
        print("Employee name :", self.name)
        # Accessing protected member in child class
        print("Working on project :", self._project)
c = Employee("joey")
c.show()
# Direct access protected data member
print('Project:', c._project)
# op:Employee name : joey
# Working on project : NLP
# Project: NLP


# ---------------------POLYMORPHISM-----------------------

def add(x, y, z = 0):
	return x + y + z
print(add(2, 3))
print(add(2, 3, 4))
print("-"*50)
# op:5
# 9


class Bird:
    def intro(self):
        print("There are many types of birds.")

    def flight(self):
        print("Most of the birds can fly but some cannot.")


class sparrow(Bird):
    def flight(self):
        print("Sparrows can fly.")


class ostrich(Bird):
    def flight(self):
        print("Ostriches cannot fly.")


obj_bird = Bird()
obj_spr = sparrow()
obj_ost = ostrich()

obj_bird.intro()
obj_bird.flight()

obj_spr.intro()
obj_spr.flight()

obj_ost.intro()
obj_ost.flight()

# op:There are many types of birds.
# Most of the birds can fly but some cannot.
# There are many types of birds.
# Sparrows can fly.
# There are many types of birds.
# Ostriches cannot fly.


# class India():
# 	def capital(self):
# 		print("New Delhi is the capital of India.")
#
# 	def language(self):
# 		print("Hindi is the most widely spoken language of India.")
#
# 	def type(self):
# 		print("India is a developing country.")
#
# class USA():
# 	def capital(self):
# 		print("Washington, D.C. is the capital of USA.")
#
# 	def language(self):
# 		print("English is the primary language of USA.")
#
# 	def type(self):
# 		print("USA is a developed country.")
#
# obj_ind = India()
# obj_usa = USA()
# for country in (obj_ind, obj_usa):
# 	country.capital()
# 	country.language()
# 	country.type()