import csv,operator
id = 0
sub_c=6
sub_n=7
up_sub_c=6
up_sub_n=7
count=0
#student=[{}]
student=[]
subject=[]


def savefile(student):
    header = ['id', 'Roll no', 'Name', 'Gender', 'Age', 'department', 'semester', 'subjects']
    s_file = open("sample.csv", "w")
    writer = csv.writer(s_file)
    writer.writerow(header)
    writer.writerows(student)
    print("Single data write successfully...")
    s_file.close()


def cases(num):

    if num==0:
        exit()
    match num:
        case 1:
            f = open('sample.csv', 'r')
            reader = csv.reader(f)

            global id, d
            id = id + 1
            print(id)
            # id = int(input("enter the id:"))
            name = input("enter the student name:")
            rollno = input("enter the student rollno:")

            for row in reader:
                if len(row)!=0:
                    if row[1]==rollno:
                        print('#'*50)
                        print("this roll no ",rollno,"is already used please enter unique")
                        print('#' * 50)
                        choicefuc()
                        break

            gender = input("enter the student gender:")
            age = input("enter the student age:")
            department = input("enter the studnet depart:")
            sem = input("enter the student semester:")
            sub_count = int(input("enter the subject you want to add:"))
            data = [
                id, rollno, name, gender, age, department,
                sem]

            for i in range(sub_count):
                sub_code = input("subject code")
                sub_name = input("subject name:")
                d = [sub_code,sub_name]
                data.append(d)

            student.append(data)
            header = ['id', 'Roll no', 'Name', 'Gender', 'Age', 'department', 'semester','subjects']
            s_file = open("sample.csv", "w")
            writer = csv.writer(s_file)
            writer.writerow(header)
            writer.writerows(student)
            print("Single data write successfully...")
            s_file.close()
            # updatelist=[]
            # for index, value in enumerate(student[0][7]):
            #     updatelist.append(value)
            # print(updatelist[0])
            choicefuc()

        case 2:

                f = open('sample.csv', 'r')
                reader = csv.reader(f)
                # headers = next(reader, None)
                # print(headers)
                data1 = [row for row in reader]
                for p in data1:
                    print("#"*50)
                    print(p)


                choicefuc()



        case 3:

            print("1.serach by name")
            print("2.serach by rollno")
            print("3.sercah by department")
            print("0.exit")
            serach=int(input("enter yor choice for search :"))
            if serach>3:
                print("pelease enter the 1 to 3 number")
                choicefuc()
            else:

                match serach:
                    case 0:
                        choicefuc()
                    case 1:
                        names=input("enter the name")
                        f = open('sample.csv', 'r')
                        reader = csv.reader(f)

                        for row in reader:
                            rang=len(row)
                            c=rang-1
                            #print('forloop')
                            if row[2]==names:
                                cou=-1
                                for i in range(int(c)):
                                    cou=cou+1
                                    print(row[cou],end='   ')
                                choicefuc()
                    case 2:
                        rollno = input("enter the rollno")
                        f = open('sample.csv', 'r')
                        reader = csv.reader(f)

                        for row in reader:
                            rang = len(row)
                            c = rang - 1
                            # print('forloop')
                            if row[1] == rollno:
                                cou = -1
                                for i in range(int(rang)):
                                    cou = cou + 1
                                    print(row[cou], end='   ')
                                choicefuc()
                    case 3:
                        depart = input("enter the department")
                        f = open('sample.csv', 'r')
                        reader = csv.reader(f)

                        # for row in reader:
                        #     for row[5] in row:
                        #         if row[5]==depart:
                        #             print("roll :",row[1])
                        for row in reader:
                            rang = len(row)
                            c = rang - 1
                            # print('forloop')
                            if row[5] == depart:
                                cou = -1
                                data1=[]
                                for i in range(int(rang)):
                                    cou = cou + 1
                                    data1.append(row[cou])

                                print(data1)
                                choicefuc()


        case 4:
            if len(student)==0:
                print("no data found")
                choicefuc()
            else:
                f = open('sample.csv', 'r')
                reader = csv.reader(f)
                print("--- Delete Student ---")
                roll = input("Enter roll no. to delete: ")
                for row in reader:
                    if roll in row[1]:

                        student_found = False
                        updated_data = []
                        with open('sample.csv', "r", encoding="utf-8") as f:
                            reader = csv.reader(f)
                            counter = 0
                            for row in reader:
                                if len(row) > 0:
                                    if roll != row[0]:
                                        updated_data.append(row)
                                        counter += 1
                                    else:
                                        student_found = True

                            if student_found is True:
                                with open('sample.csv', "w", encoding="utf-8") as f:
                                    writer = csv.writer(f)
                                    writer.writerows(updated_data)
                                print("Roll no. ", roll, "deleted successfully")
                            else:
                                print("student not found")

                        choicefuc()
                    else:
                        print("roll no not found")
                        choicefuc()

        case 5:
            roll_id=input("enter the roll no:")
            print(roll_id)
            f = open('sample.csv', 'r')
            reader = csv.reader(f)

            for roll in student:

                print("1.update name")
                print("2.update age")
                print("3.update gender")
                print("4.update department")
                print("5.update semester")
                print("6.update subject info")


                ch=int(input("enter the "))

                match ch:
                        case 1:
                            print(student)
                            up_name=input('enter the updated name')
                            for i in student:
                                if i[1]==roll_id:
                                    i[2]=up_name
                                    print("updated")
                                    savefile(student)

                            choicefuc()
                        case 2:
                            up_gender=input('enter the updated gender')
                            for i in student:
                                if i[1] == roll_id:
                                    i[3] = up_gender
                                    print("updated")
                                    savefile(student)

                        case 3:
                            try:
                                up_age = int(input('enter the updated age'))
                                for i in student:
                                    if i[1] == roll_id:
                                        i[4] = up_age
                                        print("updated")
                                        savefile(student)
                                        choicefuc()
                            except:
                                print("#"*40)
                                print("please enter the numeric value")
                                print("#"*40)
                                choicefuc()
                        case 4:
                            up_depart = input('enter the updated department')
                            for i in student:
                                if i[1] == roll_id:
                                        i[5] = up_depart
                                        print("updated")
                                        savefile(student)
                                        choicefuc()
                        case 5:
                            up_sem = input('enter the updated sem')
                            for i in student:
                                if i[1] == roll_id:
                                    i[6] = up_sem
                                    print("updated")
                                    savefile(student)
                                    choicefuc()
                        case 6:
                            updatelist = []

                            roll_id = input("enter you want update which id subject")

                            for row in student:
                                if row[1]==roll_id:
                                    #import pdb;pdb.set_trace()
                                    for i,v in enumerate(row):
                                        if i>6:
                                            updatelist.append(v)
                                    c=0
                                    for indx,vale in enumerate(updatelist):
                                        c=c+1
                                        print(c,vale)
                                    choice=int(input("enter your choice"))
                                    if choice<= len(updatelist) and choice!=0:

                                        if choice==1:
                                            up_sub_code = input("enter the you want update code:")
                                            up_sub_name = input("enter the updated subject name :")
                                            updatelist[0][0] = up_sub_code
                                            updatelist[0][1] = up_sub_name
                                        if choice==2:
                                            up_sub_code = input("enter the you want update code:")
                                            up_sub_name = input("enter the updated subject name :")
                                            updatelist[1][0] = up_sub_code
                                            updatelist[1][1] = up_sub_name
                                        if choice==3:
                                            up_sub_code = input("enter the you want update code:")
                                            up_sub_name = input("enter the updated subject name :")
                                            updatelist[2][0] = up_sub_code
                                            updatelist[2][1] = up_sub_name
                                        if choice==4:
                                            up_sub_code = input("enter the you want update code:")
                                            up_sub_name = input("enter the updated subject name :")
                                            updatelist[3][0] = up_sub_code
                                            updatelist[3][1] = up_sub_name
                                        if choice==5:
                                            up_sub_code = input("enter the you want update code:")
                                            up_sub_name = input("enter the updated subject name :")
                                            updatelist[4][0] = up_sub_code
                                            updatelist[4][1] = up_sub_name
                                    else:
                                        print("#"*50)
                                        print("you have only",len(updatelist),"subject please enter valid choice")
                                        print("#" * 50)
                                        choicefuc()

                                    print(updatelist)
                                    savefile(student)
                                    choicefuc()

                            else:
                                print("roll not found")






        case 6:
                    print("1.sort by roll no")
                    print("2.sort by name")
                    print("3.sort by department")
                    print("0.exit")
                    n=int(input("enter sort choice"))
                    match n:
                        case 0:
                            choicefuc()
                        case 1:
                            data = csv.reader(open('sample.csv'), delimiter=',')
                            head=next(data)
                            # sort data on the basis of age
                            dat = sorted(data, key=operator.itemgetter(1))
                            for i in dat:
                                print(i)
                            print('After sorting:')

                            choicefuc()
                        case 2:
                            data = csv.reader(open('sample.csv'), delimiter=',')
                            head = next(data)

                            # sort data on the basis of age
                            data1 = sorted(data, key=operator.itemgetter(2))

                            # displaying sorted data
                            print('After sorting:')
                            print(data1)
                        case 3:
                            data = csv.reader(open('sample.csv'), delimiter=',')
                            head = next(data)

                            # sort data on the basis of age
                            data2 = sorted(data, key=operator.itemgetter(2))

                            # displaying sorted data
                            print('After sorting:')
                            print(data2)
        case 0:
            exit()



def choicefuc():

    print("menu choice for calculation")
    print("1,Display all student list")
    print("2,Add student detail")
    print("3,Search student by rollno")
    print("4.Delete student detail")
    print("5.Update student detail")
    print("6.Sorting (Rollno, Name, department, semester, Age)")
    print("0.exit")
    try:
        choice = int(input("enter the your choice"))
        if choice<=6:
            cases(choice)


        else:
                print("#"*40)
                print("please enter the correct no")
                print("#" * 40)
                choicefuc()

    except ValueError:
        print("#"*40)
        print("enter the num of list")
        print("#"*40)
        choicefuc()


choicefuc()



