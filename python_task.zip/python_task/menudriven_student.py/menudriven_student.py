"""
python task (23 Feb, 2022):

Menu Driven task
----------------------------------------------
Task 3: Build a simple Student Management System
    - Display all student list
    - Add student detail (Rollno, Name, Gender, Age, department, semester, subjects)
        a. subjects : subject_code and subject_name
    - Search student by rollno, name, department
    - Delete student detail
    - Update student detail
    - Sorting (Rollno, Name, department, semester, Age)
"""

# # student={1:['Reshma','female',22,'it','4',1,'ss',]}
# from pythonpracticeProject.ex_exception import ValueTooLargeError

# student=[{"roll_no", "name", "gender", "age", "department", "semester", "subject":{"sub_code":11,"sub_name":"dbms"}}]
student={}
subject={}
details={}
class Error(Exception):
    pass

class DigitError(Error):
    """Base class for other exceptions"""
    pass
# class ValueTooSmallError(Error):
#     """Raised when the input value is too small"""
#     pass

def cases(num):
    try:
        if num == 0:
            print("Thank you...")
            exit()
        else:
            match num:
                case 1:
                    if len(student)==0:
                        print("No data found")
                        choiceFunction()
                    else:
                        print("Display all student list")
                        print("#" * 50)
                        print(student)
                        # for i in student:
                        #     for j in i.items():
                        #         print(j)
                        print("#" * 50)
                    choiceFunction()
                case 2:
                    id=input('enter teh id:')
                    name=input("Enter the student name:")
                    rollno=input("Enter the student rollno:")
                    # for roll in student.keys():
                    #     if roll==rollno:
                    #         print("Please enter different roll number")
                    #         choiceFunction()
                    gender=input("Enter the student gender:")
                    age=int(input("Enter the student age:"))
                    department=input("Enter the studnet depart:")
                    sem=input("Enter the student semester:")
                    cnt = int(input("enter How many subjects you want to add : "))
                    sub_count = int(input("enter the subject you want to add:"))
                    details = {id: [rollno, name, gender, age, department, sem]}
                    for i in range(sub_count):
                        sub_name = input("subject name:")
                        sub_code = input("subject code")
                        subject = {sub_code: sub_name}
                        details.update(subject)
                    student.update(details)
                    choiceFunction()
                case 3:
                    print("#" * 50)
                    print("1.Search by rollno")
                    print("2.Search by name")
                    print("3.Search by department")
                    print("0.Exit")
                    print("#" * 50)
                    c = input("Enter yor choice for search :")
                    if c == 0:
                        exit()
                    else:
                        match c:
                            case 1:
                                name = input("Enter the name for find")
                                for key, val in student.items():
                                    if val[0] == name:
                                        print("#" * 40)
                                        print(student[key])
                                        print("#" * 40)
                                        choiceFunction()
                            case 2:
                                find_roll = input("Enter rollno:")
                                if find_roll in student:
                                    print("#" * 50)
                                    print(student[find_roll])
                                    print("#" * 50)
                                    choiceFunction()
                                else:
                                    print("roll no not found")
                                    choiceFunction()
                            case 3:
                                depart = input("Enter department for find")
                                for key, val in student.items():
                                    if val[3] == depart:
                                        print("#" * 40)
                                        print(student[key])
                                        print("#" * 40)
                                        choiceFunction()
                    choiceFunction()
                case 4:
                    del_roll=input("Enter roll no")
                    if del_roll in student:
                        student.pop(del_roll)
                        print("#" * 50)
                        print("student deleted")
                        print("#" * 50)
                    else:
                        print("roll no not found")
                    choiceFunction()

                case 5:
                    update_roll=input("enter the roll no:")
                    if update_roll in student:
                        print("#" * 50)
                        print("1.update name")
                        print("2.update age")
                        print("3.update age")
                        print("4.update department")
                        print("5.update semester")
                        print("6.update subject code")
                        print("7.update subject name")
                        print("#" * 50)

                        ch=int(input("Enter: "))
                        match ch:
                            case 1:
                                up_name=input('Enter the updated name')
                                student[update_roll][0]=up_name
                                print("#" * 50)
                                print("student name update")
                                print("#" * 50)
                                choiceFunction()
                            case 2:
                                up_gender=input('Enter the updated gender')
                                student[update_roll][1]=up_gender
                                print("#" * 50)
                                print("student gender updated")
                                print("#" * 50)
                                choiceFunction()

                            case 3:
                                try:
                                    up_age = int(input('enter the updated age'))
                                    student[update_roll][2] = up_age
                                    print("#" * 50)
                                    print("student age update")
                                    print("#" * 50)
                                    choiceFunction()
                                except:
                                    print("#"*40)
                                    print("please enter the numeric value")
                                    print("#"*40)
                                    choiceFunction()
                            case 4:
                                up_depart = input('enter the updated department')
                                student[update_roll][3] = up_depart
                                print("#" * 50)
                                print("student department update")
                                print("#" * 50)
                                choiceFunction()
                            case 5:
                                up_sem = input('enter the updated sem')
                                student[update_roll][4] = up_sem
                                print("#" * 50)
                                print("student semester update")
                                print("#" * 50)
                                choiceFunction()
                            case 6:
                                up_sub_code = input('enter the updated subject code')
                                student[update_roll][5] = up_sub_code
                                print("#" * 50)
                                print("student subject code update")
                                print("#" * 50)
                                choiceFunction()
                            case 7:
                                up_sub_name = input('enter the updated subject name')
                                student[update_roll][6] = up_sub_name
                                print("#" * 50)
                                print("student subject name update")
                                print("#" * 50)
                                choiceFunction()
                    else:
                        print("roll no not found")
                        choiceFunction()
                case 6:
                    print("#" * 50)
                    print("1.Sort by roll no")
                    print("2.Sort by name")
                    print("3.sort by department")
                    print("0.Exit")
                    print("#" * 50)
                    n=input("Enter sort choices : ")
                    if n == 0:
                        exit()
                    else:
                        match n:
                            case 1:
                                for i in sorted(student.keys()):
                                    print(student[i])
                                # print(sorted(student,key=itemgetter("roll_no")))
                            case 2:
                                for i in sorted(student.values()[0]):
                                    pass
                    choiceFunction()
    except ValueError:
        print("Please enter only numeric for last except")
        print("#"*50)
    except ImportError:
        print("Import module properly")
    except IndexError:
        print("list index out of range")
        print()



def choiceFunction():
    print("#" * 50)
    print("Welcome to Student Management System")
    print("#" * 50)
    print("1.Display all student list")
    print("2.Add student detail")
    print("3.Search student by rollno")
    print("4.Delete student detail")
    print("5.Update student detail")
    print("6.Sorting (Rollno, Name, department, semester, Age)")
    print("0.Exit")
    print("#" * 50)
    try:
        choice = int(input("Enter your choice:"))
        cases(choice)
    except ValueError:
        print("#"*40)
        print("Enter the number only for choice")
        print("#"*40)
        choiceFunction()

choiceFunction()




# var my_name
# def studentDetails
# class Student



# import math
# student_list = [{
#     "rollno":1,
#     "name":""
# }]
# # creating options
# while True:
#     print("\nSTUDENT MENU")
#     print("1. Display all student list")
#     print("2. Add student detail")
#     print("3. Search student by rollno, name, department")
#     print("4. Delete student detail")
#     print("5. Update student detail")
#     print("6. Sorting (Rollno, Name, department, semester, Age)")
#     print("0. Exit")
#     choice1 = int(input("Enter the Choice:"))
#
#     if choice1 == 1:
#         print("\nDisplay all student list")
#         print("Roll no :",rollno)
#         print("Name of student :",name)
#         print("Gender :",gender)
#         print("Age :",age)
#         print("Department : ",department)
#         print("Semester : ",semester)
#         print("Subject : ",)
#         print("#"*50)
#         print(student)
#         print("#"*50)
#
#     elif choice1 == 2:
#         print("\nAdd student detail")
#         rollno = int(input("Enter Roll number : "))
#         # for key in student.keys():
#         #     if key == rollno:
#         #         print("Please enter different")
#         name = input("Enter name : ")
#         gender = input("Enter gender : ")
#         age = int(input("Enter age : "))
#         department = input("Enter department : ")
#         semester = int(input("Enter semester : "))
#         subjectcode = input("Enter subject code :")
#         sub_name = input("Enter subject name :")
#         details = {rollno:[name,gender,age,department,semester],'subject':{'subjectcode':subjectcode,'subjectname':sub_name}}
#         for key in student.keys():
#             if key == rollno:
#                 print("Please enter another roll no, it already exists")
#             else:
#                 student.update(details)
#
#     elif choice1 == 3:
#         search_roll = input("Enter roll number for search :")
#         if search_roll in student:
#             print("#" * 50)
#             print(student[search_roll])
#             print("#" *50)
#         else:
#             print("Roll number not found")
#
#     elif choice1 == 4:
#         del_roll = input("Enter roll no for delete student :")

