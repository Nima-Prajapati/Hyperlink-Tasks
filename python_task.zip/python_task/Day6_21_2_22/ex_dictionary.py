# Python task (21 Feb, 2022):
#
# Task 1: Dictionary
# Dictionary : collection of items,store data values in key:value pairs,ordered*, changeable and do not allow duplicates.

###########################################################
# Practice
###########################################################
# a = {1: 'one',2:'Two',3:'Three'}
# print(type(a))
# b = {"1": 'one',"2":'Two',"3":'Three'}
# print(type(b))
# c = {"string": 'one',2:'Two',3:[1,2,3]}
# print(type(c))
#
# print(a[1])
# # print(a[4]) #KeyError
#
# print(a.get(2))
# print(a.get(4)) #None
#
# d = dict([('abc',"Hello"),(2,"World")])
# print("Dictionary is format {}".format(d))
# print(f"Dictionary is f {d}")
#
# d['abc'] = "Hi"
# # d.pop('abc')
# # d.popitem()
# # d.clear()
# # del a
# print(f"Dictionary is {d}")
#
# e = d.copy() #have diff memory address
# print(f"Dictionary is copy {e}")
#
# e = d # have same memory address
## id(e)
## id(d)
# e['abc'] = "hiiiiiiiiii"
# print(f"Dictionary is e=d {e}")
# print(f"Dictionary is e=d {d}")
#
# print(f"Dictionary is {type(d.items())}")

marks = {}.fromkeys(['Python','Nodejs','Blockchain'],0)
print(marks)
print(type(marks))
for key, value in marks.items():
    print(value)
print("#"*70)

for key, value in marks.items():
    print(f" {key} - {value}")
print("#"*70)

a = {x: x*x for x in range(10)}
print(a)
for x in range(10):
    a[x] = x*x
print(a)
print("#"*70)





#####################################################################
# Examples
#####################################################################
dict1 = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 2020,
  "colors": ["red", "white", "blue"]
}
print(dict1)

# length of dict
print("Length : ",len(dict1))

print("type of dict : ",type(dict1))
print("#"*70)

# access item from dict
x = dict1["model"]
print(x)
x = dict1.get("model")
print("Access item using get method : ",x)
x = dict1.keys()
print("access keys : ",x)
x = dict1.values()
print("Values are : ",x)
dict1["year"] = 2020
print("Access threw year : ",x)
print("#"*70)

x = dict1.items()
#show item in tuple form
print("get items : ",x)
print("#"*70)

#check if key exists
if "brand" in dict1:
    print("Yes, 'brand' is one of the keys in the dict1 dictionary")
else:
    print("Not exists")
print("#" * 70)

# change item
dict1["year"] = 2021
print("after change value : ",dict1)
dict1.update({"year": 2020})
print(dict1)
print("#"*70)

# remove items
# dict1.pop("model")
# # pop() method removes the item with the specified key name
# print("After pop method : ",dict1)

# dict1.popitem()
# # popitem() method removes the last inserted item (in versions before 3.7, a random item is removed instead
# print("After popitem : ",dict1)
#
# del dict1["year"]
# print("After del :",dict1)
# dict1.clear()
# print("After clear method : ",dict1)


# Loop
# only key
for i in dict1:
    print("for loop : ",i)

# only value
for i in dict1:
    print("values using for loop : ",dict1[i])
for i in dict1.values():
    print("values using for loop and .values : ",i)

for x, y in dict1.items():
  print(x, y)
print("#"*70)


# copy dict
copydict = dict1.copy()
print("Copy dict : ",copydict)

copydict = dict(dict1)
print("copy using dict keyword : ",copydict)
print("#"*70)


# nested dict
myfamily = {
  "child1" : {
    "name" : "Emil",
    "year" : 2004
  },
  "child2" : {
    "name" : "Tobias",
    "year" : 2007
  },
  "child3" : {
    "name" : "Linus",
    "year" : 2011
  }
}
print(myfamily)
print("#"*70)

# 1 - Convert two lists into a dictionary
# The zip() function returns a zip object, which is an iterator of tuples where the first item in each passed iterator is paired together,
# and then the second item in each passed iterator are paired together etc.If the passed iterators have different lengths,
# the iterator with the least items decides the length of the new iterator.
keys = ['Ten', 'Twenty', 'Thirty']
values = [10, 20, 30]
res_dict = dict(zip(keys, values))
print("convert list into dict",res_dict)
print("#"*70)

# 2 - Merge two Python dictionaries into one
dict1 = {'Ten': 10, 'Twenty': 20, 'Thirty': 30}
dict2 = {'Thirty': 30, 'Fourty': 40, 'Fifty': 50}
dict3 = {**dict1, **dict2}
print("Merge two dict into one : ",dict3)
# dict3 = dict1.copy()
# dict3.update(dict2)
# print(dict3)
print("#"*70)


# 3 - Initialize dictionary with default values
employees = ['Kelly', 'John']
defaults = {"designation": 'Developer', "salary": 8000}
# fromkeys()	Returns a dictionary with the specified keys and value
res = dict.fromkeys(employees, defaults)
print(res)
# Individual data
# print(res["Kelly"])
student = ['nan', 'man']
details = {"roll": '1', "standard": 10}
ans = dict.fromkeys(student,details) #method returns a dictionary with the specified keys and the specified value.
print(ans)
print("#"*70)


# 4 - extracting the keys from a given dictionary
sampleDict = {
  "name": "Kelly",
  "age":25,
  "salary": 8000,
  "city": "New york" }
keys = ["name", "salary"]
newDict = {k: sampleDict[k] for k in keys}
print(newDict)
print("#"*70)

# 5 - Delete a list of keys from a dictionary
# Keys to remove
keys = ["name", "salary"]
for k in keys:
    sampleDict.pop(k)
print(sampleDict)
print("#"*70)


# 5 - Check if a value exists in a dictionary
dict1 = {'a': 10, 'b': 20, 'c': 30}
if 20 in dict1.values():
    print('20 present in a dict')
else:
    print("20 is not present in dict")
print("#"*70)

# 6 - Get the key of a minimum value from the following dictionary
print(min(dict1, key=dict1.get))
print("#"*70)


#  7 - Change value of a key in a nested dictionary
sdict = {
    'emp1': {'name': 'Jhon', 'salary': 7500},
    'emp2': {'name': 'Emma', 'salary': 8000},
    'emp3': {'name': 'Brad', 'salary': 6500}
}

sdict['emp3']['salary'] = 8500
print(sdict)
print("#"*70)


#8  Delete specific keys from a dictionary
d1={1:"a",2:"b",3:"c"}
d1.pop(1)
print(d1)
print("#"*70)


#9 nested dic print value
d1 = {"1": {"2": {"name": "kajal","mark": {"guj": 70, "eng": 100 }}}}
print(d1['1']['2']['mark']['eng'])


#10 change the value of key
#we cant change the value we can delete and add new key at time
d1={1:'mohit',2:'karan'}
d1[3] = d1.pop(2)
print(d1)




list=[{'subcode':1,'subname':'java'},{'subcode':2,'subname':'c++'}]

for row in list:
    print(f"Subject Code : {row['subcode']} , Subject Name: {row['subname']}")


list=[1,'name','gender',{'subcode':1,'subname':'java'},{'subcode':2,'subname':'c++'}]

for index, item in enumerate(list):
    if index>2:
            for value in item.values():
                 print(value)


print("Subject Code : {} , Subject Name: {}")






# roll, name, age, semester, subject
# 1, vishals, 24, 8, [(1, DBMS), (2, DS)]

# roll, name, age, semester, subject[(code, name)]
# 1, vishals, 24, 8, [(1, DBMS), (2, DS)]