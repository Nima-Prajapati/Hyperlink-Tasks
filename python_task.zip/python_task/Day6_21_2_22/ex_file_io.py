# Python task (21 Feb, 2022):
# Task 2: File I/O

# "r" - Read - Default value. Opens a file for reading, error if the file does not exist
# "a" - Append - Opens a file for appending, creates the file if it does not exist
# "w" - Write - Opens a file for writing, creates the file if it does not exist
# "x" - Create - Creates the specified file, returns an error if the file exists
# "t" - Text - Default value. Text mode
# "b" - Binary - Binary mode (e.g. images)
# t and b have with create/read/write/append any mode
# r+	It opens the file to read and write both. The file pointer exists at the beginning.
# w+	It opens the file to write and read data. It will override existing data.
# a+	It opens a file to append and read both.
# rb+	It opens the file to read and write both in binary format. The file pointer exists at the beginning of the file.
# file methods:read,readline,readlines,truncate(size),write,writelines,close,seek,tell,fileno,flush
# fileno()	Returns a number that represents the stream, from the operating system's perspective.


# f = open("fileoperation.txt")
# print(f)
#
# f = open("fileoperation.txt",'w')
# f.close()
# print(f)
#
# f = open("fileoperation.txt",'a')
# f.write("How are you??")
# f.close()
# print(f)
#
# f = open("fileoperation.txt",'a+b')
# f.close()
# print(f)
#
# f = open("fileoperation.txt",'a+t')
# f.close()
# print(f)
#
# # w+ : write in file
# f = open("fileoperation.txt",'w+')
# f.write("How are you??")
# f.close()
# print(f)
#
# f = open("fileoperation.txt",'r+')
# print(f.read())
# # f.write("How are you??")
# f.close()
# # print(f)
#
# f = open("fileoperation.txt",'r+')
# print(f.read())
# f.write("good")
# f.close()
# # print(f)
#
# f = open("fileoperation.txt",'r+')
# print(f.read())
# f.write("awsome")
# f.close()
# # print(f)
#
#
# try:
#     f = open("fileoperation.txt", 'r+')
#     print(f.read())
#     f.write("\tawsome2")
# except Exception:
#     pass
# finally:
#     f.close()
#
## no need to close file
# with open("fileoperation.txt",'r+') as f:
#     print(f.read())
#     f.write("\tHello")
#     print(f.read())
#
#
# # with open("fileoperation.txt",'r+') as f:
#       #Returns the current file location.
# #     print(f.tell())
# #     f.write("100 lines")
#
# with open("fileoperation.txt",'r+') as f:
#     # print(f.seek(100))
#     # Set file pointer position in a file
#     f.seek(100)
#     print(f.read())
#
# with open("fileoperation.txt",'r+') as f:
#     for line in f:
#         print(line,end='')




######################################################
# Example w3school

# f = open("demofile1.txt", "a")
# f.write("Now the file has more content!")
# f.close()
# #open and read the file after the appending:
# f = open("demofile1.txt", "r")
# print(f.read())
#
# # Read Only Parts of the File
# f = open("demofile1.txt", "r")
# print(f.read(5))
#
# f = open("demofile1.txt", "r")
# print(f.readline())
# print(f.readline())
# f.close()
#
#
# f = open("demofile1.txt", "r")
# for x in f:
#   print(x)
# f.close()



# ##############################################################
# Example
################################################################
#1 file open

# f = open("demofile1.txt", "r")
# print("1 ans :",f.read())
# f.close()
# print("+-"*50)
#
#
# #2 Write a function in python to count the number of lines from a text file.which is starting with an alphabet "H".
# file = open("demofile1.txt","r")
# c=0
# print("2nd ans:")
# for line in file:
#     if line[0] in 'H':
#         c+=1
# print(c)
# file.close()
# print("+-"*50)
#
#
# #3 Write a function in Python to count and display the total number of character in a text file
# file = open("demofile1.txt","r")
# pco = 0
# wco=0
# for line in file:
#     pco+=1
#     for word in line:
#         wco+=1
# print("3rd ans :")
# print("no of line in file :",pco)
# print("no of character in file :",wco)
# file.close()
# print("+-"*50)
#
#
# #4 Write a function in Python to read lines from a text file. Your function should find and display the occurrence of the word "Now
# count=0
# file=open("demofile1.txt",'r')
# read = file.read()
# word = read.split()
# for w in word:
#     if w=='Now':
#         count+=1
# print("4th ans :",count)
# print("+-"*50)
#
#
# #5 Write a function in Python to count uppercase character in a text file.
# file = open("demofile1.txt",'r')
# data = file.read()
# coun=0
# for char in data:
#     if char.isupper():
#         coun+=1
# print("uppercase word count :",coun)
# file.close()
# print("+-"*50)
#
#
# #6 last word is e
# file=open("demofile1.txt",'r')
# data=file.read()
# word=data.split()
# for w in word:
#     if w[-1]=='e':
#         print(w)
# print("+-"*50)

"""
append,write and read
"""
# with open('demofile1.txt', 'a') as f:
#     f.write("\nKnowledge is power")
#
# f = open('demofile1.txt', 'r')  # checking
# print(f.read())








