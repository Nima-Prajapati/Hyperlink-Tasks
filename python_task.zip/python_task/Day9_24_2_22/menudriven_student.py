"""
python task (23 Feb, 2022):

Menu Driven task
----------------------------------------------
Task 3: Build a simple Student Management System
    - Display all student list
    - Add student detail (Rollno, Name, Gender, Age, department, semester, subjects)
        a. subjects : subject_code and subject_name
    - Search student by rollno, name, department
    - Delete student detail
    - Update student detail
    - Sorting (Rollno, Name, department, semester, Age)

Today's python task (24 Feb, 2022)

Menu driven task with CSV File Handling
------------------------------------------------

Task 1: Build a simple Student Management System With File Handling (CSV File)
    - Display all student list
    - Add student detail (Rollno, Name, Gender, Age, department, semester, subjects)
        a. subjects : subject_code and subject_name
    - Search student by rollno, name, department
    - Delete student detail
    - Update student detail
    - Sorting (Rollno, Name, department, semester, Age)
"""
"""
Modes:
‘r’ – to read an existing file,
‘w’ – to create a new file if the given file doesn’t exist and write to it,
‘a’ – to append to existing file content,
‘+’ –  to create a new file for reading and writing
"""


import csv,operator,os
id = 0
sub_c=6
sub_n=7
up_sub_c=6
up_sub_n=7
count=0
#student=[{}]
student=[]
subject=[]


def savefile(student):
    header = ['id', 'Roll no', 'Name', 'Gender', 'Age', 'department', 'semester', 'subjects']
    s_file = open("sample.csv", "w")
    writer = csv.writer(s_file)
    writer.writerow(header)
    writer.writerows(student)
    print("Single data write successfully...")
    s_file.close()


def cases(num):
    try:
        if num==0:
            exit()
        match num:
            case 1:
                f = open('sample.csv', 'r')
                reader = csv.reader(f)

                global id, d
                id = id + 1
                print(id)
                # id = int(input("enter the id:"))
                # name = input("enter the student name:")
                rollno = input("Enter the student roll no:")

                for row in reader:
                    if len(row)!=0:
                        if row[1]==rollno:
                            print('#'*50)
                            print("This roll no ",rollno,"is already used please enter unique")
                            print('#' * 50)
                            choicefuc()
                            break

                name = input("Enter the student name:")
                punc = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
                while True:
                    if name.isalpha() and len(name) <= 5 and len(name) >= 1:
                        break
                    elif name == punc and name == " ":
                        print("Name only contain characters")
                        name = input('Enter Name : ')
                    else:
                        print("Name only contain characters")
                        name = input('Enter Name : ')
                gender = input("Enter the student gender:")
                while True:
                    if gender.isalpha() and gender == 'male' or gender == 'female':
                        break
                    elif gender == " ":
                        print("Enter gender")
                        gender = input('Enter Gender : ')
                    else:
                        print("Enter male or female only")
                        gender = input('Enter Gender : ')
                age = input("Enter the student age:")
                while True:
                    if age.isdigit() and len(age) > 0 and len(age) < 4:
                        break
                    elif age == " ":
                        print("Please Enter age")
                        age = input('Enter Age : ')
                    else:
                        print("Enter Numeric value only")
                        age = input('Enter Age : ')
                department = input("Enter the studnet depart:")
                while True:
                    if department.isalpha():
                        break
                    elif department == " ":
                        print("Please enter department")
                        department = input('Enter Department : ')
                    else:
                        print("Enter character only")
                        department = input('Enter Department : ')

                sem = input("Enter the student semester:")
                while True:
                    if sem.isdigit() and len(sem) > 0:
                        break
                    elif sem == " ":
                        print("Please enter semester")
                        sem = input('Enter Semester : ')
                    else:
                        print("Enter Numeric value only")
                        sem = input('Enter Semester : ')

                sub_count = int(input("Enter the subject you want to add:"))
                data = [
                    id, rollno, name, gender, age, department,
                    sem]

                for i in range(sub_count):
                    sub_code = input("subject code :")
                    while True:
                        if sub_code.isdigit():
                            break
                        elif sub_code == " ":
                            print("Enter Numeric Subject code")
                            sub_code = input("Enter Subject code : ")
                        else:
                            print("Enter Numeric Subject code")
                            sub_code = input("Enter Subject code : ")
                    sub_name = input("subject name:")
                    while True:
                        if sub_name.isalpha():
                            break
                        elif sub_name == " ":
                            print("Enter Numeric Subject code")
                            sub_name = input("Enter Subject Name : ")
                        else:
                            print("Enter Numeric Subject code")
                            sub_name = input("Enter Subject Name : ")
                    d = [sub_code,sub_name]
                    data.append(d)

                student.append(data)
                header = ['id', 'Roll no', 'Name', 'Gender', 'Age', 'department', 'semester','subjects']
                s_file = open("sample.csv", "w")
                writer = csv.writer(s_file)
                writer.writerow(header)
                writer.writerows(student)
                print("Single data write successfully...")
                s_file.close()
                # updatelist=[]
                # for index, value in enumerate(student[0][7]):
                #     updatelist.append(value)
                # print(updatelist[0])
                choicefuc()

            case 2:
                if not os.path.isfile('sample.csv'):
                    print("File not exists.")
                    # Creates a new file, because file not exists.
                    with open('sample.csv', 'w') as fp:
                        pass
                elif len(student)==0:
                    print("No data found")
                    choicefuc()
                else:
                    f = open('sample.csv', 'r')
                    reader = csv.reader(f)
                    # headers = next(reader, None)
                    # print(headers)
                    data1 = [row for row in reader]
                    for p in data1:
                        print("#"*50)
                        print(p)

                    choicefuc()

            case 3:
                print("1.Search by name")
                print("2.Search by roll no")
                print("3.Search by department")
                print("0.exit")
                serach=int(input("enter yor choice for search :"))
                if serach>3:
                    print("Please enter choice between 0 to 3 number")
                    choicefuc()
                else:
                    match serach:
                        case 0:
                            choicefuc()
                        case 1:
                            names=input("Enter the name for search : ")
                            f = open('sample.csv', 'r')
                            reader = csv.reader(f)

                            for row in reader:
                                rang=len(row)
                                c=rang-1
                                #print('forloop')
                                if row[2]==names:
                                    cou=-1
                                    for i in range(int(c)):
                                        cou=cou+1
                                        print(row[cou],end='   ')
                                    choicefuc()
                                    print("#" * 50)
                                else:
                                    print("Name not found")
                                    choicefuc()
                                    print("#" * 50)
                                    # names = input("Enter the name for search : ")
                        case 2:
                            rollno = input("Enter the rollno for search:")
                            f = open('sample.csv', 'r')
                            reader = csv.reader(f)

                            for row in reader:
                                rang = len(row)
                                c = rang - 1
                                # print('forloop')
                                if row[1] == rollno:
                                    cou = -1
                                    for i in range(int(rang)):
                                        cou = cou + 1
                                        print(row[cou], end='   ')
                                    choicefuc()
                                    print("#" * 50)
                                else:
                                    print("Roll Number not found")
                                    print("#" * 50)
                                    choicefuc()
                        case 3:
                            depart = input("Enter the department for search :")
                            f = open('sample.csv', 'r')
                            reader = csv.reader(f)

                            # for row in reader:
                            #     for row[5] in row:
                            #         if row[5]==depart:
                            #             print("roll :",row[1])
                            for row in reader:
                                rang = len(row)
                                c = rang - 1
                                # print('forloop')
                                if row[5] == depart:
                                    cou = -1
                                    data1=[]
                                    for i in range(int(rang)):
                                        cou = cou + 1
                                        data1.append(row[cou])

                                    print(data1)
                                    choicefuc()
                                    print("#" * 50)
                                else:
                                    print("Department not found")
                                    print("#" * 50)
                                    choicefuc()
            case 4:
                if len(student)==0:
                    print("No data found")
                    choicefuc()
                else:
                    f = open('sample.csv', 'r')
                    reader = csv.reader(f)
                    print("--- Delete Student ---")
                    roll = input("Enter roll no. to delete: ")
                    for row in reader:
                        if roll in row[1]:

                            student_found = False
                            updated_data = []
                            with open('sample.csv', "r", encoding="utf-8") as f:
                                reader = csv.reader(f)
                                counter = 0
                                for row in reader:
                                    if len(row) > 0:
                                        if roll != row[0]:
                                            updated_data.append(row)
                                            counter += 1
                                        else:
                                            student_found = True

                                if student_found is True:
                                    with open('sample.csv', "w", encoding="utf-8") as f:
                                        writer = csv.writer(f)
                                        writer.writerows(updated_data)
                                    print("Roll no. ", roll, "deleted successfully")
                                else:
                                    print("student not found")
                                    print("#" * 50)
                            choicefuc()
                        else:
                            print("Roll no not found")
                            choicefuc()

            case 5:
                roll_id=input("Enter roll no:")
                print(roll_id)
                f = open('sample.csv', 'r')
                reader = csv.reader(f)
                # header = ['id', 'Roll no', 'Name', 'Gender', 'Age', 'department', 'semester', 'subjects']
                for roll in student:
                    print("1.update name")
                    print("2.update gender")
                    print("3.update age")
                    print("4.update department")
                    print("5.update semester")
                    print("6.update subject info")
                    ch=int(input("enter the "))
                    match ch:
                            case 1:
                                print(student)
                                up_name=input('Enter the updated name:')
                                # punc = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
                                # if up_name.isalpha() and len(up_name) <= 5 and len(up_name) >= 1:
                                #     break
                                # elif up_name == punc and up_name == " ":
                                #     print("Name only contain characters")
                                #     up_name = input('Enter Name : ')
                                # elif up_name.isdigit():
                                #     print("Name only contain characters")
                                #     up_name = input('Enter Name : ')
                                # else:
                                for i in student:
                                    if i[1]==roll_id:
                                        i[2]=up_name
                                        print("updated")
                                        savefile(student)

                                    choicefuc()
                            case 2:
                                up_gender=input('Enter the updated gender:')
                                # if up_gender.isalpha() and (up_gender == 'male' or up_gender == 'female'):
                                #     break
                                # elif up_gender == " ":
                                #     print("Enter gender")
                                #     up_gender = input('Enter Gender : ')
                                # else:
                                for i in student:
                                    if i[1] == roll_id:
                                        i[3] = up_gender
                                        print("updated")
                                        savefile(student)

                            case 3:
                                try:
                                    up_age = int(input('enter the updated age:'))
                                    for i in student:
                                        if i[1] == roll_id:
                                            i[4] = up_age
                                            print("updated")
                                            savefile(student)
                                            choicefuc()
                                except:
                                    print("#"*50)
                                    print("please enter the numeric value")
                                    print("#"*50)
                                    choicefuc()
                            case 4:
                                up_depart = input('Enter the updated department:')
                                for i in student:
                                    if i[1] == roll_id:
                                            i[5] = up_depart
                                            print("updated")
                                            savefile(student)
                                            choicefuc()
                            case 5:
                                up_sem = input('Enter the updated sem:')
                                for i in student:
                                    if i[1] == roll_id:
                                        i[6] = up_sem
                                        print("updated")
                                        savefile(student)
                                        choicefuc()
                            case 6:
                                updatelist = []
                                roll_id = input("Enter roll no you want update which id's subject")
                                for row in student:
                                    if row[1]==roll_id:
                                        #import pdb;pdb.set_trace()
                                        for i,v in enumerate(row):
                                            if i>6:
                                                updatelist.append(v)
                                        c=0
                                        for indx,vale in enumerate(updatelist):
                                            c=c+1
                                            print(c,vale)
                                        choice=int(input("enter your choice"))
                                        if choice<= len(updatelist) and choice!=0:

                                            if choice==1:
                                                up_sub_code = input("Enter the you want update code:")
                                                up_sub_name = input("Enter the updated subject name :")
                                                updatelist[0][0] = up_sub_code
                                                updatelist[0][1] = up_sub_name
                                            if choice==2:
                                                up_sub_code = input("Enter the you want update code:")
                                                up_sub_name = input("Enter the updated subject name :")
                                                updatelist[1][0] = up_sub_code
                                                updatelist[1][1] = up_sub_name
                                            if choice==3:
                                                up_sub_code = input("Enter the you want update code:")
                                                up_sub_name = input("Enter the updated subject name :")
                                                updatelist[2][0] = up_sub_code
                                                updatelist[2][1] = up_sub_name
                                            if choice==4:
                                                up_sub_code = input("Enter the you want update code:")
                                                up_sub_name = input("Enter the updated subject name :")
                                                updatelist[3][0] = up_sub_code
                                                updatelist[3][1] = up_sub_name
                                            if choice==5:
                                                up_sub_code = input("enter the you want update code:")
                                                up_sub_name = input("enter the updated subject name :")
                                                updatelist[4][0] = up_sub_code
                                                updatelist[4][1] = up_sub_name
                                        else:
                                            print("#"*50)
                                            print("you have only",len(updatelist),"subject please enter valid choice")
                                            print("#" * 50)
                                            choicefuc()

                                        print(updatelist)
                                        savefile(student)
                                        choicefuc()

                                else:
                                    print("Roll not found")

            case 6:
                print("1.sort by roll no")
                print("2.sort by name")
                print("3.sort by department")
                print("0.exit")
                n=int(input("Enter sort choice:"))
                match n:
                    case 0:
                        choicefuc()
                    case 1:
                        data = csv.reader(open('sample.csv'), delimiter=',')
                        head=next(data)
                        # sort data on the basis of roll no
                        dat = sorted(data, key=operator.itemgetter(1))
                        for i in dat:
                            print(i)
                        print('After sorting:')

                        choicefuc()
                    case 2:
                        data = csv.reader(open('sample.csv'), delimiter=',')
                        head = next(data)

                        # sort data on the basis of name
                        data1 = sorted(data, key=operator.itemgetter(2))

                        # displaying sorted data
                        print('After sorting:')
                        print(data1)
                    case 3:
                        data = csv.reader(open('sample.csv'), delimiter=',')
                        head = next(data)

                        # sort data on the basis of department
                        data2 = sorted(data, key=operator.itemgetter(5))

                        # displaying sorted data
                        print('After sorting:')
                        print(data2)
            case 0:
                exit()
    except ValueError:
        print("Please enter only numeric")
        print("#"*50)
    except AttributeError:
        print("attribute assignment or reference fails")
    except ImportError:
        print("Import module properly")
    except IndexError:
        print("list index out of range")
    except KeyError:
        print("Key not found")
    except NameError:
        print("variable is not found in local or global scope")
    except SyntaxError:
        print("Invalid syntax")
    except TypeError:
        print("function or operation is applied to an object of incorrect type")
    except EOFError:
        print("End of line")
    except FileNotFoundError:
        print("File not created..")
        print()



def choicefuc():
    print("#" * 50)
    print("Menu For Student Management System")
    print("1.Add student detail")
    print("2.Display all student list")
    print("3.Search student")
    print("4.Delete student detail")
    print("5.Update student detail")
    print("6.Sorting (Rollno, Name, department, semester, Age)")
    print("0.exit")
    print("#" * 50)
    try:
        choice = int(input("Enter your choice : "))
        print("#" * 50)
        if choice<=6:
            cases(choice)
        else:
                print("#"*40)
                print("please enter the correct no")
                print("#" * 40)
                choicefuc()

    except ValueError:
        print("#"*50)
        print("enter the num of list")
        print("#"*50)
        choicefuc()


choicefuc()







# import csv
# import os
#
# id = 0
# sub_c=5
# sub_n=6
# up_sub_c=5
# up_sub_n=6
# count=0
# student={}
# # student_fields = ['Roll no','name','age','gender','department','sem','sub_code','sub_name']
# student_fields = ['Roll no','name','age','gender','department','sem','subject']
# student_file = 'student.csv'
# # student["subject"] = []
#
#
# def cases(num):
#     try:
#         if num == 0:
#             print("Thank you...")
#             exit()
#         else:
#             match num:
#                 case 1:
#                     # if len(student)==0:
#                     #     print("Empty list")
#                     if not os.path.isfile('student.csv'):
#                         print("File not exists.")
#                         # Creates a new file, because file not exists.
#                         with open('student.csv', 'w') as fp:
#                             pass
#                     if os.stat('student.csv').st_size == 0:
#                         print("Student data not found.")
#                         choiceFunction()
#                     else:
#                         print("Display all student list")
#                         print("#" * 50)
#                         # print(student,end="\n")
#                         # reader = csv.reader(open('student.csv','r'))
#                         with open('student.csv', 'r') as f:
#                             reader = csv.reader(f)
#                             header = next(reader, None)
#                             print(header)
#                             # for i in student_fields:
#                             #     print(i,end='\t ')
#                             for row in reader:
#                                 for item in row:
#                                     print(item)
#                                 # print("\n")
#                         print("#" * 50)
#                     choiceFunction()
#                 case 2:
#                     flag = True
#                     global id
#                     id = id + 1
#                     print(id)
#
#                     # id = int(input("enter the id:"))
#                     name = input("enter the student name:")
#                     rollno = input("enter the student rollno:")
#                     for key, val in student.items():
#                         if len(val) != 0:
#                             if val[0] == rollno:
#                                 print("#" * 40)
#                                 print("please enter uniqe roll number this no already asign")
#                                 print("#" * 40)
#                                 choiceFunction()
#                     gender = input("enter the student gender:")
#                     age = input("enter the student age:")
#                     department = input("enter the studnet depart:")
#                     sem = input("enter the student semester:")
#                     sub_count = int(input("Enter the subject you want to add:"))
#                     data = [rollno, name, gender, age, department, sem]
#                     # details = {id: [rollno, name, gender, age, department, sem]}
#                     for i in range(sub_count):
#                         sub_code = input("subject code")
#                         sub_name = input("subject name:")
#                         # subject = [{sub_code: sub_name}]
#                         subject = [sub_code,sub_name]
#                         data.extend(subject)
#                         print(data[6])
#                     student.update({id:data})
#                     student_file = open("student.csv","w")
#                     writer = csv.writer(student_file)
#                     for key, value in student.items():
#                         writer.writerow([key,value])
#
#                     student_file.close()
#                     # with open('student.csv','w') as f:
#                     #     writer = csv.writer(f)
#                     #
#                     #     writer.writerow(student_fields)
#                     #     for key, value in student.items():
#                     #         writer.writerow([key,value])
#                     # f.close()
#                     choiceFunction()
#                 case 3:
#                     print("#" * 50)
#                     print("1.Search by name")
#                     print("2.Search by rollno")
#                     print("3.Search by department")
#                     print("0.Exit")
#                     print("#" * 50)
#                     srch = int(input("Enter yor choice for search :"))
#                     # def srchcases(c)
#                     if srch == 0:
#                         exit()
#                     else:
#                         match srch:
#                             case 1:
#                                 name = input("Enter the name for search:")
#                                 sub_val = ''
#                                 with open('student.csv') as f:
#                                     reader = csv.DictReader(f)
#                                 for row in reader:
#                                     if (len(row) > 0):
#                                         if row[1] == name:
#                                             print("Roll no : ",row[0])
#                                             print("Name :",row[1])
#                                             break
#                                         else:
#                                             print("Name not found")
#
#                                 # if len(name)==1:
#                                 #     for key,val in student.items():
#                                 #         value=str(val[1])
#                                 #         s=value[0]
#                                 #         s.split()
#                                 #         if s == name:
#                                 #             print("#"*50)
#                                 #             print(student[key])
#                                 #             print("#"*50)
#                                 #             choiceFunction()
#                                 #         else:
#                                 #             print("student not found")
#                                 if len(name)>1:
#                                     for key,val in student.items():
#                                         try:
#                                             if val[1] == name:
#                                                 print("#"*50)
#                                                 print(student[key])
#                                                 print("#"*50)
#                                                 choiceFunction()
#                                             else:
#                                                 print("Data not found")
#                                         except IndexError:
#                                             print("Enter proper name")
#                                             choiceFunction()
#                                 else:
#                                     print("Data not found")
#                                 # for key, val in student.items():
#                                 #     if val[1] == name:
#                                 #         print("#" * 40)
#                                 #         print(student[key])
#                                 #         print("#" * 40)
#                                 #         # choiceFunction()
#                                 #         # searchcase()
#                                 #     else:
#                                 #         print("Name Not found")
#                             case 2:
#                                 find_roll = input("Enter rollno for search:")
#                                 if find_roll in student:
#                                     print("#" * 50)
#                                     print(student[find_roll])
#                                     print("#" * 50)
#                                     choiceFunction()
#                                 else:
#                                     print("roll no not found")
#                                     choiceFunction()
#                                 # for key,val in student.items():
#                                 #     if val[0] == find_roll:
#                                 #         print("#" * 50)
#                                 #         print(student[key])
#                                 #         print("#" * 50)
#                                 #         # choiceFunction()
#                                 #     else:
#                                 #         print("Roll number not found")
#                                 #         choiceFunction()
#                             case 3:
#                                 depart = input("Enter department for search : ")
#                                 for key, val in student.items():
#                                     if val[4] == depart:
#                                         print("#" * 40)
#                                         print(student[key])
#                                         print("#" * 40)
#                                         # choiceFunction()
#                                     else:
#                                         print("Department Not found")
#                     choiceFunction()
#                 case 4:
#                     if len(student) == 0:
#                         print("no data found")
#                         choiceFunction()
#                     else:
#                         roll = int(input("Enter roll for delete : "))
#                         try:
#                             for key, val in student.items():
#                                 if val[0] == roll:
#                                     student.pop(key)
#                                     print("student deleted")
#                                     choiceFunction()
#                                 else:
#                                     print("roll no not found")
#                         except RuntimeError:
#                             pass
#                         choiceFunction()
#                 case 5:
#                     roll_id = int(input("enter the roll no:"))
#                     print(roll_id)
#
#                     for roll_id in student:
#
#                         print("1.update name")
#                         print("2.update age")
#                         print("3.update gender")
#                         print("4.update department")
#                         print("5.update semester")
#                         print("6.update subject info")
#
#                         ch = int(input("enter the "))
#
#                         match ch:
#                             case 1:
#                                 up_name = input('enter the updated name')
#                                 student[roll_id][1] = up_name
#                                 print("#" * 50)
#                                 print("student name update")
#                                 print("#" * 50)
#                                 choiceFunction()
#                             case 2:
#                                 up_gender = input('enter the updated gender')
#                                 student[roll_id][2] = up_gender
#                                 print("#" * 50)
#                                 print("student gender updated")
#                                 print("#" * 50)
#                                 choiceFunction()
#
#                             case 3:
#                                 try:
#                                     up_age = int(input('enter the updated age'))
#                                     student[roll_id][3] = up_age
#                                     print("#" * 50)
#                                     print("student age update")
#                                     print("#" * 50)
#                                     choiceFunction()
#                                 except:
#                                     print("#" * 40)
#                                     print("please enter the numeric value")
#                                     print("#" * 40)
#                                     choiceFunction()
#                             case 4:
#                                 up_depart = input('enter the updated department')
#                                 student[roll_id][4] = up_depart
#                                 print("#" * 50)
#                                 print("student department update")
#                                 print("#" * 50)
#                                 choiceFunction()
#                             case 5:
#                                 up_sem = input('enter the updated sem')
#                                 student[roll_id][5] = up_sem
#                                 print("#" * 50)
#                                 print("student semester update")
#                                 print("#" * 50)
#                                 choiceFunction()
#                             case 6:
#                                 # print(student[id][7])
#                                 roll_id = int(input("enter id you want to update:"))
#                                 # print(student[roll_id])
#                                 # import pdb;pdb.set_trace()
#
#                                 print(roll_id)
#                                 # print("direct",student[2])
#                                 print("non direct", student[roll_id])
#                                 reng = len(student[roll_id])
#                                 print("value count", reng)
#                                 up = reng - 6
#                                 print("seprate sub", up)
#                                 for i in range(reng):
#                                     if i > 5:
#                                         reng1 = up / 2
#                                         print("rang subject pair", reng1)
#                                         global sub_c, sub_n, count
#                                         for j in range(int(reng1)):
#                                             sub_c = sub_c + 1
#                                             sub_n = sub_n + 1
#                                             count = count + 1
#
#                                             try:
#                                                 print(count, 'subject code:', student[roll_id][sub_c], 'subject name:',
#                                                       student[roll_id][sub_n])
#                                                 sub_c = sub_c + 1
#                                                 sub_n = sub_n + 1
#                                             except:
#                                                 pass
#
#                                 chose = int(input("enter which subject you want to update"))
#                                 global up_sub_c, up_sub_n
#
#                                 up_code = input("enter updated code")
#                                 up_name = input("enter updated name")
#                                 print(roll_id)
#                                 if chose == 1:
#                                     up_sub_c = up_sub_c + 1  # 6
#                                     up_sub_n = up_sub_n + 1  # 7
#                                     student[roll_id][up_sub_c] = up_code
#                                     student[roll_id][up_sub_n] = up_name
#                                     print(up_sub_c, up_sub_n)
#                                     print(student)
#                                     choiceFunction()
#                                 if chose == 2:
#                                     up_sub_c = up_sub_c + 3  # 8
#                                     up_sub_n = up_sub_n + 3  # 9
#                                     student[roll_id][up_sub_c] = up_code
#                                     student[roll_id][up_sub_n] = up_name
#                                     print(up_sub_c, up_sub_n)
#                                     print(student)
#                                     choiceFunction()
#                                 if chose == 3:
#                                     up_sub_c = up_sub_c + 5  # 10
#                                     up_sub_n = up_sub_n + 5  # 11
#                                     student[roll_id][up_sub_c] = up_code
#                                     student[roll_id][up_sub_n] = up_name
#                                     print(up_sub_c, up_sub_n)
#                                     print(student)
#                                     choiceFunction()
#                                 if chose == 4:
#                                     up_sub_c = up_sub_c + 4
#                                     up_sub_n = up_sub_n + 4
#                                     student[roll_id][up_sub_c] = up_code
#                                     student[roll_id][up_sub_n] = up_name
#                                     print(student)
#                                     choiceFunction()
#
#                             # case 7:
#                             #     up_sub_name = input('enter the updated subject name')
#                             #     student[id][6] = up_sub_name
#                             #     print("#" * 50)
#                             #     print("student subject name update")
#                             #     print("#" * 50)
#                             #     choiceFunction()
#                     choiceFunction()
#                 case 6:
#                     print("#" * 50)
#                     print("1.Sort by roll no")
#                     print("2.Sort by name")
#                     print("3.Sort by department")
#                     print("4.Sort by semester")
#                     print("5.Sort by age")
#                     print("0.Exit")
#                     print("#" * 50)
#                     n = int(input("Enter sort choices : "))
#                     data = csv.reader(open('student.csv'))
#
#                     if n == 0:
#                         exit()
#                     else:
#                         match n:
#                             case 1:
#                                 data = sorted(student.items(), key=lambda x: x[0],reverse=True)
#                                 print('After sorting:')
#                                 print(data)
#                                 print("-" * 50)
#                                 choiceFunction()
#                             case 2:
#                                 # sortname = sorted(student.items(), key=operator.itemgetter(1))
#                                 data = sorted(student.items(),key=lambda x: x[1])
#                                 print(data)
#                                 print("-" * 50)
#                                 choiceFunction()
#                             case 3:
#                                 data = sorted(student.items(), key=lambda x: x[4],reverse=True)
#                                 print(data)
#                                 choiceFunction()
#                             case 4:
#                                 data = sorted(student.items(), key=lambda x: x[5],reverse=True)
#                                 print(data)
#                                 choiceFunction()
#                             case 5:
#                                 data = sorted(student.items(), key=lambda x: x[3], reverse=True)
#                                 print(data)
#                                 choiceFunction()
#                     choiceFunction()
#     except ValueError:
#         print("Please enter only numeric for last except")
#         print("#"*50)
#     except ImportError:
#         print("Import module properly")
#     except IndexError:
#         print("list index out of range")
#     except KeyError:
#         print("Key not found")
#     except NameError:
#         print("variable is not found in local or global scope")
#     except SyntaxError:
#         print("Invalid syntax")
#     except IndentationError:
#         print("Give proper indentation")
#     except TypeError:
#         print("function or operation is applied to an object of incorrect type")
#         print()
#
#
#
# def choiceFunction():
#     print("#" * 50)
#     print("Welcome to Student Management System")
#     print("#" * 50)
#     print("1.Display all student list")
#     print("2.Add student detail")
#     print("3.Search student by rollno")
#     print("4.Delete student detail")
#     print("5.Update student detail")
#     print("6.Sorting (Rollno, Name, department, semester, Age)")
#     print("0.Exit")
#     print("#" * 50)
#     try:
#         choice = int(input("Enter your choice:"))
#         if choice <= 6:
#             cases(choice)
#         else:
#             print("#" * 40)
#             print("please enter the correct no")
#             print("#" * 40)
#             choiceFunction()
#     except ValueError:
#         print("#"*40)
#         print("Enter the number only for choice")
#         print("#"*40)
#         choiceFunction()
#
# choiceFunction()



# def searchcase():
#     print("#" * 50)
#     print("1.Search by name")
#     print("2.Search by rollno")
#     print("3.Search by department")
#     print("0.Exit")
#     print("#" * 50)
#     try:
#         srch = int(input("Enter your choice for search:"))
#         srchcases(srch)
#     except ValueError:
#         print("#"*40)
#         print("Enter the number only for choice")
#         print("#"*40)
#         searchcase()










# import math
# student_list = [{
#     "rollno":1,
#     "name":""
# }]
# # creating options
# while True:
#     print("\nSTUDENT MENU")
#     print("1. Display all student list")
#     print("2. Add student detail")
#     print("3. Search student by rollno, name, department")
#     print("4. Delete student detail")
#     print("5. Update student detail")
#     print("6. Sorting (Rollno, Name, department, semester, Age)")
#     print("0. Exit")
#     choice1 = int(input("Enter the Choice:"))
#
#     if choice1 == 1:
#         print("\nDisplay all student list")
#         print("Roll no :",rollno)
#         print("Name of student :",name)
#         print("Gender :",gender)
#         print("Age :",age)
#         print("Department : ",department)
#         print("Semester : ",semester)
#         print("Subject : ",)
#         print("#"*50)
#         print(student)
#         print("#"*50)
#
#     elif choice1 == 2:
#         print("\nAdd student detail")
#         rollno = int(input("Enter Roll number : "))
#         # for key in student.keys():
#         #     if key == rollno:
#         #         print("Please enter different")
#         name = input("Enter name : ")
#         gender = input("Enter gender : ")
#         age = int(input("Enter age : "))
#         department = input("Enter department : ")
#         semester = int(input("Enter semester : "))
#         subjectcode = input("Enter subject code :")
#         sub_name = input("Enter subject name :")
#         details = {rollno:[name,gender,age,department,semester],'subject':{'subjectcode':subjectcode,'subjectname':sub_name}}
#         for key in student.keys():
#             if key == rollno:
#                 print("Please enter another roll no, it already exists")
#             else:
#                 student.update(details)
#
#     elif choice1 == 3:
#         search_roll = input("Enter roll number for search :")
#         if search_roll in student:
#             print("#" * 50)
#             print(student[search_roll])
#             print("#" *50)
#         else:
#             print("Roll number not found")
#
#     elif choice1 == 4:
#         del_roll = input("Enter roll no for delete student :")


# x = [{"srno.":1, "name":"vishal"}, {"srno.":2, "name":"nima"}, {"srno.":3, "name":"shahu"}]
