"""
Task 1: Student management system with RegEX validation
"""
import csv, operator, json, os
import re

id = 0
sub_c = 6
sub_n = 7
up_sub_c = 6
up_sub_n = 7
count = 0
# student=[{}]
student = []
subject = []


# if (not nam.isalpha() and nam.isdigit()) and nam == " ":

def savefile(student):
    header = ['id', 'Roll no', 'Name', 'Email', 'Gender', 'Age', 'department', 'semester', 'subjects']
    s_file = open("sample.csv", "w")
    writer = csv.writer(s_file)
    writer.writerow(header)
    writer.writerows(student)
    print("Single data write successfully...")
    s_file.close()


def cases(num):
    try:
        if num == 0:
            exit()
        match num:
            case 1:
                f = open('sample.csv', 'r')
                reader = csv.reader(f)

                global id, d
                id = id + 1
                print(id)
                # id = int(input("enter the id:"))
                while True:
                    rollno = input("enter the student rollno:")
                    proll = re.match("^[0-9]+$", rollno)
                    if not proll:
                        print("please enter a valid roll no")
                    else:
                        break
                for row in reader:
                    if len(row) != 0:
                        if row[1] == rollno:
                            print('#' * 50)
                            print("this roll no ", rollno, "is already used please enter unique")
                            print('#' * 50)
                            choicefuc()
                            break
                while True:
                    name = input("Enter the student name:")
                    pattern_name = re.match("^[a-zA-Z]+$", name)
                    if not pattern_name:
                        print("Please Enter Valid Name")
                    else:
                        break
                while True:
                    email = input("Enter the email : ")
                    pattern_email = re.match(r'\b[a-z0-9._]+@[a-z0-9.]+\.[a-z]{2,3}\b', email)
                    if not pattern_email:
                        print("Enter proper email")
                    else:
                        break
                while True:
                    gender = input("Enter the student gender:")
                    pattern_gender = re.match("^(male|female)$", gender)
                    if not pattern_gender:
                        print("Please enter valid gender")
                    else:
                        break
                while True:
                    age = input("Enter the student age:")
                    pattern_age = re.match("^100|[1-9]?\d$", age)
                    if not pattern_age:
                        print("Please enter valid age : ")
                    else:
                        break
                while True:
                    department = input("Enter the student depart:")
                    pattern_department = re.match("^[a-zA-Z]+$", department)
                    if not pattern_department:
                        print("Enter proper department")
                    else:
                        break
                while True:
                    sem = input("Enter the student semester:")
                    pattern_sem = re.match("^([1-9]|1[012])$", sem)
                    if not pattern_sem:
                        print("Enter valid semester")
                    else:
                        break
                while True:
                    sub_count = input("Enter the subject you want to add:")
                    pattern_subcount = re.match("^[0-9]+$", sub_count)
                    if not pattern_subcount:
                        print("Enter valid count")
                    else:
                        break

                data = [id, rollno, name, email, gender, age, department,
                        sem]

                for i in range(int(sub_count)):
                    while True:
                        sub_code = input("subject code :")
                        pattern_code = re.match("^([A-Za-z0-9]+)?$", sub_code)
                        if not pattern_code:
                            print("Enter valid code")
                        else:
                            break

                    while True:
                        sub_name = input("subject name:")
                        pattern_cname = re.match("^([A-Za-z]+)?$", sub_name)
                        if not pattern_cname:
                            print("Enter valid subject name")
                        else:
                            break

                    d = [sub_code, sub_name]
                    data.append(d)

                student.append(data)
                header = ['id', 'Roll no', 'Name', 'Email', 'Gender', 'Age', 'department', 'semester', 'subjects']
                s_file = open("sample.csv", "w")
                writer = csv.writer(s_file)
                writer.writerow(header)
                writer.writerows(student)
                print("Single data write successfully...")
                s_file.close()
                choicefuc()

            case 2:
                if not os.path.isfile('sample.csv'):
                    print("File not exists.")
                    # Creates a new file, because file not exists.
                    with open('sample.csv', 'w') as fp:
                        pass
                elif len(student) == 0:
                    print("No data found")
                    choicefuc()
                else:
                    f = open('sample.csv', 'r')
                    reader = csv.reader(f)
                    head = next(f)
                    for row in reader:
                        print(row)
                        y = json.loads(row[8].replace("'", '"'))
                        print("subjectcode :", y[0], "subjectname:", y[1])
                    choicefuc()

            case 3:
                print("1.Search by name")
                print("2.Search by roll no")
                print("3.Search by department")
                print("0.exit")
                while True:
                    serach = input("enter yor choice for search :")
                    psearch = re.match("^[0-3]+$", serach)
                    if not psearch:
                        print("please enter a valid choice on numeric")
                    else:
                        break
                serach1 = int(serach)

                match serach1:
                    case 0:
                        choicefuc()
                    case 1:
                        while True:
                            names = input("enter the name")
                            pnames = re.match("^[a-zA-Z]+$", names)
                            if not pnames:
                                print("please enter a valid name")
                            else:
                                break

                        f = open('sample.csv', 'r')
                        reader = csv.reader(f)

                        for row in reader:
                            rang = len(row)
                            # c = rang-1
                            # print('forloop')
                            if row[2] == names:
                                cou = -1
                                for i in range(int(rang)):
                                    cou = cou + 1
                                    print(row[cou], end='   ')
                                choicefuc()
                                print("#" * 50)
                        else:
                            print("Name not found")
                            choicefuc()
                            print("#" * 50)
                    case 2:
                        while True:
                            rollno = input("enter the student rollno:")
                            prollno = re.match("^[0-9]+$", rollno)
                            if not prollno:
                                print("please enter a valid roll no")
                            else:
                                break

                        f = open('sample.csv', 'r')
                        reader = csv.reader(f)

                        for row in reader:
                            rang = len(row)
                            c = rang - 1
                            # print('forloop')
                            if row[1] == rollno:
                                cou = -1
                                for i in range(int(rang)):
                                    cou = cou + 1
                                    print(row[cou], end='   ')
                                choicefuc()
                                print("#" * 50)
                        else:
                            print("Roll Number not found")
                            print("#" * 50)
                            choicefuc()
                    case 3:
                        while True:
                            depart = input("enter the studnet depart:")
                            pdepart = re.match("^[a-zA-Z]+$", depart)
                            if not pdepart:
                                print("please enter a valid department")
                            else:
                                break
                        f = open('sample.csv', 'r')
                        reader = csv.reader(f)

                        for row in reader:
                            rang = len(row)
                            c = rang - 1
                            # print('forloop')
                            if row[6] == depart:
                                cou = -1
                                data1 = []
                                for i in range(int(rang)):
                                    cou = cou + 1
                                    data1.append(row[cou])

                                print(data1)
                                choicefuc()
                                print("#" * 50)
                        else:
                            print("Department not found")
                            print("#" * 50)
                            choicefuc()
            case 4:
                if len(student) == 0:
                    print("no data found")
                    choicefuc()
                else:
                    f = open('sample.csv', 'r')
                    reader = csv.reader(f)
                    print("--- Delete Student ---")
                    while True:
                        roll = input("enter the student rollno:")
                        prollp = re.match("^[0-9]+$", roll)
                        if not prollp:
                            print("please enter a valid roll no")
                        else:
                            break
                    for row in reader:
                        import pdb;
                        pdb.set_trace()
                        if roll == row[1]:

                            student_found = False
                            updated_data = []
                            with open('sample.csv', "r", encoding="utf-8") as f:
                                reader = csv.reader(f)
                                counter = 0
                                for row in reader:
                                    if len(row) > 0:
                                        if roll != row[0]:
                                            updated_data.append(row)
                                            counter += 1
                                        else:
                                            student_found = True

                                if student_found is True:
                                    with open('sample.csv', "w", encoding="utf-8") as f:
                                        writer = csv.writer(f)
                                        writer.writerows(updated_data)
                                    print("Roll no. ", roll, "deleted successfully")
                                else:
                                    print("student not found")

                            choicefuc()
                        else:
                            print("roll no not found")
                            choicefuc()

            case 5:
                while True:
                    roll_id = input("enter the student rollno:")
                    proll_id = re.match("^[0-9]+$", roll_id)
                    if not proll_id:
                        print("please enter a valid roll no")
                    else:
                        break
                print(roll_id)
                f = open('sample.csv', 'r')
                reader = csv.reader(f)
                # header = ['id', 'Roll no', 'Name', 'Email', 'Gender', 'Age', 'department', 'semester', 'subjects']
                for roll in student:
                    print("1.update name")
                    print("2.update gender")
                    print("3.update age")
                    print("4.update department")
                    print("5.update semester")
                    print("6.update subject info")
                    print("7. update email")
                    print("0.Exit")
                    while True:
                        ch = input("enter the choice")
                        proll_id = re.match("^[0-9]+$", roll_id)
                        if not proll_id:
                            print("please enter a valid choice on numeric")
                        else:
                            break
                    ch1 = int(ch)
                    match ch1:
                        case 0:
                            choicefuc()
                        case 1:
                            while True:
                                up_name = input("enter the student name:")
                                pup_name = re.match("^[a-zA-Z]+$", up_name)
                                if not pup_name:
                                    print("please enter a valid name")
                                else:
                                    break

                            for i in student:
                                if i[1] == roll_id:
                                    i[2] = up_name
                                    print("updated")
                                    savefile(student)

                            choicefuc()
                        case 2:
                            while True:
                                up_gender = input('Enter the updated gender:')
                                pup_gender = re.match("^(male|female)$", up_gender)
                                if not pup_gender:
                                    print("please enter a valid gender")
                                else:
                                    break

                            for i in student:
                                if i[1] == roll_id:
                                    i[4] = up_gender
                                    print("updated")
                                    savefile(student)

                            choicefuc()
                        case 3:
                            try:
                                while True:
                                    up_age = input('enter the updated age:')
                                    pup_age = re.match("^100|[1-9]?\d$", up_age)
                                    if not pup_age:
                                        print("please enter a valid age")
                                    else:
                                        break

                                for i in student:
                                    if i[1] == roll_id:
                                        i[5] = up_age
                                        print("updated")
                                        savefile(student)
                                choicefuc()
                            except:
                                print("#" * 50)
                                print("please enter the numeric value")
                                print("#" * 50)
                                choicefuc()
                        case 4:
                            while True:
                                up_depart = input('Enter the updated department:')
                                pup_depart = re.match("^[a-zA-Z]+$", up_depart)
                                if not pup_depart:
                                    print("please enter a valid department")
                                else:
                                    break

                            for i in student:
                                if i[1] == roll_id:
                                    i[6] = up_depart
                                    print("updated")
                                    savefile(student)
                                    choicefuc()
                        case 5:
                            while True:
                                up_sem = input('Enter the updated sem:')
                                pup_sem = re.match("^([1-9]|1[012])$", up_sem)
                                if not pup_sem:
                                    print("please enter a valid semester")
                                else:
                                    break

                            for i in student:
                                if i[1] == roll_id:
                                    i[7] = up_sem
                                    print("updated")
                                    savefile(student)
                                    choicefuc()
                        case 6:
                            updatelist = []
                            while True:
                                roll_id = input("enter the student roll no:")
                                proll_id = re.match("^[0-9]+$", roll_id)
                                if not proll_id:
                                    print("please enter a valid rollno")
                                else:
                                    break

                            for row in student:
                                if row[1] == roll_id:
                                    # import pdb;pdb.set_trace()
                                    for i, v in enumerate(row):
                                        if i > 7:
                                            updatelist.append(v)
                                    c = 0
                                    for indx, vale in enumerate(updatelist):
                                        c = c + 1
                                        print(c, vale)
                                    choice = int(input("Enter your choice : "))
                                    if choice <= len(updatelist) and choice != 0:

                                        if choice == 1:
                                            while True:
                                                up_sub_code = input("subject code")
                                                psub_code = re.match("^([A-Za-z0-9]+)?$", up_sub_code)
                                                if not psub_code:
                                                    print("please enter a valid subject code")
                                                else:
                                                    break
                                            while True:
                                                up_sub_name = input("subject name:")
                                                psub_name = re.match("^([A-Za-z]+)?$", up_sub_name)
                                                if not psub_name:
                                                    print("please enter a valid subject name")
                                                else:
                                                    break

                                            updatelist[0][0] = up_sub_code
                                            updatelist[0][1] = up_sub_name
                                        if choice == 2:
                                            while True:
                                                up_sub_code = input("subject code")
                                                psub_code = re.match("^([A-Za-z0-9]+)?$", up_sub_code)
                                                if not psub_code:
                                                    print("please enter a valid subject code")
                                                else:
                                                    break
                                            while True:
                                                up_sub_name = input("subject name:")
                                                psub_name = re.match("^([A-Za-z]+)?$", up_sub_name)
                                                if not psub_name:
                                                    print("please enter a valid subject name")
                                                else:
                                                    break

                                            updatelist[1][0] = up_sub_code
                                            updatelist[1][1] = up_sub_name
                                        if choice == 3:
                                            while True:
                                                up_sub_code = input("subject code")
                                                psub_code = re.match("^([A-Za-z0-9]+)?$", up_sub_code)
                                                if not psub_code:
                                                    print("please enter a valid subject code")
                                                else:
                                                    break
                                            while True:
                                                up_sub_name = input("subject name:")
                                                psub_name = re.match("^([A-Za-z]+)?$", up_sub_name)
                                                if not psub_name:
                                                    print("please enter a valid subject name")
                                                else:
                                                    break

                                            updatelist[2][0] = up_sub_code
                                            updatelist[2][1] = up_sub_name
                                        if choice == 4:
                                            while True:
                                                up_sub_code = input("subject code")
                                                psub_code = re.match("^[0-9]+$", up_sub_code)
                                                if not psub_code:
                                                    print("please enter a valid subject code")
                                                else:
                                                    break
                                            while True:
                                                up_sub_name = input("subject name:")
                                                psub_name = re.match("^[a-zA-Z]+$", up_sub_name)
                                                if not psub_name:
                                                    print("please enter a valid subject name")
                                                else:
                                                    break

                                            updatelist[3][0] = up_sub_code
                                            updatelist[3][1] = up_sub_name
                                        if choice == 5:
                                            while True:
                                                up_sub_code = input("subject code")
                                                psub_code = re.match("^[0-9]+$", up_sub_code)
                                                if not psub_code:
                                                    print("please enter a valid subject code")
                                                else:
                                                    break
                                            while True:
                                                up_sub_name = input("subject name:")
                                                psub_name = re.match("^[a-zA-Z]+$", up_sub_name)
                                                if not psub_name:
                                                    print("please enter a valid subject name")
                                                else:
                                                    break

                                            updatelist[4][0] = up_sub_code
                                            updatelist[4][1] = up_sub_name
                                    else:
                                        print("#" * 50)
                                        print("you have only", len(updatelist), "subject please enter valid choice")
                                        print("#" * 50)
                                        choicefuc()

                                    print(updatelist)
                                    savefile(student)
                                    choicefuc()

                            else:
                                print("Roll not found")

                        case 7:
                            while True:
                                up_email = input('Enter the updated email:')
                                pup_email = re.match(r'\b[a-z0-9._]+@[a-z0-9.]+\.[a-z]{2,3}\b', pup_email)
                                if not pup_email:
                                    print("please enter a valid email")
                                else:
                                    break

                            for i in student:
                                if i[1] == roll_id:
                                    i[3] = up_email
                                    print("updated")
                                    savefile(student)
                                    choicefuc()

            case 6:
                print("1.sort by roll no")
                print("2.sort by name")
                print("3.sort by department")
                print("0.exit")
                while True:

                    n = input("enter sort choice")
                    pn = re.match("^[0-3]+$", n)
                    if not pn:
                        print("please enter the numeric and right menu")
                    else:
                        break
                n1 = int(n)
                match n1:
                    case 0:
                        choicefuc()
                    case 1:
                        data = csv.reader(open('sample.csv'), delimiter=',')
                        head = next(data)
                        # sort data on the basis of roll no
                        dat = sorted(data, key=operator.itemgetter(1))
                        for i in dat:
                            print(i)
                        # print('After sorting:')
                        choicefuc()
                    case 2:
                        data = csv.reader(open('sample.csv'), delimiter=',')
                        head = next(data)
                        # sort data on the basis of name
                        data1 = sorted(data, key=operator.itemgetter(2))

                        # displaying sorted data
                        print('After sorting:')
                        print(data1)
                        choicefuc()
                    case 3:
                        data = csv.reader(open('sample.csv'), delimiter=',')
                        head = next(data)

                        # sort data on the basis of department
                        data2 = sorted(data, key=operator.itemgetter(5))

                        # displaying sorted data
                        print('After sorting:')
                        print(data2)
                        choicefuc()
            case 0:
                exit()
    except ValueError:
        print("Please enter only numeric")
        print("#" * 50)
    except AttributeError:
        print("attribute assignment or reference fails")
    except ImportError:
        print("Import module properly")
    except IndexError:
        print("list index out of range")
    except KeyError:
        print("Key not found")
    except NameError:
        print("variable is not found in local or global scope")
    except SyntaxError:
        print("Invalid syntax")
    except TypeError:
        print("function or operation is applied to an object of incorrect type")
    except EOFError:
        print("End of line")
    except FileNotFoundError:
        print("File not created..")
        print()


def choicefuc():
    print("#" * 50)
    print("Menu For Student Management System")
    print("1.Add student detail")
    print("2.Display all student list")
    print("3.Search student")
    print("4.Delete student detail")
    print("5.Update student detail")
    print("6.Sorting (Roll no, Name, department, semester, Age)")
    print("0.exit")
    print("#" * 50)
    try:
        choice = int(input("Enter your choice : "))
        print("#" * 50)
        if choice <= 6:
            cases(choice)
        else:
            print("#" * 40)
            print("please enter the correct no")
            print("#" * 40)
            choicefuc()
    except ValueError:
        print("#" * 50)
        print("enter the num of list")
        print("#" * 50)
        choicefuc()


choicefuc()
