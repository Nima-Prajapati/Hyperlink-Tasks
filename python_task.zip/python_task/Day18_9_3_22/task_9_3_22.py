"""
Today's python task (9 Mar, 2022)

Task 1: Student management system with RegEX validation
Task 2: Datetime module

"""

"""
Task 2: Datetime module
The date contains year, month, day, hour, minute, second, and microsecond.
The datetime module has many methods to return information about the date object.
-Commonly used classes in the datetime module are:
    date Class
    time Class
    datetime Class
    timedelta Class
"""
import datetime

# Get current date and time
current_datetime = datetime.datetime.now()
print("Current date and time :", current_datetime)
print("-" * 50)

# Get current date
current_date = datetime.date.today()
print(f"Current Date : {current_date}")
print("-" * 50)

# Get Attribute of a datetime modules
# dir() function to get a list containing all attributes of a module.
print(f"Attribute of a datetime modules : {dir(datetime)}")
print("-" * 50)

from datetime import date

# datetime.date class
d = datetime.date(2021, 2, 13)
print("year-month-day : ", d)
print("-" * 50)

# Get current date
print(f"Current date : {date.today()}")
print("-" * 50)

d = date(2021, 2, 28)
print(d)
print("-" * 50)

# Get date from a timestamp
# A Unix timestamp is the number of seconds between a particular date and January 1, 1970 at UTC. You can convert a
#   timestamp to date using fromtimestamp() method.
timestamp = date.fromtimestamp(1646826001)
print("Date : ", timestamp)
print("-" * 50)

# Print today's year, month and day
today = date.today()
print("Current year : ", today.year)
print("Current month : ", today.month)
print("Current day : ", today.day)
print("-" * 50)

from datetime import time

# time(hour=0, minute=0, second=0)
a = time()
print("Current time :", a)
# op:Current time : 00:00:00
print("-" * 50)

# # time(hour, minute and second)
b = time(5, 35, 20)
print("Time : ", b)
print("-" * 50)

c = time(hour=17, minute=35, second=20)
print("Time : ", c)
print("-" * 50)

# # time(hour, minute, second, microsecond)
d = time(17, 35, 20, 564856)
print("Time : ", d)
print("-" * 50)

# Print hour, minute, second and microsecond
e = time(17, 35, 20, 564856)
print("Hour : ", e.hour)
print("Minute : ", e.minute)
print("Second : ", e.second)
print("Microsecond :", e.microsecond)
print("-" * 50)

# datetime.datetime
from datetime import datetime, date, timedelta

# datetime(year, month, day)
a = datetime(2021, 6, 25)
print(a)

# datetime(year, month, day, hour, minute, second, microsecond)
b = datetime(2021, 6, 25, 20, 25, 1, 542682)
print(b)
print(b.year)
print(b.month)
print("Hour : ", b.hour)
print("Minute : ", b.minute)
print("Timestamp : ", b.timestamp())
print("-" * 50)

d1 = date(year=2022, month=1, day=14)
d2 = date(year=2021, month=12, day=31)
d3 = d1 - d2
print(d3)
print(type(d3))
print("-" * 50)

d1 = datetime(year=2022, month=1, day=14, hour=7, minute=7, second=7)
d2 = datetime(year=2021, month=12, day=31, hour=8, minute=8, second=8)
d3 = d1 - d2
print(d3)
print(type(d3))
print("-" * 50)

# A timedelta object represents the difference between two dates or times.
# Difference between two timedelta objects
d1 = timedelta(weeks=2, days=14, hours=7, minutes=7, seconds=7)
d2 = timedelta(days=4, hours=8, minutes=8, seconds=8)
d3 = d1 - d2
print("Difference between two timedelta objects : ", d3)
print(type(d3))
print("-" * 50)

# Printing negative timedelta object
d1 = timedelta(seconds=33)
d2 = timedelta(seconds=54)
d3 = d1 - d2
print("Printing negative timedelta object : ", d3)
print(abs(d3))
print(type(d3))
print("-" * 50)

# Time duration in seconds
d1 = timedelta(days=4, hours=8, seconds=8, microseconds=233423)
print("Total seconds : ", d1.total_seconds())
print("-" * 50)

"""
 Formate datetime:
    mm/dd/yyyy in the US, whereas dd/mm/yyyy is more common in the UK.
    
strftime():
- datetime object to string
The strftime() method is defined under classes date, datetime and time. The method creates a formatted string from a given date, datetime or time object.
The datetime object has a method for formatting date objects into readable strings.
The method is called strftime(), and takes one parameter, format, to specify the format of the returned string:
"""
"""
%a	Weekday, short version	e.g Wed	
%A	Weekday, full version	e.g.Wednesday	
%w	Weekday as a number 0-6, 0 is Sunday	eg.3	
%d	Day of month 01-31	eg.31	
%b	Month name, short version	eg.Dec	
%B	Month name, full version	eg.December	
%m	Month as a number 01-12	 eg.12	
%y	Year, short version, without century	eg.18	
%Y	Year, full version	 eg.2018	
%H	Hour 00-23	 eg.17	
%I	Hour 00-12	  eg.05	
%p	AM/PM	 eg.PM	
%M	Minute 00-59	eg.41	
%S	Second 00-59	eg.08	
%f	Microsecond 000000-999999	eg.548513	
%z	UTC offset	 eg.+0100	
%Z	Timezone	 eg.CST	
%j	Day number of year 001-366	 eg.365	
%U	Week number of year, Sunday as the first day of week, 00-53	 eg.52	
%W	Week number of year, Monday as the first day of week, 00-53	  eg.52	
%c	Local version of date and time	 eg. Mon Dec 31 17:41:00 2018	
%C	Century	 eg.20	
%x	Local version of date	 eg.12/31/18	
%X	Local version of time	 eg.17:41:00	
%%	A % character	 eg.%	
%G	ISO 8601 year	 eg.2018	
%u	ISO 8601 weekday (1-7)	 eg.1	
%V	ISO 8601 weeknumber (01-53)	  eg.01
"""

from datetime import datetime

# current date and time
now = datetime.now()

# %Y - year [0001,..., 2018, 2019,..., 9999]
# %m - month [01, 02, ..., 11, 12]
# %d - day [01, 02, ..., 30, 31]
# %H - hour [00, 01, ..., 22, 23
# %M - minute [00, 01, ..., 58, 59]
# %S - second [00, 01, ..., 58, 59]

t = now.strftime("%H:%M:%S %A %a")
print(t)
print("-" * 50)

t = now.strftime("%m + %d + %y  %H - %M - %S ")
print(t)
print("-" * 50)

"""
strptime : 
The strptime() method creates a datetime object from a given string (representing date and time).
"""

# date_string = "11 Mar, 2022"
# print("Date_string : ",date_string)
# date_obj = datetime.strptime(date_string, "%d %B, %Y")
# print("date object : ",date_obj)

#
# TimeZone
from datetime import datetime
import pytz

#
# local = datetime.now()
# print("Local : ",local.strftime("%d/%m/%Y, %H:%M:%S"))
#
# # tz_NY =


