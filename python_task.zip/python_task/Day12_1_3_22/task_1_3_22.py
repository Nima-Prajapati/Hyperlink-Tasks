"""
python task (1 Mar, 2022)

Task 1: Class
Task 2: Inheritance
Task 3: Multiple Inheritance
Task 4: Operator Overloading
"""

"""
Task 1: Class
"""
class Employee:
    "This is employee class"
    def __init__(self,emp_no,name,department,salary):
        self.emp_no = emp_no
        self.name = name
        self.department = department
        self.salary = salary

    #getter method
    def getInfo(self):
        print(f"Employee Number : {self.emp_no}")
        print(f"Employee Name : {self.name}")
        print(f"Employee Department : {self.department}")
        print(f"Employee Salary : {self.salary}")

    #setter method
    def setSalary(self,salary):
        self.__salary = salary

print(Employee.__doc__)
emp = Employee(1,'nima','it',5000)
emp.getInfo()
print("-"*80,end="\n\n")

"""
Task 2: Inheritance
"""
# single Inheritance
class Person:
  def __init__(self, fname, lname):
    self.firstname = fname
    self.lastname = lname

  def printname(self):
    print(self.firstname, self.lastname)

class Student(Person):
  def __init__(self, fname, lname):
    Person.__init__(self, fname, lname)

x = Student("Reshma", "P")
x.printname()


# class Polygon:
#     def __init__(self,no_of_sides):
#         self.n = no_of_sides
#         self.sides = [0 for i in range(no_of_sides)]
#
#     def inputSides(self):
#         self.sides = [float(input("Enter sides "+ str[i+1]+" : "))
#              for i in range(self.n)
#         ]
#
#         self.sides = []
#         for i in range(self.n):
#             a = float(input("Enter sides "+ str(i+1)+ " :"))
#             self.sides.append(a)
#
#     def displaySides(self):
#         for i in range(self.n):
#             print("Sides",i+1,"is",self.sides[i])
#
# class Triangle(Polygon):
#     def __init__(self):
#         Polygon.__init__(self,3)
#
#     def findArea(self):
#         a,b,c = self.sides
#
#         s = (a+b+c)/2
#
#         area = (s*(s-a)*(s-b)*(s-c)) ** 0.5
#
#         print("The area of triangle is %0.2f"% area)
#
#
# t = Triangle()
#
# t.inputSides()
# t.displaySides()
# t.findArea()

print("-"*80,end="\n\n")
# Multilevel Inheritance
class A:
    def getInfoA(self):
        print("I am class A")

class B(A):
    def getInfoB(self):
        print("I am class B")

class C(B):
    def getInfoC(self):
        print("I am class C")

obj = C()
obj.getInfoA()
obj.getInfoB()
obj.getInfoC()
print(C.mro())
print("-"*80,end="\n\n")


# Hierarchical Inheritance
# Base class
class Parent:
    def func1(self):
        print("This function is in parent class.")

# Derived class1
class Child1(Parent):
    def func2(self):
        print("This function is in child 1.")

# Derivied class2
class Child2(Parent):
    def func3(self):
        print("This function is in child 2.")


# Driver's code
object1 = Child1()
object2 = Child2()
object1.func1()
object1.func2()
object2.func1()
object2.func3()
print("-"*80,end="\n\n")

# Hybrid Inheritance: Inheritance consisting of multiple types of inheritance is called hybrid inheritance.
class School:
    def func1(self):
        print("This function is in school.")

class Student1(School):
    def func2(self):
        print("This function is in student 1. ")

class Student2(School):
    def func3(self):
        print("This function is in student 2.")

class Student3(Student1, School):
    def func4(self):
        print("This function is in student 3.")


# Driver's code
object = Student3()
object.func1()
object.func2()
print("-"*80,end="\n\n")




"""
Task 3: Multiple Inheritance
A     B
 \    /
    c
"""
import math
class Circle:
    def __init__(self, radius):
        self.radius = radius

    def areaOfCircle(self):
        print(f"Area of circle is :{math.pi * (self.radius * self.radius):.2f}")

class Rectangle:
    def __init__(self,l,w):
        self.length = l
        self.width = w

    def areaOfRectangle(self):
        print(f"Area of Rectangle is :{(self.length * self.width)}")

class AreaCalculator(Circle,Rectangle):
    def __init__(self,r,l,w):
        # using class name provide argument to the super class
        Circle.__init__(self,r)
        Rectangle.__init__(self,l,w)

        # super().__init__(self,r)
        # Rectangle.__init__(self,l,w)

ac = AreaCalculator(5,45,12)
ac.areaOfCircle()
ac.areaOfRectangle()
print("-"*80,end="\n\n")



"""
Task 4: Operator Overloading
"""
class A:
    def __init__(self, x=0,y=0):
        self.x = x
        self.y = y

    def __str__(self):
        return f"Overloading : {self.x}, {self.y}"
        # return f"Overloading : {self.x} == {self.y}"
        #op:Overloading : 2 == 3

    # Overloading + operator
    def __add__(self, other):
        x = self.x + other.x
        y = self.y + other.y
        return A(x,y)

    def __sub__(self, other):
        x = self.x - other.x
        y = self.y - other.y
        return A(x,y)

    def __mul__(self, other):
        x = self.x - other.x
        y = self.y - other.y
        return A(x, y)

    def __mod__(self, other):
        x = self.x - other.x
        y = self.y - other.y
        return A(x, y)

    # def __pow__(self, power, modulo=None):
    #     x = self.x - power.y
    #     return x

    def __gt__(self, other):
        if (self.x > other.y):
            return True
        else:
            return False

    def __lt__(self, other):
        if (self.x < other.y):
            return "ob1 is less than ob2"
        else:
            return "ob2 is less than ob1"

    def __eq__(self, other):
        if (self.x == other.y):
            return "Both are equal"
        else:
            return "Not equal"


obj1 = A(2,5)
obj2 = A(5,3)
print("Addition :",obj1 + obj2)
print("subtraction :",obj1 - obj2)
print("Multiplication :",obj1 * obj2)
print("Module :",obj1 % obj2)
obj3 = A(2)
# print("Power : ", obj3 ** 2)
if obj1 > obj2:
    print("ob1 is greater than ob2")
else:
    print("ob2 is greater than ob1")

print("Less then: ",obj1 < obj2)
print("Equal: ",obj1 == obj2)
print("-"*80,end="\n\n")


class LenExample:
    def __init__(self, item):
        self.item = item
    def __len__(self):
        return len(self.item)
len_instance = LenExample([1, 2, 3])

print(len(len_instance))


# import string
# class Str:
#     def __init__(self, string_):
#         self.string = string
#     def __add__(self, string2):
#         return self.string_ + string2
# instance1 = Str("Hello")
# print(instance1 + " World")



"""
Setter Getter
"""







#

#
#
# class grandfather:
#     print("i am grand fathe")
#     def sum(self,a,b):
#         print(a+b)
#
# class father(grandfather):
#     print("i am father")
#     def sum(self,a,b,c=300):
#         print(a+b+c)
#
# class son(father):
#     print("i am son")
#
#
# sonobj=son()
#
# sonobj.sum(10,20)
# sonobj.sum(100,200)
#
#
#
# class price:
#     def rs(self,rupee,name):
#         print(name,"car have this price ",rupee)
#
# class cars:
#     def engine(self,name):
#         print("this car",name, "have engine")
#
#     def color(self,colors):
#         print("this car hav",colors)
#
# class audi(cars,price):
#     def name(self):
#
#         print("my name is audi")
#
# class bmw(cars,price):
#     def name(self):
#          print("my name is bmw")
#
# abij=audi()
# abij.engine("audi")
# abij.color("red")
# abij.rs(50000,'audi')
#
# print("-"*50)
#
# bobj=bmw()
# bobj.engine("BMW")
# bobj.color("black")
# bobj.rs(100000,"BMW")
