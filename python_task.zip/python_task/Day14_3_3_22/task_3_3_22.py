"""
Task 1: Json Module
"""


import csv,json

# field_names = ['name', 'gender', 'subject']
# rows = [
#     {'name':'sagar', 'gender': 'male', 'subject': {'Code1':'java','Code2':'PYTHON'}},
#     {'name':'jay', 'gender': 'male', 'subject': {'Code1':'Python'}},
#     {'name':'kajal', 'gender': 'female', 'subject': {'Code1':'C','Code2':'C++'}},
# ]
# with open('ex_json.csv', 'w',encoding='UTF8',newline='') as csvfile:
#     writer = csv.DictWriter(csvfile, fieldnames=field_names)
#     writer.writeheader()
#     writer.writerows(rows)
#
# with open('ex_json.csv','r') as f:
#     reader = csv.DictReader(f)
#
#     for row in reader:
#         subjects = json.loads(row['subject'].replace("'",'"'))
#         print(type(subjects))
#
#         print(f"Student name is : {row.get('name')}")
#         print(f"Student gender is: {row.get('gender')}")
#         print("Subjects details:")
#         for key,value in subjects.items():
#             print(f"\tCode: {key} - Name: {value}")
#         print("-"*50)


# Convert from Python to JSON
dict1 = [
    {
        "name":"Test",
        "age":20,
        "gender":"Female",
        "address":"Ahmedabad, Gujarat, India",
        "phone":[
            {
                "type":"Mobile",
                "phone":"+91123456789"
            },
            {
                "type":"Telephone",
                "phone":"+07926813723"
            }
        ],
        "subjects":{"Code1":"Python","Code2":"Java"}
    },
{
        "name":"Test2",
        "age":25,
        "gender":"Male",
        "address":"Ahmedabad, Gujarat, India",
        "phone":[
            {
                "type":"Mobile",
                "phone":"+91123456789"
            },
            {
                "type":"Telephone",
                "phone":"+07926813723"
            }
        ],
        "subjects":{"001":"DBMS","002":"OS"}
    }
]
print(type(dict1))
print("-"*50)

# #Convert from Python to JSON
# str1 = json.dumps(dict1, indent=4,separators=(",","="))
#
# print(type(str1))
# print(str1)
# print("-"*50)
#
#
# str2 = json.dumps(dict1, indent=4)
#
# print(type(str2))
# print(str2)
# print("-"*50)
#
# # some JSON:Parse JSON - Convert from JSON to Python
# str3 = json.loads(str2)
# print(type(str3))
# print(str3)

tuple1 = ("apple", "banana", "cherry", "apple", "cherry")
print(type(tuple1))
str1 = json.dumps(tuple1,indent=3)
print(type(str1))
print(str1)

str2 = json.loads(str1)
print(type(str2))
print(str2)

