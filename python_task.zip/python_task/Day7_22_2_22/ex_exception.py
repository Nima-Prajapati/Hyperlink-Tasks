"""
python task (22 Feb, 2022):
Task 2: Exception & Error
"""

# 1 - syntax error
amt = 100
# if(amt>200)
#     print("You are eligible to purchase Dsa Self Paced")
# op:SyntaxError: invalid syntax

# 2 - Logical error
# a = amt / 0
# print(a)
# op:ZeroDivisionError: division by zero

# 3 - indentation error
# if(a<3):
# print("abc")
# op:IndentationError: expected an indented block

# 4 - exception MemoryError :Raised when an operation runs out of memory.
# def fact(a):
#     factors = []
#     for i in range(1, a + 1):
#         if a % i == 0:
#             factors.append(i)
#     return factors
# num = 600851475143
# print(fact(num))
# op:


# 5 - exception AssertionError : Raised when an assert statement fails.
# assert False, 'The assertion failed'
# assert 5 > 10, "5 is small"  #if--else
# op:AssertionError: The assertion failed

# 6 - OverflowError:	Raised when the result of an arithmetic operation is too large to be represented.
import math
# print(math.exp(1000))
# op: OverflowError: math range error

# 7 - exception ImportError:Raised when the imported module is not found.
# import module_does_not_exist
# op:ModuleNotFoundError: No module named 'module_does_not_exist'
# from exceptions import Userexception

# 8 - exception IndexError:Raised when the index of a sequence is out of range.
# array = [ 0, 1, 2 ]
# print (array[3])
# op:IndexError: list index out of range

# 9 - exception KeyError:Raised when a key is not found in a dictionary.
# array = { 'a':1, 'b':2 }
# print (array['c'])
# op:KeyError: 'c'

# 10 - exception NameError:Raised when a variable is not found in local or global scope.
# def func():
#     print(ans)
# func()
# op:NameError: name 'ans' is not defined

"""
11 - exception ZeroDivisionError:Raised when the second operand of division or modulo operation is zero.
"""
# print (1/0)
# op:ZeroDivisionError: division by zero

"""
12 - FileNotFoundError:
"""
# with open("myfile.txt") as f:
#     for line in f:
#         print(line,end="")

"""
13 - AttributeError:	Raised when attribute assignment or reference fails.
"""
# X = 10
# X.append(6)
# op:AttributeError: 'int' object has no attribute 'append'

# built-in exceptions :
# AssertionError:	Raised when an assert statement fails.
# AttributeError:	Raised when attribute assignment or reference fails.
# EOFError:	Raised when the input() function hits end-of-file condition.
# FloatingPointError:	Raised when a floating point operation fails.(not work in python3)
# GeneratorExit:	Raise when a generator's close() method is called.
# ImportError:	Raised when the imported module is not found.
# IndexError:	Raised when the index of a sequence is out of range.
# KeyError:	Raised when a key is not found in a dictionary.
# KeyboardInterrupt:	Raised when the user hits the interrupt key (Ctrl+C or Delete).
# MemoryError:	Raised when an operation runs out of memory.
# NameError:	Raised when a variable is not found in local or global scope.
# NotImplementedError:	Raised by abstract methods.
# OSError:	Raised when system operation causes system related error.
# OverflowError:	Raised when the result of an arithmetic operation is too large to be represented.
# ReferenceError:	Raised when a weak reference proxy is used to access a garbage collected referent.
# RuntimeError:	Raised when an error does not fall under any other category.
# StopIteration:	Raised by next() function to indicate that there is no further item to be returned by iterator.
# SyntaxError:	Raised by parser when syntax error is encountered.
# IndentationError:	Raised when there is incorrect indentation.
# TabError:	Raised when indentation consists of inconsistent tabs and spaces.
# SystemError:	Raised when interpreter detects internal error.
# SystemExit:	Raised by sys.exit() function.
# TypeError:	Raised when a function or operation is applied to an object of incorrect type.
# UnboundLocalError:	Raised when a reference is made to a local variable in a function or method, but no value has been bound to that variable.
# UnicodeError:	Raised when a Unicode-related encoding or decoding error occurs.
# UnicodeEncodeError:	Raised when a Unicode-related error occurs during encoding.
# UnicodeDecodeError:	Raised when a Unicode-related error occurs during decoding.
# UnicodeTranslateError:	Raised when a Unicode-related error occurs during translating.
# ValueError:	Raised when a function gets an argument of correct type but improper value.
# ZeroDivisionError:	Raised when the second operand of division or modulo operation is zero.

# try----except
# try:
#     print("Run this code")
# except:
#     print("Run this code if an exception occurs")
# else:
#     print("Run this code if no exception occurs")
# print("+-"*40)


"""
Task 3: Exception Handling
"""
# 1 -
# put unsafe operation in try block
# try:
#     a = int(input("Enter a:"))
#     b = int(input("Enter b:"))
#     c = a/b
#     print("a/b = %d" % c)
# # if error occur then it goes in except block
# except:
#     print("Can't divide with zero")
# # final code in finally block
# finally:
#     print("Finally executed")

# second way
# try:
#     a = int(input("Enter a:"))
#     b = int(input("Enter b:"))
#     c = a/b
#     print("a/b = %d"%c)
# # Using Exception with except statement. If we print(Exception) it will return exception class
# except Exception:
#     print("can't divide by zero")
#     print(Exception)
# else:
#     print("I am else block")
print("+-"*40)


# 2 - Built-in exception
try:
    a = 10/0
    print(a)
except ArithmeticError:
        print ("This is raising an arithmetic exception.")
else:
    print ("Success.")
finally:
    print("Arithmetic error example")
print("+-"*40)

# 3
# try:
#     num = int(input("Enter a number: "))
#     assert num % 2 == 0
# except:
#     print("Not an even number!")
# else:
#     print("It's an even number")
# print("+-"*40)


# 4 - dictionary example with try catch in python
# dict1 = {1 : 'one',2: 'Two',3 : 'Three'}
# dict1 = {"one":1, "two":2}
# w = input("Enter a word: ")
# try:
#     if dict1[w]:
#         print("Found")
# except KeyError:
#     # print(e)
#     print("That word is not a key in the dictionary, try again")
# else:
#     print("That word is a key in the dictionary")



# data = {"one": 1, "Two": 2, "words": 3}
# # make all keys lowercase
# data = {k.lower(): v for k, v in data.items()}
# while True:
#     w = input("Enter a word: ")
#     if data.get(w.lower()):
#         print("That word is a key in the dictionary")
#     else:
#         print("That word is not a key in the dictionary, try again")
#         break

# 5 - LookupError
# try:
#     a = [1, 2, 3]
#     print (a[3])
# except LookupError:
#     print ("Index out of bound error.")
# else:
#     print ("Success")

# 6 - FloatingPointError





"""
Task 4: user-defined exception
"""
# # 1
try:
    print(1/0)
except ZeroDivisionError:
    print("Division error")
print("+-"*40)
#
# # 2
class CustomError(Exception):
    pass
try:
    raise CustomError
except CustomError:
    print("Custom error...")
print("+-"*40)

# 3
# dict1 = {1 : 'one',2: 'Two',3 : 'Three'}
# w = int(input("Enter a numeric key: "))
# try:
#     if dict1[w]:
#         print("Found")
# except KeyError as e:
#     print(e)
#     # print("That word is not a key in the dictionary, try again")
# else:
#     print("That word is a key in the dictionary")

# # value error
# try:
#     x = int(input("Please enter a number :"))
# except ValueError:
#     print("That was no valid number..")


# 4
# define Python user-defined exceptions

class Error(Exception):
    """Base class for other exceptions"""
    pass
class ValueTooSmallError(Error):
    """Raised when the input value is too small"""
    pass
class ValueTooLargeError(Error):
    """Raised when the input value is too large"""
    pass

# you need to guess this number
number = 10
# user guesses a number until he/she gets it right
while True:
    try:
        i_num = int(input("Enter a number: "))
        if i_num < number:
            raise ValueTooSmallError
        elif i_num > number:
            raise ValueTooLargeError
        break
    except ValueTooSmallError:
        print("This value is too small, try again!")
        print()
    except ValueTooLargeError:
        print("This value is too large, try again!")
        print()

print("Congratulations! You guessed it correct.")