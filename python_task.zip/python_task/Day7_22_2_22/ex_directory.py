"""
python task (22 Feb, 2022):
Task 1: Directory
"""

# Directory : collection of files and folders.A directory or folder is a collection of files and subdirectories.
# Python has the os module that provides us with many useful methods to work with directories (and files as well).

import os
# The getcwd() method displays the current working directory.
print("Get current directory : ",os.getcwd())

print("get byte object : ",os.getcwdb())


"""
The mkdir() Method
You can use the mkdir() method of the os module to create directories in the current directory. You need to supply an argument to this method which contains the
name of the directory to be created.
"""
# print("Make directory : ",os.mkdir('testingdir'))
# print("Make directory : ",os.mkdir('testingdir2'))

"""
The chdir() Method
You can use the chdir() method to change the current directory. The chdir() method takes an argument, which is the name of the directory that
you want to make the current directory.
"""

# print("change directory : ",os.chdir('package'))

# All files and sub-directories inside a directory can be retrieved using the listdir() method.
print("List of directory : ",os.listdir())

"""
The rename() method can rename a directory or a file.the rename() method takes in two basic arguments: the old name as the first argument
and the new name as the second argument.
"""
# os.rename('testingdir','testingdir1')

"""
A file can be removed (deleted) using the remove() method. The rmdir() method deletes the directory, which is passed as an argument in the method.
Before removing a directory, all the contents in it should be removed.
"""
# os.rmdir('testingdir2')



"""
os.close():This function closes the associated file.
"""
# import os
print("os.close()")
f = os.open("demofile1.txt",os.O_WRONLY)
os.close(f)
print("-"*80, end="\n\n")




"""
os.access()
"""




