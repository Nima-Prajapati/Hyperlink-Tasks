"""
Today's python task (25 Feb, 2022)

Task 1: Working with CSV module
	a. Read data from CSV file
	b. Write data into CSV file (Single/Multiple row)
	c. Read data using DictReader()
	d. Write data using DictWriter()


Task 2: Build a simple Student Management System With File Handling (CSV) and perform all previous constrain.

"""
import csv


"""
a. Read data from CSV file
"""
# try:
#     f = open('studentcsv.csv','r')
#     reader = csv.reader(f)
#     headers = next(reader, None) #1st line or header skip
#     print(headers)
#
#     # lst = []
#     # for row in reader:
#     #     for (h,x) in zip(headers,row)
#     #         lst.append({h:x})
#     # print(lst)
#
#     print("#"*50)
#     data = [{h:x for (h,x) in zip(headers,row)} for row in reader]
#     print(data)
# except Exception as e:
#     print("Error : ",e)
# finally:
#     f.close()


"""
b. Write data into CSV file (Single/Multiple row)
"""
# header = ['Roll no','Name','Gender','Age']
# data = [1,'Seema','Female',22]
#
# with open ('studentcsv.csv', 'w') as f:
#     writer = csv.writer(f)
#
#     writer.writerow(header)
#
#     writer.writerow(data)
#     print("Single data write successfully...")

# Multiple
# header = ['Roll no','Name','Gender','Age']
# data = [
#     [1,'Reshma','Female',27],
#     [2,'Jaguu','Male',20]
# ]
# with open('studentcsv.csv','w',encoding='UTF8',newline='') as f:
#     writer = csv.writer(f)
#
#     writer.writerow(header)
#     writer.writerow(data)


"""
c. Read data using DictReader()
"""
with open('studentcsv.csv') as f:
    reader = csv.DictReader(f)

    for row in reader:
        print(row)
        # if row['Roll no']=='1':
            # print(row['name'])



"""
d. Write data using DictWriter()
"""
# # header
# fields = ['Roll no','name','gender','age']
# # data
# mydict =[{'Roll no': '1', 'name': 'sagar', 'gender': 'male', 'age': '2'},
#          {'Roll no': '2', 'name': 'kajal', 'gender': 'female', 'age': '2'},
#          {'Roll no': '3', 'name': 'jay', 'gender': 'male', 'age': '2'},
#          {'Roll no': '4', 'name': 'urja', 'gender': 'female', 'age': '2'},
#          {'Roll no': '5', 'name': 'sahil', 'gender': 'male', 'age': '2'},
#          {'Roll no': '6', 'name': 'md', 'gender': 'male', 'age': '2'}]
#
# with open('studentcsv.csv','w',encoding='UTF8',newline='') as f:
#     writer = csv.DictWriter(f, fieldnames=fields)
#
#     # writing headers (field names)
#     writer.writeheader()
#
#     # writing data rows
#     writer.writerows(mydict)
#

