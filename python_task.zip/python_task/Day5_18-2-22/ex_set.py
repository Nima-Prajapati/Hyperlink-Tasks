# Python Task 18-2-22

# Set : Sets are used to store multiple items in a single variable.A set is a collection which is unordered, unchangeable*, and unindexed.do not allow duplicate values.
#
# 1- Add a list of elements to a set
#     a. sample_set = {"Yellow", "Orange", "Black"} and sample_list = ["Blue", "Green", "Red"]
sample_set = {"Yellow", "Orange", "Black"}
sample_list = ["Blue", "Green", "Red"]
# update()	Update the set with the union of this set and others
sample_set.update(sample_list)
print("Q1 :",sample_set)

# add()	Adds an element to the set
for i in sample_list:
    sample_set.add(i)
print("Q1 : ",sample_set)
print("+-"*40)
# op :Q1 :  {'Yellow', 'Red', 'Black', 'Orange', 'Blue', 'Green'}


# 2- Return a new set of identical items from two sets
#     a. set1 = {10, 20, 30, 40, 50} and set2 = {30, 40, 50, 60, 70}
# intersection()	Returns a set, that is the intersection of two other sets
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}
print("Q2 : ",set1.intersection(set2))
print("+-"*40)
# op:Q2 :  {40, 50, 30}


# 3- Get Only unique items from two sets
#     a. set1 = {10, 20, 30, 40, 50} and set2 = {30, 40, 50, 60, 70}
# union()	Return a set containing the union of sets
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}

print("Q3 : ",set1.union(set2))
print("+-"*40)
# op:Q3 :  {70, 40, 10, 50, 20, 60, 30}


# 4- Update the first set with items that don’t exist in the second set
#     a. set1 = {10, 20, 30} and set2 = {20, 40, 50}
# difference_update(): Removes the items in this set that are also included in another, specified set
set1 = {10, 20, 30}
set2 = {20, 40, 50}
set1.difference_update(set2)
print("Q4 : ",set1)
print("+-"*40)
# op :Q4 :  {10, 30}


# 5- Remove items from the set at once
#     a. Write a Python program to remove items 10, 30, 50 from the following set at once.
#     b. set1 = {10, 20, 30, 40, 50}
# difference_update()	Removes the items in this set that are also included in another, specified set
set1 = {10, 20, 30, 40, 50}
set1.difference_update({10, 30, 50})
print("Q5 : ",set1)
print("+-"*40)
# op:Q5 :  {40, 20}


# 6- Return a set of elements present in Set A or B, but not both
#     a. set1 = {10, 20, 30, 40, 50} and set2 = {30, 40, 50, 60, 70}
# symmetric_difference()	Returns a set with the symmetric differences of two sets
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}
print("Q6 : ",set1.symmetric_difference(set2))
print("+-"*40)
# op:Q6 :  {20, 70, 10, 60}


# 7- Check if two sets have any elements in common. If yes, display the common elements
#     a. set1 = {10, 20, 30, 40, 50} and set2 = {60, 70, 80, 90, 10}
# isdisjoint()	Returns whether two sets have a intersection or not
set1 = {10, 20, 30, 40, 50}
set2 = {60, 70, 80, 90, 10}
if set1.isdisjoint(set2):
  print("Two sets have no items in common")
else:
  print("Two sets have items in common")
  print("Q7 : ",set1.intersection(set2))
print("+-"*40)
# op:Q7 :  {10}


# 8- Update set1 by adding items from set2, except common items
#     a. set1 = {10, 20, 30, 40, 50} and set2 = {30, 40, 50, 60, 70}
# symmetric_difference_update()	inserts the symmetric differences from this set and another
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}

set1.symmetric_difference_update(set2)
print("Q8 : ",set1)
print("+-"*40)
# op:Q8 :  {70, 10, 20, 60}

# 9- Remove items from set1 that are not common to both set1 and set2
#     a. set1 = {10, 20, 30, 40, 50} and set2 = {30, 40, 50, 60, 70}
# intersection_update()	Removes the items in this set that are not present in other, specified set(s)
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}

set1.intersection_update(set2)
print("Q9 : ",set1)
print("+-"*40)
# op :{40, 50, 30}