# Python Task 18-2-22

# String : sequence of character
#
# 1- Create a string made of the first, middle and last character
str1 = "Jason"
print("Q1 String is : ",str1)
length = len(str1)
ans = str1[0]
middle = int(length/2)
ans += str1[middle]
ans += str1[length-1]
print("first,middle and last character : ",ans)
print("+-"*40)
# op : first,middle and last character :  Jsn
# ------------------------------------------------------------------------------------------------------------------------------------------------------------

# 2- Create a string made of the middle three characters
#     a. str1 = "JhonDipPeta"
#     b. str2 = "JaSonAy"
def middle_three_chars(str1):
    print("Q2 String is", str1)
    # get middle index number
    middle = int(len(str1) / 2)
    # string slicing to get result characters
    res = str1[middle - 1:middle + 2]
    print("Middle three chars are:", res)
middle_three_chars("JhonDipPeta")
middle_three_chars("JaSonAy")
print("+-"*40)
# op :Q2 String is JhonDipPeta
# Middle three chars are: Dip
# Q2 String is JaSonAy
# Middle three chars are: Son
#---------------------------------------------------------------------------------------------------------------------------

# 3- Append new string in the middle of a given string
#     a. Given two strings, s1 and s2. Write a program to create a new string s3 by appending s2 in the middle of s1.
def append_at_middle(s1, s2):
    print("Q3 Strings are", s1, s2)
    # middle index number of s1
    middle = int(len(s1) / 2)
    # get character from 0 to the middle index number from s1
    x = s1[:middle:]
    # concatenate s2
    x += s2
    # append remaining character from s1
    x += s1[middle:]
    print("After appending new string at middle:", x)
append_at_middle("JaSonAy", "John")


# str1 = 'JaSonAy'
# str2 = 'John'
# l = len(str1)//2
# str3 = str1[0:l] + str2 + str1[l::]
# print(str3)

print("+-"*40)
# op:Q3 Strings are JaSonAy John
# After appending new string at middle: JaSJohnonAy
# ---------------------------------------------------------------------------------------------------------------------

# 4- Create a new string made of the first, middle, and last characters of each input string
#     a. Given two strings, s1 and s2, write a program to return a new string made of s1 and s2’s first, middle, and last characters.
s1 = "JaSonAy"
s2 = "John"
def mix_string(s1, s2):
    # get first character from both string
    first_char = s1[0] + s2[0]
    # get middle character from both string
    s1_middle = s1[int(len(s1) / 2):int(len(s1) / 2) + 1]
    s2_middle = s2[int(len(s2) / 2):int(len(s2) / 2) + 1]
    middle_char = s1_middle + s2_middle
    # get last character from both string
    last_char = s1[len(s1) - 1] + s2[len(s2) - 1]
    # add all string
    ans = first_char + middle_char + last_char
    print("Q4 Mix String is: ", ans)

mix_string(s1, s2)


# s1 = "JaSonAy"
# s2 = "John"
# def fun(str1, str2):
#     l1 = int(len(str1) / 2)
#     l2 = int(len(str2) / 2)
#
#     S = str1[0] + str2[0] + str1[l1] + str2[l2] + str1[-1] + str2[-1]
#     return S


print("+-"*40)
# op:Q4 Mix String is  JJohyn
# --------------------------------------------------------------------------------------------------------------------------

# 5- Arrange string characters such that lowercase letters should come first
#     a. Given string contains a combination of the lower and upper case letters. Write a program to arrange the characters of a string so that
#     all lowercase letters should come first.
str1 = "HeLlo"
print('Q5 String:', str1)
lower_char = []
upper_char = []
for i in str1:
    if i.islower():
        # add lowercase characters to lower list
        lower_char.append(i)
    else:
        # add uppercase characters to lower list
        upper_char.append(i)

# Join both list
sorted_str = ''.join(lower_char + upper_char)
print('Q5 Result:', sorted_str)
print("+-"*40)
# op:Q5 String: HeLlo
# Q5 Result: eloHL
# -----------------------------------------------------------------------------------------------------------------------

# 6- Count all letters, digits, and special symbols from a given string
str1 = "P@yt2ho&#i5ne"
print("Q6 string : ",str1)
print(len(str1))
char_count = 0
digit_count = 0
symbol_count = 0
for i in str1:
    if i.isalpha():
        char_count += 1
    elif i.isdigit():
        digit_count += 1
    # if it is not letter or digit then it is special symbol
    else:
        symbol_count += 1

print("Chars =", char_count, "Digits =", digit_count, "Symbol =", symbol_count)
print("total counts of chars, Digits, and symbols \n")
print("+-"*40)
# op :
# ---------------------------------------------------------------------------------------------------------------------

#
# 7- Create a mixed String using the following rules
#     a.Given two strings, s1 and s2. Write a program to create a new string s3 made of the first char of s1, then the last char of s2,
#     Next, the second char of s1 and second last char of s2, and so on. Any leftover chars go at the end of the result.
str1 = "JaSon"
str2 = "Johnn"

s1_length = len(str1)
s2_length = len(str2)
# reverse s2
s2 = str2[::-1]
str3 = ""
# s1 ascending and s2 descending
for i in range(s1_length):
    str3 += str1[i]
    str3 += s2[i]

print("Q7 ans :",str3)

# 2
s3 =''
for i in range(len(str1)):
    s3+=str1[i]
    s3+=str2[-i-1]
print("Q7 Ans : ",s3)
print("+-"*40)
# ----------------------------------------------------------------------------------------------------------------------

# 8- String characters balance Test
#     a. s1 = "Yn" and s2 = "PYnative"
#     b. s1 = "Ynf" and s2 = "PYnative"
#     Note: For example, strings s1 and s2 are balanced if all the characters in the s1 are present in s2. The character’s position doesn’t matter.
s1 = "Ynf"
s2 = "PYnative"
balanced = True
for i in s1:
    if i in s2:
        continue
    else:
        balanced = False
print("Q8 ans : ",balanced)

# 2
s1 = "Yn"
s2 = "PYnative"
ans = True
for i in s1:
    if i in s2:
        ans = True
    else:
        ans = False
        break
print(ans)
print("+-"*40)
# op:Q8 ans :  False
# ------------------------------------------------------------------------------------------------------------------------

# 9- Find all occurrences of a substring in a given string by ignoring the case
#     a. Write a program to find all occurrences of “INDIA” in a given string ignoring the case.
#     B. str1 = "Welcome to USA. usa awesome, isn't it?"
str1 = "Welcome to USA. usa awesome, isn't it?"
sub_string = "INDIA"
# convert to lowercase
lower_str = str1.lower()
# count = lower_str.count(sub_string.lower())
count = lower_str.count(sub_string)
print("The count of INDIA is:", count)
print("+-"*40)
# op: The count of INDIA is: 0
# ------------------------------------------------------------------------------------------------------------------

# 10- Calculate the sum and average of the digits present in a string
#     A. str1 = "PYnative29@#8496"
str1 = "PYnative29@#8496"
total = 0
count = 0
for i in str1:
    if i.isdigit():
        total += int(i)
        count += 1
# avg = sum / count of digits
avg = total / count
print("Q10 Sum is:", total)
print("Average is :",avg)
print("+-"*40)
# op:Q10 Sum is: 38
# Average is : 6.333333333333333
# --------------------------------------------------------------------------------------------------------------

# 11- Write a program to count occurrences of all characters within a string
from collections import Counter
str1 = "INDIA"
count = Counter(str1)
print("Q11 Ans :",count)
# print("maximum occurence: ",count.get(" "))
print("+-"*40)
# op:Q11 Ans : Counter({'I': 2, 'N': 1, 'D': 1, 'A': 1})
# ------------------------------------------------------------------------------------------------------------------

# 12- Reverse a given string
str1 = "Welcome to USA."
rev = str1[::-1]
print("Q12 reverse : ",rev)
str1 = ''.join(reversed(str1))
print("Q12 reverse : ",str1)

# 2
str2 = str1[len(str1):: -1]
print(str2)
print("+-"*40)
# op:Q12 reverse :  .ASU ot emocleW
# --------------------------------------------------------------------------------------------

# 13- Find the last position of a given substring
#     a. Write a program to find the last position of a substring “John” in a given string.
#     b. str1 = "John is a data scientist who knows Python. John works at google."
str1 = "John is a data scientist who knows Python. John works at google."
print("String is:", str1)
index_occ = str1.rfind("John")
print("Q13 Last occurrence of John at:", index_occ)
print("+-"*40)
# op:String is: John is a data scientist who knows Python. John works at google.
# Q13 Last occurrence of John at: 43
# --------------------------------------------------------------------------------------------------

# 14- Split a string on hyphens
#     a. str1 = John-is-a-data-scientist
str1 = "John-is-a-data-scientist"
print("Q14 String is:", str1)
sub_strings = str1.split("-")
print("string is : ",sub_strings)
for i in sub_strings:
    print(i,)
print("+-"*40)
# op:Q14 String is: John-is-a-data-scientist
# string is :  ['John', 'is', 'a', 'data', 'scientist']
# John
# is
# a
# data
# scientist
# -----------------------------------------------------------------------------

# 15- Remove empty strings from a list of strings
#     a. str_list = ["Emma", "Jon", "", "Kelly", None, "Eric", ""]
str_list = ["Emma", "Jon", "", "Kelly", None, "Eric", ""]
while("" in str_list):
    str_list.remove("")
print("Q15 ans After removing empty string : ",str_list)
print("+-"*40)
# op :Q15 ans After removing empty string :  ['Emma', 'Jon', 'Kelly', None, 'Eric']
# ----------------------------------------------------------------------------

# 16- Remove special symbols / punctuation from a string
#     a. str1 = "/*Jon is @developer & musician"
str1 = "/*Jon is @developer & musician"
print("Q16 string is ", str1)
punc = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
for i in str1:
    if i in punc:
        str1 = str1.replace(i, "")
print("The string after punctuation: " ,str1)

# 2
# import string
# str1 = "/*Jon is @developer & musician"
# str1 = str1.translate(str.maketrans('', '', string.punctuation))
# print(str1)
print("+-"*40)
# op:Q16 string is  /*Jon is @developer & musician
# The string after punctuation:  Jon is developer  musician
# ----------------------------------------------------------------------------------------------

# 17- Removal all characters from a string except integers
#     a. str1 = 'I am 25 years and 10 months old'
str1 = 'I am 25 years and 10 months old'
print("Q17 string is : ", str1)
import re  #regex
numeric_string = re.sub("[^0-9]", "", str1)
new_str = re.sub("\D", "", str1)
print(numeric_string)
print(new_str)

# 2
digits = ''
for i in str1:
    if i.isnumeric():
        digits+=i
print(digits)
print("+-"*40)
# op:2510
# ------------------------------------------------------------------------------------------------

# 18- Find words with both alphabets and numbers (use any)
#     a. str1 = "John30 is Data scientist50 and AI Expert"
str1 = "John30 is Data scientist50 and AI Expert"
print("Q18 string :",str1)
ans = re.findall(r'(?:\d+[a-zA-Z]+|[a-zA-Z]+\d+)', str1)
print("Words with alphabets and numbers : " + str(ans))

# 2
str1 = str1.split(' ')
for i in str1:
    for j in i:
        if j.isnumeric():
            print(i)
            break
print("+-"*40)
# op:Q18 string : John30 is Data scientist50 and AI Expert
# Words with alphabets and numbers : ['John30', 'scientist50']
# --------------------------------------------------------------------------------------------------

# 19- Replace each special symbol with # in the following string
# a. str1 = '/*Jon is @developer & musician!!'
import string as st
str1 = '/*Jon is @developer & musician!!'
print("Q19 String is : ",str1)
replace = '#'
# string.punctuation to get the list of all special symbols
for i in st.punctuation:
    str1 = str1.replace(i, replace)
print("The strings after replacement : ", str1)

# 2
from string import punctuation
for i in punctuation:
    str1 = str1.replace(i, '#')

print( str1)
print("+-"*40)







# # str1 = "He" \
# #        "llo"
# # str2 = 'Hello'
# # str3 = '''Hello'''
# # str4 = """He
# # llo"""
# str1 = "Hello"
# str2 = ('Hello' 'world')
# print(str1[1:3])
# print(str1 * 3)
# print(str2)
#
# print('''Hello , World's !''')
# print("Hello World's")
# print('Hello "World"')
# print("Hello \"World\"")
# print('Hell\'o "World"')
# print(3*'hello')
#
# # \n - new line,
# print('c:\docs\nabc')
# print(r'c:\docs\nabc')
# print("C:\\Python3\\lib")
# print("C:\\\\Python3\\\\lib")
#
# print("Hello\t World")
# print("Hello\n World")
#
# print("Hell{}' 'Wor{}d".format('0','l'))
# print("{1}, {2} and {0}".format('How','are','you'))