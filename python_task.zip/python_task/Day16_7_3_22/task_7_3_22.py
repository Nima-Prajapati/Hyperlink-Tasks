"""
Today's python task (7 Mar, 2022)

Task 1: Decorators
Task 2: Property decorators
Task 3: Abstract Method

"""

"""
Task 1: Decorators
-This is also called metaprogramming because a part of the program tries to modify another part of the program at compile time.
-A decorator in Python is a function that takes another function as its argument, and returns yet another function .
 Decorators can be extremely useful as they allow the extension of an existing function, without any modification to the original function source code.
- function call in sequence
"""


# 1
# pass fn function2 to the  decorator_function, and this function returns the inner function which we assign
def decorator_function(fun):
    def inner():
        print("Decorator!!")
        fun()

    return inner


@decorator_function
def function2():
    print("Function 2 called!")


# obj = decorator_function(function2)
# obj()
function2()
print("---1" * 40)


# 2
def decorator_function(fun):
    def inner(a, b):
        if b == 0:
            print("B is 0")
            return
        return fun(a, b)  # function2 call

    return inner


@decorator_function
def function2(a, b):
    print(f"Sum : {a + b}")


# obj = decorator_function(function2)
# obj()
function2(10, 2)
print("--2" * 40)


# 3
def decorator_function(fun):
    def inner(*args, **kwargs):
        print(args)
        print(kwargs)
        return fun(*args, **kwargs)

    return inner


@decorator_function
def function2(a, b, c, *args, **kwargs):
    print(f"Sum : {a + b + c}")


# obj = decorator_function(function2)
# obj()
function2(10, 0, 12, d=25, f=True)
print("--3" * 40)


# 4
def decorator_function(fun):
    def inner(*args, **kwargs):
        print("Decorator 1St called..")
        print(args)
        print(kwargs)
        return fun(*args, **kwargs)

    return inner


def decorator_function2(fun):
    def inner(*args, **kwargs):
        print("Decorator 2nd called..")
        print(args)
        print(kwargs)
        return fun(*args, **kwargs)

    return inner


@decorator_function2
@decorator_function
def function2(a, b, c, *args, **kwargs):
    print(f"Sum : {a + b + c}")


# obj = decorator_function(function2)
# obj()
function2(10, 0, 12, d=25, f=True)
print("--4" * 40)


# 5
def decorator_function(fun):
    def inner(*args, **kwargs):
        print("Decorator 1St called..")
        print(args)
        print(kwargs)
        return fun(*args, **kwargs)

    return inner


def decorator_function2(fun):
    def inner(*args, **kwargs):
        print("Decorator 2nd called..")
        print(args)
        print(kwargs)
        if args[1] == 0:  # if b==0
            print("Stop!")
            return
        return fun(*args, **kwargs)

    return inner


@decorator_function
@decorator_function2
def function2(a, b, c, *args, **kwargs):
    print(f"Sum : {a + b + c}")


function2(10, 0, 12, d=25, f=True)
print("--5" * 40)

# 6
"""
we pass the function add_together to the decorator_list function, and this function returns the inner function which we 
assign to the variable name add_together. As add_together now points to the inner function, which expects a list of 2
element tuples, we can call add_together with a list of tuples as the argument.
"""


def decorator_list(fnc):
    def inner(list_of_tuples):
        return [fnc(val[0], val[1]) for val in list_of_tuples]

    return inner


@decorator_list
def add_together(a, b):
    return a + b


print(add_together([(1, 3), (3, 17), (5, 5), (6, 7)]))
print("--6" * 40)


# 7
def meta_decorator(power):
    def decorator_list(fnc):
        def inner(list_of_tuples):
            return [(fnc(val[0], val[1])) ** power for val in list_of_tuples]

        return inner

    return decorator_list


@meta_decorator(2)
def add_together(a, b):
    return a + b


print(add_together([(1, 3), (3, 17), (5, 5), (6, 7)]))
print("--7" * 40)

"""
Task 2: Property decorators
Python programming provides us with a built-in @property decorator which makes usage of getter and setters much easier.
delete,
Property() Function:
        -It is used to define properties in the python class.
        - This method in python provides an interface to instance attribute.
        -This method takes get,set,delete and doc method as argument and return an object of the property class.
Syntax:
    - Property(fget, fset, fdel, doc)
Parameters:
        - fget: (Optional)Function for getting the attribute value. Default value is None.
        - fset: (Optional)Function for setting the attribute value. Default value is None.
        - fdel: (Optional)Function for deleting the attribute value. Default value is None.
        - doc: (Optional) A string that contains the documentation. Default value is None.
- It is recommended to use the property decorator instead of property() method.
@property function work like attribute
"""


# 1
class A:
    def __init__(self, number=0):
        self.set_number(number)

    def to_number(self):
        return self.get_number()

    # getter method
    def get_number(self):
        return self._number

    # setter method
    def set_number(self, value):
        self._number = value + value


obj = A(20)
# Get the number attribute via a getter
print(obj.get_number())
# Get the to_number method, get_number() called by the method itself
print(obj.to_number())
# # new constraint implementation
# print(obj.set_number(10))
# # Get the to_number method
# print(obj.to_number())
print("--1" * 40)


# 2
class A:
    def __init__(self, number=0):
        self.numbers = number

    def to_number(self):
        return self.numbers

    # getter method
    def get_number(self):
        return self._number

    # setter method
    def set_number(self, value):
        self._number = value + value

    # property(fget=None, fset=None, fdel=None, doc=None)
    number = property(get_number, set_number)


obj = A(20)
print(obj.numbers)
print(obj.to_number())
print("--2" * 40)


# 3
class Student:
    def __init__(self, name, standred, grade) -> None:
        self.name = name
        self.standred = standred
        self._grade = grade

    def get_grade(self):
        return self._grade

    def set_grade(self, g):
        self._grade = g

    def del_grade(self):
        self._grade = ''

    grade = property(get_grade, set_grade, del_grade)


student_obj = Student('John', 12, 'A')
print(f'{"-" * 50}')
print("Property Decorator using Property() method.")

print(f"Student Name : {student_obj.name}")
print(f"Student Standred : {student_obj.standred}")
print(f"Student Grade : {student_obj.grade}")

student_obj.grade = 'A+'
print("\nAfter Updating Student Grade:")
print(f"Student Name : {student_obj.name}")
print(f"Student Standred : {student_obj.standred}")
print(f"Student Grade : {student_obj.grade}")

del student_obj.grade
print("\nAfter Deleting Student Grade:")
print(f"Student Name : {student_obj.name}")
print(f"Student Standred : {student_obj.standred}")
print(f"Student Grade : {student_obj.grade}")

# 4
# print("----------------------------------")
# print("-----@property decorators--------")
# print("----------------------------------")
#
#
# class emp:
#     def __init__(self, fname, lname):
#         self.fname = fname
#         self.lname = lname
#         # self.email=f"{self.fname}.{self.lname}@hlink.net.in"
#
#     def info(self):
#         print(f"this is employee name :{self.fname} {self.lname}")
#         # print(f"employee email :{self.fname}.{self.lname}@hlink.net.in")
#
#     @property
#     def email(self):
#         return f"{self.fname}.{self.lname}@hlink.net.in"
#
#     # @email.setter
#     # def email(self, string):
#     #     # string="dipak.kavade@gmail.com"
#     #     name = string.split('@')
#     #     name1 = name[0]
#     #     name2 = name1.split('.')
#     #     self.fname = name2[0]
#     #     self.lname = name2[1]
#     #     print(f"{self.fname}.{self.lname}@hlink.net.in")
#
#
# empobj = emp("nima", "p")
#
# empobj.fname = 'reshma'
#
# print(empobj.info())
# print(empobj.email)
# # empobj.email = "dipak.kavade@gmail.com"


"""
Task 3: Abstract Method
abstract method create in parent class and implement in child class. we can't create obj of abstract class.
Abstraction in Python is the process of hiding the real implementation of an application from the user and emphasizing only on how to use the application.
abstraction can be achieved using abstract classes and methods.
Through the process of abstraction in Python, a programmer can hide all the irrelevant data/process of an application in order to reduce complexity and increase efficiency.
A class containing one or more abstract methods is called an abstract class.
Abstract methods do not contain any implementation. Instead, all the implementations can be defined in the methods of sub-classes that inherit the abstract class. 

An abstract class can have both a normal method and an abstract method
An abstract class cannot be instantiated, ie., we cannot create objects for the abstract class

"""
# Python program showing
# abstract base class work

from abc import ABC, abstractmethod


class Polygon(ABC):

    @abstractmethod
    def noofsides(self):
        pass


class Triangle(Polygon):

    # overriding abstract method
    def noofsides(self):
        print("I have 3 sides")


class Pentagon(Polygon):

    # overriding abstract method
    def noofsides(self):
        print("I have 5 sides")


class Hexagon(Polygon):

    # overriding abstract method
    def noofsides(self):
        print("I have 6 sides")


# Driver code
R = Triangle()
R.noofsides()

R = Pentagon()
R.noofsides()

K = Hexagon()
K.noofsides()
print("--1" * 40)

# 2
from abc import ABC


class Shape(ABC):
    def print(self):
        print("I am a normal method defined inside the abstract class 'Shape'")

    def calculate_are(self):
        pass


class Rectangle(Shape):
    length = 5
    breadth = 3

    def calculate_area(self):
        return self.length * self.breadth


rec = Rectangle()  # object created for the class 'Rectangle'
rec.print()
print("Area of a rectangle:", rec.calculate_area())
