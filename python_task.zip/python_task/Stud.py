
#Student Management System

student = {}

while(True):
    print("*"*20)
    print("\nPress 1 - Display All Students")
    print("\nPress 2 - Add student detail")
    print("\nPress 3 - Search student by rollno, name, department")
    print("\nPress 4 - Update student detail")
    print("\nPress 5 - Delete student detail")
    print("\nPress 6 - Sorting (Rollno, Name, department, semester, Age)")
    print("\nPress 0 - Exit\n")
    print("*"*20)

    try:
        numb = int(input("Enter Your Choice = "))

        if numb < 0:
            raise ValueError
        elif numb == 0:
            exit()


        if numb == 1:
            if student == {}:
                print("*"*20)
                print("\n ==> Student Details Not Found <==\n")
                
            else:    
                print("*"*20)
                print("\n===> Display All Students <====\n")
                print("*"*20)
                for i, j in student.items():
                    print("\nStudent ID:", i)
        
                    for key in j:
                        print(key + ':', j[key])

        elif numb == 2: 
            print("*"*20)
            print("\n===> Add Student <====\n")
            print("*"*20)
            r_no = int(input('Enter Roll Number = '))
            for i in range(1,len(student)+1):
                if student[i]['Roll_no'] == r_no and r_no != 0:
                    print("\n ==> your input roll number is duplicate please enter another roll number <===\n")
                    break 
            else:
                name =input('Enter Name = ')
                gender =input('Enter Gender = ')
                age =int(input('Enter Age = '))
                department =input('Enter Department = ')
                semester = int(input('Enter Semester = '))


                a = {}

                subj = int(input("How Many Subject Add = "))

                for i in range(1,subj+1):
                    scode = int(input("Enter Subject code = "))
                    sub  = input("Enter Subject = ")
                    a.update({scode:sub})
                

                if r_no == 0:
                    print("*"*20)
                    print("===> 0 Value Not Excepted Please Enter Valid Number  <==== ") 

                elif r_no ==" " or name ==" " or gender ==" " or age == " " or department == " " or semester == " ":# or subject1 == " " or subject2 == " ":
                    print("\n Please Enter Valid Input")

                else:
                    roll = len(student)+1
                
                    student.update({roll:{"Roll_no":r_no,"Name":name,"Gender":gender,"Age":age,"Department":department,"Semester":semester,"Subjects":a}})
                    print("\nRecord inserted...\n")
                    for i,j in student[roll].items():
                        print(i + ':', j)

        elif numb == 3:
            while(True):
                print("*"*20)
                print("\n======>  Search Student <======")
                print("\nPress 1 - Search Roll No")
                print("\nPress 2 - Search Name")
                print("\nPress 3 - Search Department")
                print("\nPress 0 - Exit\n")
                print("*"*20)

                try:
                    numb1 = int(input("Enter Your Choice = "))
                    print("*"*20)
                    if numb1 < 0:
                        raise ValueError
                    elif numb1 == 0:
                        break
                        #exit()
                    
                    if student == {}:
                        print("\n ==> Student Details Not Found <==\n")
                    else:   
                        if numb1 == 1:
                       
                                print("\n===> Search Roll No Wise Student <====\n")
                                print("*"*20)
                                rlno = int(input("Enter Roll No = "))
                                for i in student:
                                    if student[i]["Roll_no"] == rlno:
                                            print(m + ':', j)
                    
                        elif numb1 == 2:

                                print("\n===> Search Name Wise Student <====\n")
                                print("*"*20)
                                nam = input("Enter Name = ")
                                for i in student: 
                                    if student[i]["Name"] == nam:
                                        for m,j in student[i].items():
                                            print(m + ':', j)


                        elif numb1 == 3:
  
                                print("\n===> Search Department Wise Student <====\n")
                                print("*"*20)
                                dep = input("Enter Department = ")
                                for i in student: 
                                    if student[i]["Department"] == dep:
                                            print(m + ':', j)

                    if numb1 >= 4:
                        print("*"*20)
                        print("\n ==> Please Enter Valid Choice Number <== \n")

                except ValueError as v:
                    print("\n ===> Error : Please Enter Valid Number Input <===\n")
                except KeyboardInterrupt as k:
                    print(k)
        

        elif numb == 4: 

              

            while(True):
                print("*"*20)
                print("\n======> Update Students <======")
                print("\nPress 1 - Update Roll No")
                print("\nPress 2 - Update Name")
                print("\nPress 3 - Update Gender")
                print("\nPress 4 - Update Age")
                print("\nPress 5 - Update Department")
                print("\nPress 6 - Update Semester")
                print("\nPress 7 - Update Subject")
                print("\nPress 0 - Exit\n")
                print("*"*20)

                try:
                    numb3 = int(input("Enter Your Choice = "))
                    print("*"*20)
                    if numb3 < 0:
                        raise ValueError
                    elif numb3 == 0:
                        break
                    
                    if student == {}:
                        print("\n ==> Student Details Not Found <==\n")
                    else:   

                        if numb3 == 1:
                            
                                print("\n===> Update Student Roll No  <====\n")
                                print("*"*20)
                                l = int(input("Enter Student Id ="))
                                print("*"*20)
                                ra_no = int(input("Enter New Roll Number = ")) 
                                for m in student:
                                        student[l].update({"Roll_no":ra_no})
                                        print("\nRecord Updated...\n")

                                        for i,j in student[l].items():
                                            print(i + ':', j)

                        elif numb3 == 2:
                           
                                print("\n===> Update Student Name <====\n")
                                print("*"*20)
                                l = int(input("Enter Student Id ="))
                                print("*"*20)
                                nam = input("Enter New Name = ")
                                for m in student:
                                        student[l].update({"Name":nam})
                                        print("\nRecord Updated...\n")
                                        for i,j in student[l].items():
                                            print(i + ':', j)

                        elif numb3 == 3:
                            
                                print("\n===> Update Student Gender  <====\n")
                                print("*"*20)
                                l = int(input("Enter Student Id ="))
                                print("*"*20)
                                gen = input("Enter New Gender = ")
                                for m in student:
                                        student[l].update({"Gender":gen})
                                        print("\nRecord Updated...\n")
                                        for i,j in student[l].items():
                                            print(i + ':', j)

                        elif numb3 == 4:
                            
                                print("\n===> Update Student Age  <====\n")
                                print("*"*20)
                                l = int(input("Enter Student Id ="))
                                print("*"*20)
                                ag = input("Enter New Age = ")
                                for m in student:
                                        student[l].update({"Age":ag})
                                        print("\nRecord Updated...\n")
                                        for i,j in student[l].items():
                                            print(i + ':', j)
                    
                        elif numb3 == 5:
                           
                                print("\n===> Update Student Department <====\n")
                                print("*"*20)
                                l = int(input("Enter Student Id ="))
                                print("*"*20)
                                dep = input("Enter New Department = ")
                                for m in student:
                                        student[l].update({"Department":dep})
                                        print("\nRecord Updated...\n")
                                        for i,j in student[l].items():
                                            print(i + ':', j)
                        

                    
                        elif numb3 == 6:
                            
                                print("\n===> Update Student Semester <====\n")
                                print("*"*20)
                                l = int(input("Enter Student Id ="))
                                print("*"*20)
                                sem = input("Enter New Semester = ")
                                for m in student:
                                        student[l].update({"Semester":sem})
                                        print("\nRecord Updated...\n")
                                        for i,j in student[l].items():
                                            print(i + ':', j)
                    
                        elif numb3 == 7:
                            
                                print("\n===> Update Student Semester <====\n")
                                print("*"*20)
                                l = int(input("Enter Student Id ="))
                                print("*"*20)
                                a = {}
                                l = int(input("Enter Student Id ="))
                                subj = int(input("How Many Subjects Update  = "))

                                for i in range(1,subj+1):
                                    scode = int(input("Enter Subject code = "))
                                    sub  = input("Enter Subject = ")
                                    a.update({scode:sub})

                                student[l].update({"Subjects":a})
                                print("\nRecord Updated...\n")
                                for i,j in student[l].items():
                                    print(i + ':', j)
                                



                    
                    if numb3 >= 8:
                        print("*"*20)
                        print("\n ==> Please Enter Valid Choice Number <== \n")

                except ValueError as v:
                    print("\n ===> Error : Please Enter Valid Number Input <===\n")
                except KeyboardInterrupt as k:
                    print(k)



        elif numb == 5:
            if student == {}:
                print("*"*20)
                print("\n ==> Student Details Not Found <==\n")
            else:
                print("*"*20)
                d_no = int(input("enter student roll number that you want to delete:"))
                del student[d_no]
                for i in student: 
                    print("*"*20)
                    print(f'Roll NO = {student[i]["Roll_no"]}\nName = {student[i]["Name"]}\nGender = {student[i]["Gender"]}\nDepartment = {student[i]["Department"]}\nSemester = {student[i]["Semester"]}\nSubjects = {student[i]["Subjects"]}\n')
       
        elif numb == 6:
            print("*"*20)
            while(True):
                print("*"*20)
                print("\n======>  Sorting Students <======")
                print("\nPress 1 - Sorting Roll No")
                print("\nPress 2 - Sorting Name")
                print("\nPress 3 - Sorting Department")
                print("\nPress 4 - Sorting Semester")
                print("\nPress 5 - Sorting Age")
                print("\nPress 0 - Exit\n")
                print("*"*20)

                try:
                    
                    numb2 = int(input("Enter Your Choice = "))
                    print("*"*20)
                    if numb2 < 0:
                        raise ValueError
                    elif numb2 == 0:
                        break
                    
                    if student == {}:
                        print("\n ==> Student Details Not Found <==\n")
                    else:
                        
                        if numb2 == 1:
                            print("\n===> Sorting Roll No Wise Student <====\n")
                            print("*"*20)
                            Roll_no = dict(sorted(student.items(), key = lambda x: x[1]['Roll_no']))
                            for i, j in Roll_no.items():
                                print("\nPerson ID:", i)
                                for key in j:
                                    print(key + ':', j[key])

                        elif numb2 == 2:
                            print("\n===> Sorting Name Wise Student <====\n")
                            print("*"*20)
                            name = dict(sorted(student.items(), key = lambda x: x[1]['Name']))
                            for i, j in name.items():
                                print("\nPerson ID:", i)
                                
                                for key in j:
                                    print(key + ':', j[key])

                        elif numb2 == 3:
                            print("\n===> Sorting Department Wise Student <====\n")
                            print("*"*20)
                            department = dict(sorted(student.items(), key = lambda x: x[1]['Department']))
                            for i, j in department.items():
                                print("\nPerson ID:", i)
                                for key in j:
                                    print(key + ':', j[key])

                        elif numb2 == 4:
                            print("\n===> Sorting Semester Wise Student <====\n")
                            print("*"*20)
                            semester = dict(sorted(student.items(), key = lambda x: x[1]['Semester']))
                            for i, j in semester.items():
                                print("\nPerson ID:", i) 
                                for key in j:
                                    print(key + ':', j[key])
                    
                        elif numb2 == 5:
                            print("\n===> Search Age Wise Student <====\n")
                            print("*"*20)
                            Age = dict(sorted(student.items(), key = lambda x: x[1]['Age']))
                            for i, j in Age.items():
                                print("\nPerson ID:", i)
                                for key in j:
                                    print(key + ':', j[key])

                    if numb2 >= 6:
                        print("*"*20)
                        print("\n ==> Please Enter Valid Choice Number <== \n")

                except ValueError as v:
                    print("\n ===> Error : Please Enter Valid Number Input <===\n")
                except KeyboardInterrupt as k:
                    print(k)

        elif numb >= 7:
            print("*"*20)
            print("\n ==> Please Enter Valid Choice Number <== \n")

    except ValueError as v:
        print("\n ===> Error : Please Enter Valid Number Input <===\n")
    except KeyboardInterrupt as k:
        print(k)
