Task 1 :

-keywords and identifiers
-statements and comments
-Variables, Constants and Literals
-data types
-Type Conversion and Type Casting
-I/O and import
-Operators
-Programming Namespace


1. keywords  (https://www.w3schools.com/python/python_ref_keywords.asp)

	import keyword
>>> print(keyword.kwlist)
['False', 'None', 'True', 'and', 'as', 'assert', 'async', 'await', 'break', 'class', 'continue', 'def', 'del', 'elif', 'else', 'except', 'finally', 'for', 
'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'try', 'while', 'with', 'yield']

	1.False:The False keyword is a Boolean value, and result of a comparison operation.The False keyword is the same as 0 (True is the same as 1).
			

	2.None: The None keyword is used to define a null value, or no value at all.None is not the same as 0, False, or an empty string.
			 None is a data type of its own (NoneType) and only None can be None.
			 

	3.True:The True keyword is a Boolean value, and result of a comparison operation.The True keyword is the same as 1 (False is the same as 0).
			
	4.and: The and keyword is a logical operator.Logical operators are used to combine conditional statements.The return value will only be True if both 
			statements return True, otherwise it will return False.
			 

	5.as : The as keyword is used to create an alias.In the example above, we create an alias, c, when importing the calendar module, 
			and now we can refer to the calendar module by using c instead of calendar.

	6.assert: The assert keyword is used when debugging code.The assert keyword lets you test if a condition in your code returns True, if not, 
				the program will raise an AssertionError.

	7.async:

	8.await:

	9.break: The break keyword is used to break out a for loop, or a while loop.

	10.class: The class keyword is used to create a class.A class is like an object constructor. 
				

	11.continue: The continue keyword is used to end the current iteration in a for loop (or a while loop), and continues to the next iteration.
				

	12.def: The def keyword is used to create, (or define) a function.
		

	13.del:The del keyword is used to delete objects. In Python everything is an object, so the del keyword can also be used to delete variables, lists, 
			or parts of a list etc.


	14.elif: The elif keyword is used in conditional statements (if statements), and is short for else if.

	15.else:The else keyword is used in conditional statements (if statements), and decides what to do if the condition is False.The else keyword can 
			also be use in try...except blocks

	16.except: The except keyword is used in try...except blocks. It defines a block of code to run if the try block raises an error.You can define 
				different blocks for different error types, and blocks to execute if nothing went wrong

	17.finally: The finally keyword is used in try...except blocks. It defines a block of code to run when the try...except...else block is final.The finally 
				block will be executed no matter if the try block raises an error or not.This can be useful to close objects and clean up resources.

	18.for : The for keyword is used to create a for loop.It can be used to iterate through a sequence, like a list, tuple, etc.

	19.from: The from keyword is used to import only a specified section from a module.

	20.global: The global keyword is used to create global variables from a no-global scope, e.g. inside a function.

	21.if: The if keyword is used to create conditional statements (if statements), and allows you to execute a block of code only if a condition is True.
			Use the else keyword to execute code if the condition is False

	22.import: The import keyword is used to import modules.

	23.in: The in keyword has two purposes:The in keyword is used to check if a value is present in a sequence (list, range, string etc.).
			The in keyword is also used to iterate through a sequence in a for loop

	24.is: The is keyword is used to test if two variables refer to the same object.The test returns True if the two objects are the same object.
			The test returns False if they are not the same object, even if the two objects are 100% equal.Use the == operator to test if two variables are equal.

	25.lambda: The lambda keyword is used to create small anonymous(name not need) functions. A lambda function can take any number of arguments, but can only have 
				one expression.The expression is evaluated and the result is returned.

	26.nonlocal: The nonlocal keyword is used to work with variables inside nested functions, where the variable should not belong to the inner function.
				 Use the keyword nonlocal to declare that the variable is not local.

	27.not: The not keyword is a logical operator.The return value will be True if the statement(s) are not True, otherwise it will return False.

	28.or: The or keyword is a logical operator.Logical operators are used to combine conditional statements.
			The return value will be True if one of the statements return True, otherwise it will return False.

	29.pass: The pass statement is used as a placeholder for future code.When the pass statement is executed, nothing happens, but you avoid getting an 
				error when empty code is not allowed.Empty code is not allowed in loops, function definitions, class definitions, or in if statements.
			function not compile the body,body part skip 


	30.raise: The raise keyword is used to raise an exception.You can define what kind of error to raise, and the text to print to the user.

	31.return: The return keyword is to exit a function and return a value.

	32.try: The try keyword is used in try...except blocks. It defines a block of code test if it contains any errors.
			You can define different blocks for different error types, and blocks to execute if nothing went wrong

	33.while: The while keyword is used to create a while loop.A while loop will continue until the statement is false.

	34.with: Used to simplify exception handling,no need to close the file which is opned.

	35.yield: To end a function, returns a generator,for continous call 


1.False
print(5 > 6)                  op:False
print(4 in [1,2,3])           op:False
print("hello" is "goodbye")   op:False
print(5 == 6)
print(5 == 6 or 6 == 7)
print(5 == 6 and 6 == 7)
print("hello" is not "hello")
print(not(5 == 5))
print(3 not in [1,2,3])
True and False
False == 1

2.None
x = None
type(x)

if x:
	print("Do you think None is True?")
elif x is False:
	print ("Do you think None is False?")
else:
	print("None is not True, or False, None is just None...")
op:None is not True, or False, None is just None...

3.True
print(5 < 6)             op:True
print(2 in [1,2,3])      op:True
print(5 is 5)            op:True
print(5 == 5)
print(5 == 5 or 6 == 7)
print(5 == 5 and 7 == 7)
print("hello" is not "goodbye")
print(not(5 == 7))
print(4 not in [1,2,3])
True or False
True == 1
False == 0

4.and
if 5 > 3 and 5 < 10:
	print("Both statements are True")
else:
	print("At least one of the statements are False")
op:Both statements are True

5.as
import calendar as c
print(c.month_name[1])
op:January

6.assert
x = "hello"
#if condition returns True, then nothing happens:
assert x == "hello"

#if condition returns False, AssertionError is raised:
assert x == "goodbye"
op: Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
AssertionError


7.async
# async def main():
# 	print("Hello")
# 	await asyncio.sleep(5)
# 	print("World")
# >>asyncio.run(main())
# op:

8.await

9.break
for i in range(9):
	if i > 3:
		break
	print(i)
op:0
1
2
3

10.class
class Person:
	name = "John"
	age = 36

p1 = Person()

print(p1.name)
op:John

11.continue
for i in range(9):
	if i == 3:
		continue
	print(i)  
op: 0
1
2
4
5
6
7
8		

12.	def 
function():
	pass								
def my_function():
	print("Hello from a function")

my_function()
op:Hello from a function

13.del
x = "hello"
del x
print(x)
op:Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'x' is not defined


14.elif
i=5
if i > 0:
	print("Greater")
elif i < 0:
	print("less")
else:
	print("equal")
op:Greater

15.else
x = 5

try:
	x > 10
except:
	print("Something went wrong")
else:
	print("The 'Try' code was executed without raising any errors!")
op:The 'Try' code was executed without raising any errors!

16.except
# (x/0) raises a ZeroDivisionError:

try:
	x = 1/0
except NameError:
	print("You have a variable that is not defined.")
except TypeError:
	print("You are comparing values of different type")
except:
	print("Something else went wrong")
op:Something else went wrong

17.finally
try:
	x > 3
except:
	print("Something went wrong")
else:
	print("Nothing went wrong")
finally:
	print("The try...except block is finished")
op:Nothing went wrong
	The try...except block is finished


18.for
for x in range(1, 9):
  print(x)
1
2
3
4
5
6
7
8

19.from
from datetime import time

x = time(hour=15)

print(x)
op:15:00:00 

20.global
#create a function:
def myfunction():
  global x
  x = "hello"

myfunction()

print(x) #x should now be global, and accessible in the global scope.
op:hello

21.if
x = 5
if x > 3:
  print("YES")
op:YES

22.import
import datetime

x = datetime.datetime.now()

print(x)

23.in
fruits = ["apple", "banana", "cherry"]

if "banana" in fruits:
  print("yes")
op:yes
for i in 'Helloworld':
	print(i)
op:H
e
l
l
o
w
o
r
l
d


24.is
x = ["apple", "banana", "cherry"]
y = x
print(x is y)
op:True

a=None
a is not None
op:False

25.
x = lambda a, b, c : a + b + c
print(x(5, 6, 3))
op:14

26.nonlocal
def myfunc1():
  x = "John"
  def myfunc2():
    nonlocal x
    x = "hello"
  myfunc2() 
  return x

print(myfunc1())
op:hello

27.
x = False
print(not x)
op:True

28.
x = (5 > 3 or 5 > 10)
print(x)
op:True

29.
for x in [0, 1, 2]:
  pass

# having an empty for loop like this, would raise an error without the pass statement

30.
x = -1
if x < 0:
  raise Exception("Sorry, no numbers below zero")
op:Traceback (most recent call last):
  File "<stdin>", line 2, in <module>
Exception: Sorry, no numbers below zero


31.
def myfunction():
  return 3+3

print(myfunction())
op:6

32.
try:
  x > 3
except:
  print("Something went wrong")

print("Even if it raised an error, the program keeps running")
op:Something went wrong
Even if it raised an error, the program keeps running

33.
x = 0

while x < 9:
  print(x)
  x = x + 1
op:0
1
2
3
4
5
6
7
8





2.identifiers:
A Python identifier is a name used to identify a variable, function, class, module or other object. An identifier starts with a letter A to Z or a to z or
an underscore (_) followed by zero or more letters, underscores and digits (0 to 9).
The identifier is a name used to identify a variable, function, class, module, etc. The identifier is a combination of character digits and underscore. 
The identifier should start with a character or Underscore then use a digit. The characters are A-Z or a-z, an UnderScore ( _ ) , and digit (0-9). 
we should not use special characters ( #, @, $, %, ! ) in identifiers.

	1.Identifiers can be a combination of letters in lowercase (a to z) or uppercase (A to Z) or digits (0 to 9) or an underscore _. Names like myClass, 
		var_1 and print_this_to_screen, all are valid example.
	2.An identifier cannot start with a digit. 1variable is invalid, but variable1 is a valid name.
	3.Keywords cannot be used as identifiers.
		global = 1
		Output
 			 File "<interactive input>", line 1
    			global = 1
           			   ^
		SyntaxError: invalid syntax
	4.We cannot use special symbols like !, @, #, $, % etc. in our identifier.
		a@ = 0

		Output
		  File "<interactive input>", line 1
		    a@ = 0
		     ^
		SyntaxError: invalid syntax
	5.An identifier can be of any length.
	6.Multiple words can be separated using an underscore, like this_is_a_long_variable.	
	Class names start with an uppercase letter. All other identifiers start with a lowercase letter.
	Starting an identifier with a single leading underscore indicates that the identifier is private.
	Starting an identifier with two leading underscores indicates a strongly private identifier.
	If the identifier also ends with two trailing underscores, the identifier is a language-defined special name.
Examples of valid identifiers:
1.var1
2._var1
3._1_var
4.var_1

num = 10
print(num)

_x = 100
print(_x)

a_b = 99
print(a_b)

print("abc".isidentifier())  # True
print("99a".isidentifier())  # False
print("_".isidentifier())  # True
print("for".isidentifier())  # True - wrong output

def is_valid_identifier(s):
    return s.isidentifier() and not keyword.iskeyword(s)
 
print(is_valid_identifier("for"))  # False