statements : Instructions that a Python interpreter can execute are called statements. For example, a = 1 is an assignment statement. if statement, 
			for statement, while statement, etc. are other kinds of statements
comments : They describe what is going on inside a program, so that a person looking at the source code does not have a hard time figuring it out.
			In Python, we use the hash (#)
			we can use ''' , """






Variables : A Variable is a location that is named in order to store data while the program is being run.
			In a programming language, Variables are words that are used to store values of any data type.
		Rules to be followed while declaring a Variable name
			1.A Variable’s name cannot begin with a number. Either an alphabet or the underscore character should be used as the first character.
			2.Variable names are case-sensitive and can include alphanumeric letters as well as the underscore character.
			3.Variable names cannot contain reserved terms.
			4.The equal to sign ‘=’, followed by the variable’s value, is used to assign variables in Python.
_ (underscore_ represent the o/p of prevoius operation.
Eg.
val = 50
print("Initial value:", val)

val = 100   # assigning new value
print("Updated value:", val)





Constants: A Python Constant is a variable whose value cannot be changed throughout the program.
			constant var must be in capital. e.g PI
		Rules to be followed while declaring a Constant
			1.Python Constants and variable names should contain a combination of lowercase (a-z) or capital (A-Z) characters, numbers (0-9), 
			  or an underscore ( ).
			2.When using a Constant name, always use UPPERCASE, For example, CONSTANT = 50.
			3.The Constant names should not begin with digits.
			4.Except for underscore(_), no additional special character (!, #, ^, @, $) is utilized when declaring a constant.
			5.We should come up with a catchy name for the python constants. VALUE, for example, makes more sense than V. It simplifies the coding process.
Eg. 
import con    #con.py
PI = 3.14
GRAVITY = 9.8

print('Value of PI:', con.PI)
print('Value of Gravitational force:', con.GRAVITY)




Literals: The data which is being assigned to the variables are called as Literal.
			In Python, Literals are defined as raw data which is being assigned to the variables or constants.
	Numeric Literals
		Numeric Literals are values assigned to the Variables or Constants which cannot be changed i.e., they are immutable.
		 There are a total of 3 categories in Numeric Literals. They are –  Integer, Float, and Complex.
Eg.
# Numeric Literals
a = 0b1010 #Binary Literals
b = 100 #Decimal Literal 
c = 0o310 #Octal Literal
d = 0x12c #Hexadecimal Literal

#Float Literal
float_1 = 10.5 
float_2 = 1.5e2

#Complex Literal 
x = 3.14j
print(a, b, c, d)
print(float_1, float_2)
print(x, x.imag, x.real)

# String literals
strings = "This is Python"
char = "C"
multiline_str = """This is a multiline string with more than one line code."""
unicode = u"\u00dcnic\u00f6de"
raw_str = r"raw \n string"
print(strings)
print(char)
print(multiline_str)
print(unicode)
print(raw_str)

# Boolean literals
x = (1 == True)
y = (1 == False)
a = True + 4
b = False + 10
print("x is", x)
print("y is", y)
print("a:", a)
print("b:", b)




Data type:
Text Type:	str
Numeric Types:	int, float, complex
Sequence Types:	list, tuple, range
Mapping Type:	dict
Set Types:	set, frozenset
Boolean Type:	bool
Binary Types:	bytes, bytearray, memoryview

Eg.str
x = "Hello World"
print(x)
print(type(x)) 

Eg.int
x = 20
print(x)
print(type(x)) 
op:20
<class 'int'>

Eg.float
x = 20.5
print(x)
print(type(x)) 

Eg.complex :Complex number is represented by complex class. It is specified as (real part) + (imaginary part)j. For example – 2+3j
x = 1j
print(x)
print(type(x)) 
op:1j
<class 'complex'>

Eg.list
x = ["apple", "banana", "cherry"]
print(x)
print(type(x)) 

Eg.tuple
x = ("apple", "banana", "cherry")
print(x)
print(type(x)) 

Eg.range
x = range(6)
print(x)
print(type(x)) 
op:range(0,6)
<class 'range'>

Eg.dict
x = {"name" : "John", "age" : 36}
print(x)
print(type(x)) 

Eg.set
x = {"apple", "banana", "cherry"}
print(x)
print(type(x)) 

Eg.frozenset
x = frozenset({"apple", "banana", "cherry"})
print(x)
print(type(x)) 

Eg.bool
x = True
print(x)
print(type(x)) 

Eg.bytes
x = b"Hello"
print(x)
print(type(x)) 
op:b'Hello'
<class 'bytes'>

Eg.bytearray
x = bytearray(5)
print(x)
print(type(x)) 
op:bytearray(b'\x00\x00\x00\x00\x00')
<class 'bytearray'>

Eg.memoryview
x = memoryview(bytes(5))
print(x)
print(type(x))
op:<memory at 0x01368FA0>
<class 'memoryview'> 






Type Conversion and Type Casting:
Type Conversion : Python defines type conversion functions to directly convert one data type to another
# implicit type conversion
Eg.
x = 10
print("x is of type:",type(x))
y = 10.6
print("y is of type:",type(y))
x = x + y
print(x)
print("x is of type:",type(x))

op:x is of type: <class 'int'>
y is of type: <class 'float'>
20.6
x is of type: <class 'float'>

# explicit type conversion
# initializing string
s = "10010"
 
c = int(s,2) # printing string converting to int base 2
print ("After converting to integer base 2 : ", end="")
print (c)
 
e = float(s) # printing string converting to float
print ("After converting to float : ", end="")
print (e)

op:After converting to integer base 2 : 18
After converting to float : 10010.0






Programming Namespace:
A namespace is a system that has a unique name for each and every object in Python. An object might be a variable or a method. Python itself maintains 
a namespace in the form of a Python dictionary. Let’s go through an example, a directory-file system structure in computers.
Its Name (which means name, a unique identifier) + Space(which talks something related to scope).

	Types of namespaces :local,global,built-in
		When Python interpreter runs solely without any user-defined modules, methods, classes, etc. Some functions like print(), id() are always present,
		these are built-in namespaces. When a user creates a module, a global namespace gets created, later the creation of local functions creates the
		local namespace. The built-in namespace encompasses the global namespace and the global namespace encompasses the local namespace.

Eg.
# var1 is in the global namespace
var1 = 5
def some_func():
 
    # var2 is in the local namespace
    var2 = 6
    def some_inner_func():
 
        # var3 is in the nested local
        # namespace
        var3 = 7


# global variable
count = 5
def some_method():
    global count
    count = count + 1
    print(count)

some_method()
op:6





isinstance fn: The isinstance() function returns True if the specified object is of the specified type, otherwise False.
				If the type parameter is a tuple, this function will return True if the object is one of the types in the tuple.

Eg.
x = isinstance("Hello", (str, float, int, str, list, dict, tuple))
print(x)
op:True

x = isinstance(5, int)
print(x)
op:True