Task2

str1 = "Hello world"
print(str1)
str2 = "How are you"

1.
str1.len()
len(str1)   op:11

2.
str1.split()   op:['Hello', 'world']
# str1.split(‘,’)

3.
''.join(str1.split())   op:'Helloworld'

4.
reverse = str1[::-1]
print("Reverse string :",reverse)       op:dlrow olleH

5.
from collections import Counter

string= "I am working at hyperlink infosystem"
print(string)

result= Counter(string)
result= max(result)

print("Most frequent character: ",result)
# print("Most frequent character occurs {} times: ".format(result)) use for count

op:Most frequent character:  y

6.
words = str1.split(' ')
print("wordwise split and reverse :")
for x in words:
	print(x[::-1])

op:olleH
dlrow


7.
print("Replace the word : ",str1.replace("Hello","How"))  op:Replace the word :  How world



8.
import random
ran=['a','b','c','d','e']
ran1=random.choice(ran)
string = 'Nima prajapati'
# abc = string.split()
# Define variables
result = ''
for i in string:
		if i == 'a':
				i = ran1
		result += i 
print (result)

op:

import random
str1 = "I am python trainee"
ran = "abcdefghijklmnopqrstuvwxyz"
# changed = "".join(str1[:2])
changed = "".join(str1)
changed += random.choice(ran)
changed += "".join(str1[-1])
print(changed)



str1='I am python trainee'
result=[]
print('Before interchange: ',str1)
for i in str1:
   if i=='t':
      i='zh'
   result.append(i)
print('After interchange: ',''.join(result))
op:After interchange:  I am pyzhhon zhrainee





# a="you are fine"
# print(a[4:7]+" "+a[0:4]+" "+a[8:])


# String operation:
# Task 2:
# tacking  one string
# 1. finding length
# 2. split sting by space
# 3 after split  merge remove space
# 4. print reverse string : Create a slice that starts at the end of the string, and moves backwards.
		# In this particular example, the slice statement [::-1] means start at the end of the string and end at position 0, move with the step -1, negative one, which means one step backwards.
# 5. find maximum number in sting
# 6. wordwise reverse
# 7. replace word
# 8. word interchange


# Function to reverse a string
# def reverse(string):
#     string = "".join(reversed(string))
#     return string
  
# s = "Geeksforgeeks"
  
# print ("The original string  is : ",end="")
# print (s)
  
# print ("The reversed string(using reversed) is : ",end="")
# print (reverse(s))


