Python Input : 
input([prompt])
>>> num = input('Enter a number: ')
Enter a number: 10
>>> num
'10'
>>> int('10')
10
>>> float('10')
10.0



Python Import:
import math
print(math.pi)

from math import pi
pi
3.141592653589793


Output:
print(1, 2, 3, 4)
print(1, 2, 3, 4, sep='*')
print(1, 2, 3, 4, sep='#', end='&')
op:1 2 3 4
1*2*3*4
1#2#3#4&>>

x = 5; y = 10
print('The value of x is {} and y is {}'.format(x,y))
op:The value of x is 5 and y is 10

print('I love {0} and {1}'.format('bread','butter'))
print('I love {1} and {0}'.format('bread','butter'))
op:I love bread and butter
I love butter and bread

print('Hello {name}, {greeting}'.format(greeting = 'Goodmorning', name = 'John'))
op:Hello John, Goodmorning



Operators:
1.Arithmetic operators : +,-,*,/,%,**(Exponentiation),//(Floor division)
2.Assignment operators : =,+=,-=,*=,/=,%=,//=,**=,&=,|=,^=,>>=,<<=
3.Comparison operators :==,!=,<,>,>=,<=
4.Logical operators : and,or,not
5.Identity operators : is,is not
6.Membership operators : in,not in
7.Bitwise operators :&,|,^(XOR),~(NOT),<<(Zero fill left shift),>>(Signed right shift)
identity operator:is,is not


*Arithmetic operators example

print(4+5) #9
print(10-5) #5
print(10*5) #50
print(100/2) #50.0
print(10%3) #1 its reminder	
print(5**3) #work like 5*5*5 = 125
print(100//7) #return nearest round number op:14

*Assignment operators

= assigne value to variable 

# y=1
# z=2
# x = y + z
x=5
print(x);  #5

x += 3 
print(x) #x = x + y = 8

x -= 3	
print(x) # work like x = x - y =-1

x *= 3
print(x)

x = y = 2
print(x) # work like x = x  Y = 2

x /= 3
print(x) # work like x = x / y = 0.66

x %= 3
print(x) # 0.666

x //= 3
print(x) # work for division and return nearest round number,0.0

x **= 3
print(x)
# 0.0 power

# x &= y 
x &= 3 
print(x)

x |= 3
print(x) # 

x ^= 3 # ''

x >>= 3
print(x) # This operator is used to perform Bitwise right shift on the operands and then assigning result to the left operand.

x <<= 3 # This operator is used to perform Bitwise left shift on the operands and then assigning result to the left operand.


* Comparison operators

x = 5
y = 3

print(x == y) # returns False because 5 is not equal to 3
x == y #Equal #false
print(x != y) #Not equal	#True

print(x > y) #True
print(x < y) #False 

print(x >= y) # True

print(x <= y) # False

* logical operators

print(true and true) # return true
x = 5

print(x > 3 and x < 10)
# op:true

print(x > 3 or x < 4)
# op:true

print(not(x > 3 and x < 10))
# op:false


*Identity operators

x = ["apple", "banana"]
y = ["apple", "banana"]
z = x

print(x is z) #true
print(x is y) #false
print(x == y) #true
print(x is not z) #false
print(x is not y) #true
print(x != y) #false


*Membership operators

x = ["apple", "banana"]
print("banana" in x) #true

print("pineapple" not in x) #true


*Bitwise operators

& 	AND	Sets each bit to 1 if both bits are 1
|	OR	Sets each bit to 1 if one of two bits is 1
 ^	XOR	Sets each bit to 1 if only one of two bits is 1
~ 	NOT	Inverts all the bits

<<	Zero fill left shift	Shift left by pushing zeros in from the right and let the leftmost bits fall off
>>	Signed right shift	Shift right by pushing copies of the leftmost bit in from the left, and let the rightmost bits fall off