# Python task (17 Feb, 2022):
#
# Tuple: Tuples are used to store multiple items in a single variable.Tuple is one of 4 built-in data types in Python used to store collections of data,
#           the other 3 are List, Set, and Dictionary, all with different qualities and usage.
#           A tuple is a collection which is ordered and unchangeable.Tuples are unchangeable, meaning that we cannot change, add or remove items after the tuple has been created.
#           Tuple items are ordered, unchangeable, and allow duplicate values. Tuple items are indexed, the first item has index [0], the second item has index [1] etc.
#             When we say that tuples are ordered, it means that the items have a defined order, and that order will not change.
# Method of tuple :count(),index()
# Built-in fn:cmp(),len(),max(),min()tuple()



tuple1 = ("apple", "banana", "cherry", "apple", "orange", "grapes","watermalon","chicoo","mango","coconut","guava","pineapple","almond","avocado","papaya","wood apple",
          "barberry","blackberry","blueberry","date fruit","dragon","pomegranate","raisins")
print(tuple1)
tuple2 = (10,20,30,40,50)
print("Tuple2 : ",tuple2)

# 1- Reverse the tuple
print("Q1 ans :")
reverse_tup = tuple1[::-1]
print(reverse_tup)
print("+-"*40)
# op:('raisins', 'pomegranate', 'dragon', 'date fruit', 'blueberry', 'blackberry', 'barberry', 'wood apple', 'papaya', 'avocado', 'almond', 'pineapple', 'guava',
# 'coconut', 'mango', 'chicoo', 'watermalon', 'grapes', 'orange', 'apple', 'cherry', 'banana', 'apple')
# -------------------------------------------------------------------------------------------------------------------------------------------------------------

# 2- Access value 20 from the tuple
print("Q2 ans :")
print("Access value 20 : " ,tuple1[20])      #op:Access value 20 :  dragon
print("Access negative indexing : " ,tuple1[-1])   #op:Access negative indexing :  raisins
print("Access range of indexes : " ,tuple1[2:5])   #op:Access range of indexes :  ('cherry', 'apple', 'orange')
print("+-"*40)
# op:Access value 20 :  dragon
# Access negative indexing :  raisins
# Access range of indexes :  ('cherry', 'apple', 'orange')
# ------------------------------------------------------------------------------------------------------------------------------------------------------------

# 3- Create a tuple with single item 50
singletup = ("50",)
print("Q3 ans, single item 50 : ",type(singletup))
print("+-"*40)
# op:Q3 ans, single item 50 :  <class 'tuple'>
# -----------------------------------------------------------------------------------------------------------------------------------------------------------

# 4- Unpack the tuple into 4 variables
print("Q4 ans :")
fruits = ("apple", "banana")
(red, yellow) = fruits
print(red)
print(yellow)

# 2
fruits = ("apple", "banana", "cherry", "strawberry", "raspberry")
(green, yellow, *red) = fruits
print(green)
print(yellow)
print(red)
print("+-"*40)
# op:apple
# banana
# ['cherry', 'strawberry', 'raspberry']
# ----------------------------------------------------------------------------------------------------------------------------

# 5- Swap two tuples in Python
print("Q5 ans :")
tup1 = ("Hello","world")
tup2 = (1,2,3)
print(tup1,tup2)
tup1,tup2 = tup2,tup1
print(tup1,tup2)
print("+-"*40)
# op:(1, 2, 3) ('Hello', 'world')
# ----------------------------------------------------------------------------------------------------------------------------

# 6- Copy specific elements from one tuple to a new tuple
print("Q6 ans :")
a = (10,20,30,40,50)
b = a[1:4]
print(a)
print(b)
print("+-"*40)
# op:(20, 30, 40)
# ----------------------------------------------------------------------------------------------------------------------------

# 7- Modify the tuple
tup1 = ("apple", "orange", "grapes")
modifytup = ("cherry",)
tup1 += modifytup
print("Q7 ans, Modify the tuple : ",tup1)
print("+-"*40)
# op:Modify the tuple :  ('apple', 'orange', 'grapes', 'cherry')
# ----------------------------------------------------------------------------------------------------------------------------

# 8- Sort a tuple of tuples by 2nd item
tup1 = [("apple",2), ("orange",1), ("grapes",4),("cherry",3)]
tup1.sort(key = lambda x:x[1])
print("Q8 ans, sorted : ",tup1)
# op:[('orange', 1), ('apple', 2), ('cherry', 3), ('grapes', 4)]
print("+-"*40)
# --------------------------------------------------------------------------------------------------------------------------------------

# 9- Counts the number of occurrences of item 50 from a tuple
a = (10,20,50,30,40,50)
print(a)
cnt = a.count(50)
print("Q9 ans, Occurence of 50 :",cnt)
print("+-"*40)

# def count(a, x):
#     count = 0
#     for i in a:
#         if (i == x):
#             count = count + 1
#     return count
# print("Number of occurrences of item 50 from a tuple :",count(a,50))
# op:Number of occurrences of item 50 from a tuple 2

# -------------------------------------------------------------------------------------------------------------------------------------

# 10- Check if all items in the tuple are the same
print("Q10 ans :")
a = ("apple","apple","apple","banana")
element = a[0]
chk = True
for i in a:
    if element != i:
        chk = False
        break;
if (chk == True):
    print("Equal")
else:
    print("not equal")
print("+-"*40)
# op:not equal
# ------------------------------------------------------------------------------------------------------------------------

# 11- Test if tuple is distinct(not repeated value)
a = (11,14,54,0,58,41)
print("The original tuple is : " , a)
result = len(set(a)) == len(a)
print("Is tuple distinct ? : " + str(result))
print("+-"*40)
# op:True

# Test if tuple is distinct
# res = True
# temp = set()
# for i in a:
#     if i in temp:
#         res = False
#         break
#     temp.add(i)
# print("Is tuple distinct ? : " + str(res))
# op:Is tuple distinct ? : False
# ------------------------------------------------------------------------------------------------------------

# 12- Sort Tuples by Total digits
# Using sort() + len() + sum()
a = [(3, 4, 6, 900), (1, 2), (12345,), (134, 234, 100)]
print("The original list is : ",a)
def count_digs(tup):
    # gets total digits in tuples
    return sum([len(str(i)) for i in tup])
# performing sort
a.sort(key=count_digs)
print("Sorted tuples : " + str(a))
print("+-"*40)
# op:Sorted tuples : [(1, 2), (12345,), (3, 4, 6, 900), (134, 234, 100)]

# -------------------------------------------------------------------------------------------------------------

# 13- Sum of tuple elements
a = (7, 8, 9, 1, 10, 7)
print("The original tuple is : " ,a)
# Tuple elements inversions
# Using list() + sum()
res = sum(list(a))
print("The summation of tuple elements are : " + str(res))
print("+-"*40)
# op:The original tuple is :  (7, 8, 9, 1, 10, 7)
# The summation of tuple elements are : 42
# -----------------------------------------------------------------------------------------------------------------

# 14- Maximum and Minimum N elements in Tuple
print("Maximum element in tuple : "+ str(max(tuple1)))
print("Minimum element in tuple : "+ str(min(tuple1)))
print("+-"*40)
 # op:Maximum element in tuple : wood apple
# Minimum element in tuple : almond

 #15 - Find the size of a Tuple
print("size of tuple1 : " , len(tuple1))
print("+-"*40)
# op:size of tuple1 :  23