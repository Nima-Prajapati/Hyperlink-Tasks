# Python task (17 Feb, 2022):
# Random:Python has a built-in module that you can use to make random numbers.
#

import random
a = ['a','b','c','d']
# shuffle(): Takes a sequence and returns the sequence in a random order
random.shuffle(a)
print(a)

# 1- Generate 3 random integers between 100 and 999 which is divisible by 5
# randint(): Returns a random number between the given range
print("Q1 ans : ")
count = 1
while count <= 3 :
    num = random.randint(100,999)
    if num % 5 == 0:
        print(num)
        count += 1
print("+-"*40)
# ------------------------------------------------------------------------------------------------------------------------------------------------

# 2- Random Lottery Pick. Generate 100 random lottery tickets and pick two lucky tickets from it as a winner.
# The lottery number must be 10 digits long.
# All 100 ticket number must be unique.
# randrange():	Returns a random number between the given range
# sample()	Returns a given sample of a sequence
lotry_tic_list = []
for i in range(100):
    # ticket number must be 10 digit (1000000000, 9999999999)
    lotry_tic_list.append(random.randrange(1000000000, 9999999999))
result = random.sample(lotry_tic_list,2)
print("Q2 ans : ",result)
print("+-"*40)
# ----------------------------------------------------------------------------------------------------------------------------------------------

# 3- Generate 6 digit random secure OTP
otp = random.randrange(100000,999999)
print("Q3 Generated otp : ",otp)
print("+-"*40)
# ---------------------------------------------------------------------------------------------------------------------

# 4- Pick a random character from a given String
# choice()	Returns a random element from the given sequence
str1 = 'python trainee'
char = random.choice(str1)
print("Q4 ans random char is: ", char)

import string as st
ran_str = "".join(random.choice(st.ascii_letters))
print("Q4 ans : ",ran_str)
print("+-"*40)
# ---------------------------------------------------------------------------------------------------------------------


# 5- Generate random String of length 5
stringLength=5
letters = st.ascii_letters
ran_str = ''.join(random.choice(letters) for i in range(stringLength))
print("Q5 ans : ",ran_str)
print("+-"*40)
# ----------------------------------------------------------------------------------------------------------------------


# 6- Generate a random Password which meets the following conditions
    # Password length must be 10 characters long.
    # It must contain at least 2 upper case letters, 1 digit, and 1 special symbol.
# choice()	Returns a random element from the given sequence
# shuffle()	Takes a sequence and returns the sequence in a random order

def randomPassword():
    randomSource = st.ascii_letters + st.digits + st.punctuation
    password = random.sample(randomSource, 6)
    password += random.sample(st.ascii_uppercase, 2)
    password += random.choice(st.digits)
    password += random.choice(st.punctuation)
    # password += (str(password1) + str(password2) + str(password3) + str(password4))
    passwordList = list(password)
    random.SystemRandom().shuffle(passwordList)
    password = ''.join(passwordList)
    return password

print ("Q6 ans : Password is ", randomPassword())
print("+-"*40)

# rndmsrc = st.ascii_letters
# p1 = ''.join(random.choice(st.ascii_lowercase,6))
# p2 = ''.join(random.choice(st.ascii_uppercase,2))
# p3 = ''.join(random.choice(st.digits,1))
# p4 = ''.join(random.choice(st.punctuation,1))
# password = (str(p1)+str(p2)+str(p3)+str(p4))
# print("Q6 password : ",password)
# ---------------------------------------------------------------------------------------------------------------------

# 7- Calculate multiplication of two random float numbers
    # First random float number must be between 0.1 and 1
    # Second random float number must be between 9.5 and 99.5
# uniform()	Returns a random float number between two given parameters
a = random.random()
b = random.uniform(9.5,99.5)
print(a,b)
c = a*b
print("Q7 ans : ",c)
print("+-"*40)
# ---------------------------------------------------------------------------------------------------------------------


# 8- Generate random secure token of 64 bytes and random URL
import secrets
x = secrets.token_hex(64)
y = secrets.token_urlsafe(64)
print("Random secure Hexadecimal token is ", x)
print("Random secure URL is ", y)
print("+-"*40)
# ---------------------------------------------------------------------------------------------------------------------


# 9- Roll dice in such a way that every time you get the same number
# default value for seed is current system time
random.seed(0)
print("Q9 ans Dice :",random.randint(1,6))

# dice = [1, 2, 3, 4, 5, 6]
# print("Randomly selecting same number of a dice")
# for i in range(5):
#     random.seed(25)
#     print(random.choice(dice))
print("+-"*40)
# --------------------------------------------------------------------------------------------------------------------



# 10- Generate a random date between given start and end dates
# import datetime
# date = datetime.date(random.randint(2020,2021),random.randint(1,12),random.randint(1,28))
# print("Q10 Random date is :",date)

import time

def getRandomDate(startDate, endDate ):
    print("Printing random date between", startDate, " and ", endDate)
    randomGenerator = random.random()
    dateFormat = '%m/%d/%Y'

    startTime = time.mktime(time.strptime(startDate, dateFormat))
    endTime = time.mktime(time.strptime(endDate, dateFormat))

    randomTime = startTime + randomGenerator * (endTime - startTime)
    randomDate = time.strftime(dateFormat, time.localtime(randomTime))
    return randomDate

print ("Random Date = ", getRandomDate("1/1/2020", "12/12/2022"))

