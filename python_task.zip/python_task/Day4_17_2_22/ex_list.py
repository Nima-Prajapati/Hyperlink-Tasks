# Python task (17 Feb, 2022):
# List: Lists are used to store multiple items in a single variable.
# Lists are one of 4 built-in data types in Python used to store collections of data, the other 3 are Tuple, Set, and Dictionary, all with different qualities and usage.
# Lists are created using square brackets.List items are ordered, changeable, and allow duplicate values.
# methods : append(),clear(),copy(),count(),extend(),index(),insert(),pop(),remove(),reverse(),sort()





#1 Reverse a list in Python
a = [1,2,3,5,7]
a.reverse()
print("Q1 ans Reversed list : ",a)
print("+-"*40)
# op:Reversed list :  [7, 5, 3, 2, 1]
# ---------------------------------------------------------------------------

# 2- Concatenate two lists index-wise
a = [1,2,3,5,7]
b = [4,6,8]
a.extend(b)
# ans=a+b
# print("Q2 ans:",ans)  op:Q2 ans: [1, 2, 3, 5, 7, 4, 6, 8, 4, 6, 8]
print("Q2 ans Concatenated list using list.extend() : ",a)
print("+-"*40)
# op:Concatenated list using list.extend() :  [1, 2, 3, 5, 7, 4, 6, 8]
# ------------------------------------------------------------------------------

# 3- Turn every item of a list into its square
a = [1, 2, 3, 4, 5]
squared_numbers = [number ** 2 for number in a]
print("Q3 ans Square : ",squared_numbers)
# op:Square :  [1, 4, 9, 16, 25]

# 2
print("Q3 ans :")
for i in a:
    i=i*i
    print(i)
print("+-"*40)
# ----------------------------------------------------------------------------

# 4- Concatenate two lists in the following order
list1 = ["Hello ", "take "]
list2 = ["Dear", "Sir"]
print("Q4 ans :")
print([x+y for x in list1 for y in list2])
print("+-"*40)
# Output : ['Hello Dear', 'Hello Sir', 'take Dear', 'take Sir']
# ----------------------------------------------------------------------------

# 5- Iterate both lists simultaneously
# over 3 lists using zip function
import itertools
num = [1, 2, 3]
color = ['red', 'while', 'black']
print("Q5 ans:")
for i in num:
    for j in color:
        print(str(i)+str(j))

# 2 times as len(value)= 2 which is the minimum among all the three
for (a, b) in zip(num, color):
    print(a, b)
# op:1 red
# 2 while
# 3 black
for i in num + color:
    print(i, end =" ")
print()
# op:1 2 3 red while black
print("+-"*40)

# ---------------------------------------------------------------------------------
# 6- Remove empty strings from the list of strings
a = ["","apple","","orange"]
while("" in a):
    a.remove("")
print("Q6 ans After removing empty string : ",a)
print("+-"*40)
# op:After removing empty string :  ['apple', 'orange']
# --------------------------------------------------------------------------------------------------------------------

# 7- Add new item to list after a specified item
a = [1,3,4,5,6]
print("Q7 ans : ")
a.insert(1,"abc")
print(a)
print("+-"*40)
# op:[1, 'abc', 3, 4, 5, 6]
# -----------------------------------------------------------------------------------------------------------------

# 8- Extend nested list by adding the sublist
a = ["a","b",["c","d"],"e"]
b = [4,6,8]
a[2].extend(b)
print("Q8 ans : ",a)
print("+-"*40)
# op:Q8 ans :  ['a', 'b', ['c', 'd', 4, 6, 8], 'e']
# ----------------------------------------------------------------------------------------------------------------------

# 9- Replace list’s item with new value if found
q9 = ['Hardik', 'Rohit', 'Rahul', 'Virat', 'Pant']
# find the index of Rahul
i = q9.index('Rahul')
print(i)
# replace Rahul with Shikhar
q9 = q9[:i] + ['Shikhar'] + q9[i + 1:]
print("Q9 ans : ",q9)
print("+-"*40)
# op:2
# Q9 ans :  ['Hardik', 'Rohit', 'Shikhar', 'Virat', 'Pant']
# ---------------------------------------------------------------------------------------------------------------------

# 10- Remove all occurrences of a specific item from a list.
a = [1, 3, 4, 6, 5, 1]
b = 1
# remove the item for all its occurrences
for i in a:
    if (i == b):
        a.remove(i)
print("Q10 ans :",a)
print("+-"*40)
# op:Q10 ans : [3, 4, 6, 5]
# ------------------------------------------------------------------------------------------------------------------







