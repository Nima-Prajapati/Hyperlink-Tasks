"""
python task (23 Feb, 2022):

Task 2:
 - Area of Circle
 - Area of Rectangle
 - Area of square
 - Exit
"""


def circle(radius):
    print("Area of Circle", 3.14 * radius * radius)
    print("#"*50)

def rectangle(length, breadth):
    print("Area of Rectangle:", length * breadth)
    print("#" * 50)

def square(side):
    print("Area:", side * side)
    print("#" * 50)

while True:
    print("#" * 50)
    print("Menu Driven Program")
    print("1.Area of Circle")
    print("2.Area of Rectangle")
    print("3.Area of Square")
    print("0.Exit")
    print("#" * 50)
    choice = int(input("Enter your choice:"))

    try:
        if choice in (1, 2, 3):
            if choice == 1:
                radius = int(input("Enter radius of Circle:"))
                circle(radius)
            elif choice == 2:
                length = int(input("Enter Height of Rectangle:"))
                breadth = int(input("Enter Width of Rectangle:"))
                rectangle(length, breadth)
            elif choice == 3:
                side = int(input("Enter side of Square:"))
                square(side)
            else:
                print("Wrong Choice")
        else:
            break

    except ValueError:
        print("Please enter valid number")
    except KeyboardInterrupt:
        print("Press ctrl+c")
    finally:
        print("Thank you....")
        print("#"*50)


"""
2nd way
"""
# print("#"*50)
# print("area calculation")
# print("#"*50)
#
#
# PI=3.14159265359
# def cases(num):
#     print(num)
#     match num:
#
#         case 1:
#             try:
#                 r = float(input("Enter the Radius :"))
#             except:
#                 print("Please enter only numeric value")
#             print("#" * 50)
#             print("Area of Circle :", PI*r*r)
#             print("#" * 50)
#             choicefuc()
#         case 2:
#             try:
#                 w=float(input("enter the width:"))
#                 l=float(input("enter the length:"))
#             except:
#                 print("Please enter only numeric value")
#             print("#" * 50)
#             print("Area of Rectangl :", w*l)
#             print("#" * 50)
#             choicefuc()
#         case 3:
#             try:
#                 a=float(input("enter the side:"))
#             except:
#                 print("Please enter only numeric value")
#             print("#" * 50)
#             print("Area of square :", a*a)
#             print("#" * 50)
#             choicefuc()
#         case 4:
#             exit()
#
#
# def choicefuc():
#     print("Menu choice for Area")
#     print("1,Area of Circle")
#     print("2,Area of Rectangle")
#     print("3,Area of square")
#     print("4.Exit")
#     print("#"*50)
#
#     choice = int(input("Enter your choice :"))
#     cases(choice)
# choicefuc()
