"""
Menu driven student management system using while and if--else


python task (23 Feb, 2022):

Menu Driven task
----------------------------------------------
Task 3: Build a simple Student Management System
    - Display all student list
    - Add student detail (Rollno, Name, Gender, Age, department, semester, subjects)
        a. subjects : subject_code and subject_name
    - Search student by rollno, name, department
    - Delete student detail
    - Update student detail
    - Sorting (Rollno, Name, department, semester, Age)

"""




# student_list = [
#     {"roll_num": 1, "name": "Tapu", "gender": "Male", "age": 19, "department": "Computer science", "semester": 3,
#      "subject": [{"sub_code": 11, "sub_name": "DBMS"}, {"sub_code": 11, "sub_name": "DBMS"}]},
#     {"roll_num": 2, "name": "Goli", "gender": "Male", "age": 19, "department": "Information Technology", "semester": 3,
#      "subject": [{"sub_code": 12, "sub_name": "DS"}]}
#     # {"roll_num": 3, "name": "Gogi", "gender": "Male", "age": 18, "department": "Information Technology", "semester": 1,
#     #  "subject": [{"sub_code": 10, "sub_name": "Maths-1"}]}
#     ]

# student_list = []
student = {}
import re

while True:
    print("Simple Student Management System\n"
          "1. Display all student list\n"
          "2. Add student detail (Rollno, Name, Gender, Age, department, semester, subjects)\n"
          "3. Search student by rollno, name, department\n"
          "4. Delete student detail\n"
          "5. Update student detail\n"
          "6. Sorting (Rollno, Name, department, semester, Age)\n"
          "0. Exit\n")
    try:

        select = int(input("Select operations between 1, 2, 3, 4, 5, 6, 0 :"))
        if select == 0:
            break

        if select == 1:
            if student == {}:
                print("Dictionary is empty")
            else:
                print("----Display All Students-----")
                print("*" * 20)
                for i, j in student.items():
                    print("Student ID:", i)

                    for key in j:
                        print(key + ':', j[key])
                    print("-"*50)

                # for i in student_list:
                #     for j in i.items():
                #         if j[0] == 'subject':
                #             print(j[0], ':')
                #             for subject in j[1]:
                #                 print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-', subject['sub_name'])
                #             print('-' * 80)
                #         else:
                #             print(j[0], ':', j[1])

        elif select == 2:
            print("----Add Student-----")
            print("*" * 20)
            r_no = int(input('Enter Roll Number: '))
            for i in range(1, len(student) + 1):
                if student[i]['Roll_no'] == r_no and r_no != 0:
                    print("Entered roll number is exists please enter another roll number")
                    break
            else:
                name = input('Enter Name : ')
                gender = input('Enter Gender : ')
                age = int(input('Enter Age : '))
                department = input('Enter Department : ')
                semester = int(input('Enter Semester : '))

                a = {}
                subj = int(input("How Many Subject Add : "))

                for i in range(subj):
                    scode = int(input("Enter Subject code : "))
                    sub = input("Enter Subject : ")
                    a.update({scode: sub})

                if r_no == 0:
                    print("*" * 20)
                    print("Enter Valid Number which is greater than zero")

                elif r_no == " " or name == " " or gender == " " or age == " " or department == " " or semester == " ":
                    print("Please Enter Valid Input")

                else:
                    roll = len(student) + 1
                    student.update({roll: {"Roll_no": r_no, "Name": name, "Gender": gender, "Age": age,
                                           "Department": department, "Semester": semester, "Subjects": a}})
                    print("Record inserted...")
                    for i, j in student[roll].items():
                        print(i + ':', j)


            # add_dict = {}
            # # flag = True
            # while True:
            #     try:
            #         enter_len = int(input("How Many Number of Student Record you want to Add ?: "))
            #         if enter_len > 0:
            #             break
            #             # flag = False
            #         else:
            #             print("Enter Number greater than zero")
            #     except ValueError:
            #         print("Enter integer value")
            #         # flag = True
            #
            # for record in range(0, enter_len):
            #     # flag = True
            #     while True:
            #         try:
            #             roll_num = int(input("Enter Roll Number:"))
            #             get_roll_num = any(s["roll_num"] == roll_num for s in student_list)
            #             if roll_num > 0:
            #                 if not get_roll_num:
            #                     add_dict.update({"roll_num": roll_num})
            #                     break
            #                     # flag = False
            #                 else:
            #                     print("Roll number Already Exists !")
            #                     # flag = True
            #             else:
            #                 print("Enter Number greater than zero")
            #                 # flag = True
            #         except ValueError:
            #             print("Enter integer value")
            #             # flag = True
            #     # flag = True
            #     while True:
            #         name = str(input("Enter Name:"))
            #         n1 = re.findall("(\d+)",name)
            #         if n1:
            #             print("Enter Char Only")
            #             # flag = True
            #         else:
            #             break
            #             # flag = False
            #
            #     flag = True
            #     while flag:
            #         gender = str(input("Enter Gender(male or Male or female or Female):"))
            #         if "male" == gender or "Male" == gender or "female" == gender or "Female" == gender:
            #             break
            #             # flag = False
            #         else:
            #             print("Enter Only Male or Female")
            #             # flag = True
            #
            #     # flag = True
            #     while True:
            #         try:
            #             age = int(input("Enter Age:"))
            #             if age > 0:
            #                 break
            #                 # flag = False
            #             else:
            #                 print("Enter Number greater than zero")
            #         except ValueError:
            #             print("Enter only positive Number")
            #             # flag = True
            #
            #     # flag = True
            #     while True:
            #         department = str(input("Enter Department name :"))
            #         n1 = re.findall("(\d+)", department)
            #         if n1:
            #             print("Enter Character only")
            #             # flag = True
            #         else:
            #             break
            #             # flag = False
            #
            #     # flag = True
            #     while True:
            #         try:
            #             sem = int(input("Enter Semester:"))
            #             if sem > 0:
            #                 break
            #                 # flag = False
            #             else:
            #                 print("Enter Number greater than zero")
            #         except ValueError:
            #             print("Enter only postive Number")
            #             # flag = True
            #
            #     add_sub_dict = {}
            #     add_sub_list = []
            #     add_dict.update(
            #         {"roll_num": roll_num, "name": name, "gender": gender, "age": age, "department": department,
            #          "semester": sem, "subject": add_sub_list})
            #     # {'roll_num': 1, 'name': 'Tapu', 'gender': 'Male', 'age': 19, 'department': 'Computer science', 'semester': 3,
            #     # 'subject': [{'sub_code': 11, 'sub_name': 'DBMS'}, {'sub_code': 11, 'sub_name': 'DBMS'}]}
            #
            #     # flag = True
            #     while True:
            #         try:
            #             enter_num_of_sub = int(input("How Many Number of subject you want to Add: "))
            #             if enter_num_of_sub > 0:
            #                 break
            #                 # flag = False
            #             else:
            #                 print("Enter Number greater than zero")
            #         except ValueError:
            #             print("Enter only postive Number")
            #             # flag = True
            #     # enter_num_of_sub = int(input("How Many Number of subject you want to Add: "))
            #     for sub_ject in range(0, enter_num_of_sub):
            #         # flag = True
            #         while True:
            #             try:
            #                 sub_code = int(input("Subject Code:"))
            #                 if sub_code > 0:
            #                     break
            #                     # flag = False
            #                 else:
            #                     print("Enter Number greater than zero")
            #             except ValueError:
            #                 print("Enter only postive Number")
            #                 # flag = True
            #
            #         # flag = True
            #         while True:
            #             sub_name = str(input("Subject Name:"))
            #             n1 = re.findall("(\d+)",sub_name)
            #             if n1:
            #                 print("Enter Char Only")
            #                 # flag = True
            #             else:
            #                 break
            #                 # flag = False
            #
            #         add_sub_dict.update({"sub_code": sub_code, "sub_name": sub_name})
            #         add_sub_list.append(add_sub_dict)
            #     student_list.append(add_dict)
            #
            # for i in student_list:
            #     for j in i.items():
            #         if j[0] == 'subject':
            #             print(j[0], ':')
            #             for subject in j[1]:
            #                 print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-', subject['sub_name'])
            #             print('-' * 80)
            #         else:
            #             print(j[0], ':', j[1])

        elif select == 3:

            while (True):
                print("1.Search Roll No")
                print("2.Search Name")
                print("3.Search Department")
                print("0.Exit\n")
                print("*" * 20)

                try:
                    numb1 = int(input("Enter Your Choice : "))
                    if numb1 < 0:
                        raise ValueError
                    elif numb1 == 0:
                        break
                        # exit()
                    else:
                        if student == {}:
                            print("Student Details Not Found")
                        else:
                            if numb1 == 1:
                                print("Search By Roll No")
                                rlno = int(input("Enter Roll No : "))
                                for m,j in student.items():
                                    if student[m]["Roll_no"] == rlno:
                                        print(student[m])
                                    else:
                                        print("Student not found")
                                # for i in student:
                                #     if student[i]["Roll_no"] == rlno:
                                #         print(m + ':', j)
                            elif numb1 == 2:
                                print("Search BY Name Student")
                                nam = input("Enter Name : ")
                                for m,j in student.items():
                                    if student[m]["Name"] == nam:
                                        print(student[m])
                                    else:
                                        print("Student not found")
                                # for i in student:
                                #     if student[i]["Name"] == nam:
                                #         for m, j in student[i].items():
                                #             print(m + ':', j)
                            elif numb1 == 3:
                                print("Search By Department Student")
                                dep = input("Enter Department : ")
                                for m,j in student.items():
                                    if student[m]["Department"] == dep:
                                        print(student[m])
                                    else:
                                        print("Student not found")
                                # for i in student:
                                #     if student[i]["Department"] == dep:
                                #         print(m + ':', j)

                        if numb1 >= 4:
                            print("Please Enter Valid Choice Number")
                except ValueError as v:
                    print("\n ===> Error : Please Enter Valid Number Input <===\n")
                except KeyboardInterrupt as k:
                    print(k)

            # while True:
            #     print("Search options: \n 1.Roll Number \n 2.Name "
            #           "\n 3.department \n 0.Exit")
            #     # search_input = int(input("Enter your search option:"))
            #     # flag = True
            #     while True:
            #         try:
            #             search_input = int(input("Enter your search option:"))
            #             if search_input >= 0:
            #                 break
            #                 # flag = False
            #             else:
            #                 print("Enter Number greater than zero")
            #         except ValueError:
            #             print("Enter integer value")
            #             # flag = True
            #
            #     if search_input == 0:
            #         break
            #
            #     if search_input == 1:
            #         flag = True
            #         while flag:
            #             try:
            #                 roll_num_search = int(input("Enter Roll Number for search :"))
            #                 if roll_num_search > 0:
            #                     flag = False
            #                 else:
            #                     print("Enter Number greater than zero")
            #             except ValueError:
            #                 print("Enter integer value")
            #                 flag = True
            #         for i in range(len(student_list)):
            #             if roll_num_search == student_list[i]["roll_num"]:
            #                 print(student_list[i])
            #     elif search_input == 2:
            #         flag = True
            #         while flag:
            #             name_search = str(input("Enter Name for search :")).capitalize()
            #             n1 = re.findall("(\d+)", name_search)
            #             if n1:
            #                 print("Enter Char Only")
            #                 flag = True
            #             else:
            #                 flag = False
            #         for i in range(len(student_list)+1):
            #             if name_search == student_list[i]["name"]:
            #                 print(student_list[i])
            #
            #     elif search_input == 3:
            #         flag = True
            #         while flag:
            #             department_search = str(input("Enter Department for search :")).capitalize()
            #             n1 = re.findall("(\d+)", department_search)
            #             if n1:
            #                 print("Enter Char only")
            #                 flag = True
            #             else:
            #                 flag = False
            #         for i in range(len(student_list)):
            #             if department_search == student_list[i]["department"]:
            #                 print(student_list[i])
            #     else:
            #         continue

        elif select == 4:

            if student == {}:
                print("*" * 20)
                print("---Student Details Not Found---- ")
            else:
                d_no = int(input("Enter student roll number that you want to delete:"))
                del student[d_no]
                # for i in student:
                #     print("*" * 20)
                #     print(
                #         f'Roll NO = {student[i]["Roll_no"]}\nName = {student[i]["Name"]}\nGender = {student[i]["Gender"]}\nDepartment = {student[i]["Department"]}\nSemester = {student[i]["Semester"]}\nSubjects = {student[i]["Subjects"]}\n')

            # for i in range(len(student_list)):
            #     flag = True
            #     while flag:
            #         try:
            #             delete_data = int(input("Enter Roll Number for delete :"))
            #             if delete_data > 0:
            #                 flag = False
            #             else:
            #                 print("Enter Number greater than zero")
            #         except ValueError:
            #             print("Enter integer value")
            #             flag = True
            #     if delete_data == student_list[i]["roll_num"]:
            #         del student_list[i]
            #         for i in student_list:
            #             for j in i.items():
            #                 if j[0] == 'subject':
            #                     print(j[0], ':')
            #                     for subject in j[1]:
            #                         print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-',
            #                               subject['sub_name'])
            #                     print('-' * 80)
            #                 else:
            #                     print(j[0], ':', j[1])
            #         break

        elif select == 5:
            while (True):
                print("Update Students")
                print("1.Update Roll No")
                print("2.Update Name")
                print("3.Update Gender")
                print("4.Update Age")
                print("5.Update Department")
                print("6.Update Semester")
                print("7.Update Subject")
                print("0.Exit")
                try:
                    numb3 = int(input("Enter Your Choice : "))
                    if numb3 < 0:
                        raise ValueError
                    elif numb3 == 0:
                        break
                    else:
                        if student == {}:
                            print("Student Details Not Found")
                        else:
                            if numb3 == 1:
                                print("Update Student Roll No ")
                                print("*" * 20)
                                l = int(input("Enter Student Id :"))
                                print("*" * 20)
                                ra_no = int(input("Enter New Roll Number = "))
                                for m in student:
                                    student[l].update({"Roll_no": ra_no})
                                    print("\nRecord Updated...\n")

                                    for i, j in student[l].items():
                                        print(i + ':', j)

                            elif numb3 == 2:
                                print("Update Student Name")
                                print("*" * 20)
                                l = int(input("Enter Student Id :"))
                                print("*" * 20)
                                nam = input("Enter New Name : ")
                                for m in student:
                                    student[l].update({"Name": nam})
                                    print("Record Updated...")
                                    for i, j in student[l].items():
                                        print(i + ':', j)

                            elif numb3 == 3:
                                print("Update Student Gender")
                                print("*" * 20)
                                l = int(input("Enter Student Id :"))
                                print("*" * 20)
                                gen = input("Enter New Gender : ")
                                for m in student:
                                    student[l].update({"Gender": gen})
                                    print("Record Updated...")
                                    for i, j in student[l].items():
                                        print(i + ':', j)
                            elif numb3 == 4:
                                print("Update Student Age")
                                print("*" * 20)
                                l = int(input("Enter Student Id :"))
                                print("*" * 20)
                                ag = input("Enter New Age : ")
                                for m in student:
                                    student[l].update({"Age": ag})
                                    print("Record Updated...")
                                    for i, j in student[l].items():
                                        print(i + ':', j)

                            elif numb3 == 5:
                                print("Update Student Department")
                                print("*" * 20)
                                l = int(input("Enter Student Id :"))
                                print("*" * 20)
                                dep = input("Enter New Department : ")
                                for m in student:
                                    student[l].update({"Department": dep})
                                    print("Record Updated...")
                                    for i, j in student[l].items():
                                        print(i + ':', j)

                            elif numb3 == 6:
                                print("Update Student Semester")
                                print("*" * 20)
                                l = int(input("Enter Student Id :"))
                                print("*" * 20)
                                sem = input("Enter New Semester : ")
                                for m in student:
                                    student[l].update({"Semester": sem})
                                    print("\nRecord Updated...\n")
                                    for i, j in student[l].items():
                                        print(i + ':', j)

                            elif numb3 == 7:
                                print("Update Student Subject ")
                                print("*" * 20)
                                # l = int(input("Enter Student Id :"))
                                # print("*" * 20)
                                a = {}
                                l = int(input("Enter Student Id :"))
                                subj = int(input("How Many Subjects Update : "))

                                for i in range(subj):
                                    scode = int(input("Enter Subject code : "))
                                    sub = input("Enter Subject Name : ")
                                    a.update({scode: sub})

                                student[l].update({"Subjects": a})
                                print("Record Updated...")
                                for i, j in student[l].items():
                                    print(i + ':', j)

                        if numb3 > 7:
                            print("Please Enter Valid Choice Number")

                except ValueError as v:
                    print("Please Enter Valid Number Input")
                except KeyboardInterrupt as k:
                    print(k)
        #     try:
        #         roll_num_updt = int(input('Which Roll Number data you want to update: '))
        #         result = [s for s in student_list if s.get('roll_num') == roll_num_updt]
        #         for update_result in result:
        #             rollno = int(input("Enter Your New Roll Number: "))
        #             update_result['roll_num'] = rollno
        #             name = input("Enter Your Name: ")
        #             update_result['name'] = name
        #             gender = input("Enter Your gender: ")
        #             update_result['gender'] = gender
        #             age = int(input("Enter Your age Number: "))
        #             update_result['age'] = age
        #             department = input("Enter Your Department: ")
        #             update_result['department'] = department
        #             semester = input("Enter Your Semester: ")
        #             update_result['semester'] = semester
        #             my_update_lst = []
        #             for sub_update in update_result['subject']:
        #                 sub_code = input("Enter subject code: ")
        #                 sub_name = input("Enter subject name: ")
        #                 if sub_code and sub_name:
        #                     my_update_lst.append({sub_code: sub_name})
        #             update_result['subject'] = my_update_lst
        #         print(student_list)
        #
        #     except ValueError:
        #         print('Only integers values')
        #         continue

        elif select == 6:
            while (True):
                print("----Sorting Students----")
                print("1.Sorting Roll No")
                print("2.Sorting Name")
                print("3.Sorting Department")
                print("4.Sorting Semester")
                print("5.Sorting Age")
                print("0.Exit")
                print("*" * 20)

                try:
                    numb2 = int(input("Enter Your Choice : "))
                    print("*" * 20)
                    if numb2 < 0:
                        raise ValueError
                    elif numb2 == 0:
                        break
                    else:
                        if student == {}:
                            print("---Student Details Not Found---")
                        else:
                            if numb2 == 1:
                                print("---Sorting Roll No Wise Student---")
                                Roll_no = dict(sorted(student.items(), key=lambda x: x[1]['Roll_no']))
                                for i, j in Roll_no.items():
                                    print("Person ID:", i)
                                    for key in j:
                                        print(key + ':', j[key])

                            elif numb2 == 2:
                                print("---Sorting Name Wise Student---")
                                name = dict(sorted(student.items(), key=lambda x: x[1]['Name']))
                                for i, j in name.items():
                                    print("Person ID:", i)

                                    for key in j:
                                        print(key + ':', j[key])

                            elif numb2 == 3:
                                print("---Sorting Department Wise Student---")

                                department = dict(sorted(student.items(), key=lambda x: x[1]['Department']))
                                for i, j in department.items():
                                    print("Person ID:", i)
                                    for key in j:
                                        print(key + ':', j[key])

                            elif numb2 == 4:
                                print("---Sorting Semester Wise Student---")

                                semester = dict(sorted(student.items(), key=lambda x: x[1]['Semester']))
                                for i, j in semester.items():
                                    print("\nPerson ID:", i)
                                    for key in j:
                                        print(key + ':', j[key])

                            elif numb2 == 5:
                                print("---Search Age Wise Student---")

                                Age = dict(sorted(student.items(), key=lambda x: x[1]['Age']))
                                for i, j in Age.items():
                                    print("Person ID:", i)
                                    for key in j:
                                        print(key + ':', j[key])

                    if numb2 >= 6:
                        print("*" * 20)
                        print("---Please Enter Valid Choice Number---")

                except ValueError as v:
                    print("Error : Please Enter Valid Number Input")
                except KeyboardInterrupt as k:
                    print(k)


        #     while True:
        #         print("Sorting options: \n 1.rollnum \n 2.Name "
        #               "\n 3.department \n 4.semester \n 5.Age \n 0.Exit")
        #         sort_input = int(input("Enter your sorting option:"))
        #         if sort_input == 0:
        #             break
        #
        #         if sort_input == 1:
        #             s1 = sorted(student_list, key=lambda i: i["roll_num"])
        #             for i in s1:
        #                 for j in i.items():
        #                     if j[0] == 'subject':
        #                         print(j[0], ':')
        #                         for subject in j[1]:
        #                             print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-',
        #                                   subject['sub_name'])
        #                         print('-' * 80)
        #                     else:
        #                         print(j[0], ':', j[1])
        #         elif sort_input == 2:
        #             s2 = sorted(student_list, key=lambda i: i["name"])
        #             for i in s2:
        #                 for j in i.items():
        #                     if j[0] == 'subject':
        #                         print(j[0], ':')
        #                         for subject in j[1]:
        #                             print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-',
        #                                   subject['sub_name'])
        #                         print('-' * 80)
        #                     else:
        #                         print(j[0], ':', j[1])
        #         elif sort_input == 3:
        #             s3 = sorted(student_list, key=lambda i: i["department"])
        #             for i in s3:
        #                 for j in i.items():
        #                     if j[0] == 'subject':
        #                         print(j[0], ':')
        #                         for subject in j[1]:
        #                             print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-',
        #                                   subject['sub_name'])
        #                         print('-' * 80)
        #                     else:
        #                         print(j[0], ':', j[1])
        #         elif sort_input == 4:
        #             s4 = sorted(student_list, key=lambda i: i["semester"])
        #             for i in s4:
        #                 for j in i.items():
        #                     if j[0] == 'subject':
        #                         print(j[0], ':')
        #                         for subject in j[1]:
        #                             print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-',
        #                                   subject['sub_name'])
        #                         print('-' * 80)
        #                     else:
        #                         print(j[0], ':', j[1])
        #         elif sort_input == 5:
        #             s5 = sorted(student_list, key=lambda i: i["age"])
        #             for i in s5:
        #                 for j in i.items():
        #                     if j[0] == 'subject':
        #                         print(j[0], ':')
        #                         for subject in j[1]:
        #                             print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-',
        #                                   subject['sub_name'])
        #                         print('-' * 80)
        #                     else:
        #                         print(j[0], ':', j[1])
        #         else:
        #             continue

        else:
            print("Enter valid input")
            continue

    except ValueError:
        print("Please enter only numeric")
        print("#"*50)
    except ImportError:
        print("Import module properly")
    except IndexError:
        print("list index out of range")
    except KeyError:
        print("Key not found")
    except NameError:
        print("variable is not found in local or global scope")
    except SyntaxError:
        print("Invalid syntax")
    except IndentationError:
        print("Give proper indentation")
    except TypeError:
        print("function or operation is applied to an object of incorrect type")
    except EOFError:
        print("End of line")
        print()















# aa while loop ma validation and input by user vadu logic
#
# inputByUser = input("Enter employe Name\n")
#         while True:
#             if inputByUser.isalpha() and len(inputByUser) <= 10 and len(inputByUser) >= 1:
#                 tempEmploye["name"] = inputByUser.lower().capitalize()
#                 break
#             else:
#                 print("Name only contain characters.\nEnter employe {}")
#                 inputByUser = input()





# same for email
#
# regex = "(^[a-zA-Z0-9_.]+@[a-zA-Z.]+[a-z]{2,3}$)"
#         inputByUser = input("Enter employe email\n")
#         while True:
#             if re.search(regex, inputByUser):
#                 tempEmploye["email"] = inputByUser
#                 break
#             else:
#                 print("Not proper email format.\n Enter employe email")
#                 inputByUser = input()







# me function based karu che so aa function che
#
#
#
# import re
#
# i, count = 0, 1
# idSet = set()
# desigination = (
#     'Python Dev. ', 'Java Dev. ', 'Node Js. Dev. ', 'Angular Dev. ', 'Team Lead ', 'Project Manager ',
#     'CEO', 'Director')
# employeFormat = ['Id', 'name', 'phone', 'email', 'desigination', 'experience', 'address']
# employeName = dict()
#
# inputByUser = ""
#
#
# def viewCode():
#     for employs in employeName:
#         print('')
#         i = 0
#         for data, value in employeName[employs].items():
#             if i == 4:
#                 print(data, ' : ', desigination[int(value)])
#             else:
#                 print(data, ' : ', value)
#             i += 1
#
#
# def view():
#     """View() function for viewing employes details"""
#     print("---> View Mode <---")
#     if not employeName:
#         print("First enter employs data....")
#         addEmploye()
#     else:
#         viewCode()
#
#
# def addEmploye():
#     """AddEmploye() function for adding employes"""
#     global count
#     print("---> Add Employs <---")
#     i = 1
#     tempEmploye = {'Id': count}
#     idSet.add(count)
#     for employe in employeFormat:
#         if i == 1:
#             i += 1
#         else:
#             # input validation for Desigination
#             if employe == 'desigination':
#                 jCount = 0
#                 for design in desigination:
#                     print(jCount + 1, '. ', design, end='')
#                     jCount += 1
#                 print("\nEnter your choice:")
#                 inputByUser = input("Enter employe choice for {}\n".format(employe))
#                 while True:
#                     if inputByUser.isdigit() and len(inputByUser) == 1:
#                         tempEmploye[employe] = int(inputByUser) - 1
#                         break
#                     else:
#                         print("Choice length is 1.\n Enter employe choice for {}\n".format(employe))
#                         inputByUser = input()
#
#             # input validation for Name
#             elif employe == 'name':
#                 inputByUser = input("Enter employe {}\n".format(employe))
#                 while True:
#                     if inputByUser.isalpha() and len(inputByUser) <= 10 and len(inputByUser) >= 1:
#                         tempEmploye[employe] = inputByUser.lower().capitalize()
#                         break
#                     else:
#                         print("Name only contain characters.\nEnter employe {}".format(employe))
#                         inputByUser = input()
#
#             # input validation for Phone
#             elif employe == 'phone':
#                 inputByUser = input("Enter employe {}\n".format(employe))
#                 while True:
#                     if inputByUser.isdigit() and len(inputByUser) == 10:
#                         tempEmploye[employe] = inputByUser
#                         break
#                     else:
#                         print("Phone no length 10.\n Enter employe {}".format(employe))
#                         inputByUser = input()
#
#             # input validation for email
#             elif employe == 'email':
#                 regex = '^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$'
#                 inputByUser = input("Enter employe {}\n".format(employe))
#                 while True:
#                     if re.search(regex, inputByUser):
#                         tempEmploye[employe] = inputByUser
#                         break
#                     else:
#                         print("Not proper email format.\n Enter employe {}".format(employe))
#                         inputByUser = input()
#
#             # input validation for experience
#             elif employe == 'experience':
#                 inputByUser = input("Enter employe choice for {}\n".format(employe))
#                 while True:
#                     if inputByUser.isdigit() and len(inputByUser) == 1:
#                         tempEmploye[employe] = int(inputByUser)
#                         break
#                     else:
#                         print("Choice must be in digit.\n Enter employe choice for {}".format(employe))
#                         inputByUser = input()
#
#             # input validation for address
#             elif employe == 'address':
#                 inputByUser = input("Enter employe {}\n".format(employe))
#                 while True:
#                     if len(inputByUser) >= 5 and len(inputByUser) <= 12:
#                         tempEmploye[employe] = inputByUser.lower().capitalize()
#                         break
#                     else:
#                         print("Address length between 5 to 12.\n enter employe {}".format(employe))
#                         inputByUser = input()
#
#     # Input end and below code is for viewing inserted student data
#     i = 0
#     for data in tempEmploye.values():
#         if i == 4:
#             print(desigination[int(data)], '  ', end='')
#         else:
#             print(data, '  ', end='')
#         i += 1
#     employeName["employeId_" + str(count)] = tempEmploye
#     count += 1
#
#
# def updateEmploye():
#     """UpdateEmploye() function for updating employes details"""
#     # employeName[Index_value][key]=3
#     print("---> Update Employs <---")
#     viewCode()
#     print("\n---> Select Detail <---")
#     # Getting student ID
#     print("\nEnter ID of student:")
#     employeId = input("n/N for exit\n")
#     while True:
#         if employeId in {'n', 'N'}:
#             break
#         elif not employeId.isdigit():
#             print("Enter correct no of student id.\n Enter student ID.")
#             employeId = input()
#         elif not int(employeId) in idSet:
#             print("Employe id not found try again.\n Enter student ID.")
#             employeId = input()
#         else:
#             break
#
#     # Getting Field
#     jcount = 1
#     for employe in employeFormat:
#         print(jcount, '. ', employe, ' ', end='')
#         jcount += 1
#     print("\nEnter student field name number:")
#     employeField = int(input())  # getting field by number
#     jcount = 1
#     for employe in employeFormat:
#         if jcount == employeField:
#             employeField = employe  # getting field name in string
#         jcount += 1
#
#     if employeField == 'desigination':
#         print("Old detail ({}) enter new detail:".format(
#             desigination[int(employeName["employeId_" + employeId][employeField])]))
#         jCount = 0
#         for design in desigination:
#             print(jCount + 1, '. ', design, end='')
#             jCount += 1
#         print('')
#         inputByUser = str(int(input()) - 1)
#     else:
#         print(employeName["employeId_" + employeId][employeField])
#         print("Old detail ({}) enter new detail:".format(employeName["employeId_" + employeId][employeField]))
#         inputByUser = input()
#     employeName["employeId_" + employeId][employeField] = inputByUser
#
#
# def deleteEmploye():
#     """DeleteEmploye() functions for deleting employes data"""
#     print("---> Delete Employs <---")
#     viewCode()
#     print("\n---> Select Detail <---")
#     print("\nEnter ID of student:")
#     print(idSet)
#     employeId = input("n/N for exit\n")
#     while True:
#         if employeId in {'n', 'N'}:
#             break
#         elif employeId.isdigit() and int(employeId) in idSet:
#             break
#         else:
#             print("Employe id not found try again.\n Enter student ID.")
#             employeId = input()
#
#     i = 0
#     for employe in employeFormat:
#         print(employe, " ", end='')
#     print('')
#     for data, value in employeName["employeId_" + employeId].items():
#         if i == 4:
#             print(data, ' : ', desigination[int(value)])
#         else:
#             print(data, ' : ', value)
#         i += 1
#     print("\n--> Employ -- DELETED <--")
#     del employeName["employeId_" + employeId]








print("-----")
#
#
#
# student_list = [
#     {"roll_num": 1, "name": "Tapu", "gender": "Male", "age": 19, "department": "Computer science", "semester": 3,
#      "subject": [{"sub_code": 11, "sub_name": "DBMS"}, {"sub_code": 11, "sub_name": "DBMS"}]},
#     {"roll_num": 2, "name": "Goli", "gender": "Male", "age": 19, "department": "Information Technology", "semester": 3,
#      "subject": [{"sub_code": 12, "sub_name": "DS"}]}
#     # {"roll_num": 3, "name": "Gogi", "gender": "Male", "age": 18, "department": "Information Technology", "semester": 1,
#     #  "subject": [{"sub_code": 10, "sub_name": "Maths-1"}]}
#     ]
#
# # student_list = []
# import re
#
# while True:
#     print("Simple Student Management System\n" \
#           "1. Display all student list\n" \
#           "2. Add student detail (Rollno, Name, Gender, Age, department, semester, subjects)\n" \
#           "3. Search student by rollno, name, department\n" \
#           "4. Delete student detail\n" \
#           "5. Update student detail\n" \
#           "6. Sorting (Rollno, Name, department, semester, Age)\n"
#           "0. Exit\n")
#
#     select = int(input("Select operations between 1, 2, 3, 4, 5, 6, 0 :"))
#     if select == 0:
#         break
#
#     if select == 1:
#         for i in student_list:
#             for j in i.items():
#                 if j[0] == 'subject':
#                     print(j[0], ':')
#                     for subject in j[1]:
#                         print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-', subject['sub_name'])
#                     print('-' * 80)
#                 else:
#                     print(j[0], ':', j[1])
#
#     elif select == 2:
#         add_dict = {}
#         flag = True
#         while flag:
#             try:
#                 enter_len = int(input("How Many Number of Student Record you want to Add ?: "))
#                 if enter_len > 0:
#                     flag = False
#                 else:
#                     print("Enter Number greater than zero")
#             except ValueError:
#                 print("Enter integer value")
#                 flag = True
#
#         for record in range(0, enter_len):
#             flag = True
#             while flag:
#                 try:
#                     roll_num = int(input("Roll Number:"))
#                     get_roll_num = any(s["roll_num"] == roll_num for s in student_list)
#                     if roll_num > 0:
#                         if not get_roll_num:
#                             add_dict.update({"roll_num": roll_num})
#                             flag = False
#                         else:
#                             print("Roll number Already Exists !")
#                             flag = True
#                     else:
#                         print("Enter Number greater than zero")
#                         flag = True
#                 except ValueError:
#                     print("Enter integer value")
#                     flag = True
#             flag = True
#             while flag:
#                 name = str(input("Name:"))
#                 n1 = re.findall("(\d+)",name)
#                 if n1:
#                     print("Enter Char Only")
#                     flag = True
#                 else:
#                     flag = False
#
#             flag = True
#             while flag:
#                 gender = str(input("Gender(male or Male or female or Female):"))
#                 if "male" == gender or "Male" == gender or "female" == gender or "Female" == gender:
#                     # print(gender)
#                     flag = False
#                 else:
#                     print("Enter Only Male or Female")
#                     flag = True
#
#             flag = True
#             while flag:
#                 try:
#                     age = int(input("Age:"))
#                     if age > 0:
#                         flag = False
#                     else:
#                         print("Enter Number greater than zero")
#                 except ValueError:
#                     print("Enter only postive Number")
#                     flag = True
#
#             flag = True
#             while flag:
#                 department = str(input("Department:"))
#                 n1 = re.findall("(\d+)", department)
#                 if n1:
#                     print("Enter Char only")
#                     flag = True
#                 else:
#                     flag = False
#
#             flag = True
#             while flag:
#                 try:
#                     sem = int(input("Sem:"))
#                     if sem > 0:
#                         flag = False
#                     else:
#                         print("Enter Number greater than zero")
#                 except ValueError:
#                     print("Enter only postive Number")
#                     flag = True
#
#             add_sub_dict = {}
#             add_sub_list = []
#             add_dict.update(
#                 {"roll_num": roll_num, "name": name, "gender": gender, "age": age, "department": department,
#                  "semester": sem, "subject": add_sub_list})
#             # {'roll_num': 1, 'name': 'Tapu', 'gender': 'Male', 'age': 19, 'department': 'Computer science', 'semester': 3, 'subject': [{'sub_code': 11, 'sub_name': 'DBMS'}, {'sub_code': 11, 'sub_name': 'DBMS'}]}
#
#             flag = True
#             while flag:
#                 try:
#                     enter_num_of_sub = int(input("How Many Number of subject you want to Add: "))
#                     if enter_num_of_sub > 0:
#                         flag = False
#                     else:
#                         print("Enter Number greater than zero")
#                 except ValueError:
#                     print("Enter only postive Number")
#                     flag = True
#             # enter_num_of_sub = int(input("How Many Number of subject you want to Add: "))
#             for sub_ject in range(0, enter_num_of_sub):
#                 flag = True
#                 while flag:
#                     try:
#                         sub_code = int(input("Subject Code:"))
#                         if sub_code > 0:
#                             flag = False
#                         else:
#                             print("Enter Number greater than zero")
#                     except ValueError:
#                         print("Enter only postive Number")
#                         flag = True
#
#                 flag = True
#                 while flag:
#                     sub_name = str(input("Subject Name:"))
#                     n1 = re.findall("(\d+)",sub_name)
#                     if n1:
#                         print("Enter Char Only")
#                         flag = True
#                     else:
#                         flag = False
#
#                 add_sub_dict.update({"sub_code": sub_code, "sub_name": sub_name})
#                 add_sub_list.append(add_sub_dict)
#             student_list.append(add_dict)
#         for i in student_list:
#             for j in i.items():
#                 if j[0] == 'subject':
#                     print(j[0], ':')
#                     for subject in j[1]:
#                         print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-', subject['sub_name'])
#                     print('-' * 80)
#                 else:
#                     print(j[0], ':', j[1])
#
#     elif select == 3:
#         while True:
#             print("Search options: \n 1.Roll Number \n 2.Name "
#                   "\n 3.department \n 0.Exit")
#             # search_input = int(input("Enter your search option:"))
#             flag = True
#             while flag:
#                 try:
#                     search_input = int(input("Enter your search option:"))
#                     if search_input >= 0:
#                         flag = False
#                     else:
#                         print("Enter Number greater than zero")
#                 except ValueError:
#                     print("Enter integer value")
#                     flag = True
#
#             if search_input == 0:
#                 break
#
#             if search_input == 1:
#                 flag = True
#                 while flag:
#                     try:
#                         roll_num_search = int(input("Roll Number:"))
#                         if roll_num_search > 0:
#                             flag = False
#                         else:
#                             print("Enter Number greater than zero")
#                     except ValueError:
#                         print("Enter integer value")
#                         flag = True
#                 for i in range(len(student_list)):
#                     if roll_num_search == student_list[i]["roll_num"]:
#                         print(student_list[i])
#             elif search_input == 2:
#                 flag = True
#                 while flag:
#                     name_search = str(input("Name:")).capitalize()
#                     n1 = re.findall("(\d+)", name_search)
#                     if n1:
#                         print("Enter Char Only")
#                         flag = True
#                     else:
#                         flag = False
#                 for i in range(len(student_list)):
#                     if name_search in student_list[i]["name"]:
#                         print(student_list[i])
#
#             elif search_input == 3:
#                 flag = True
#                 while flag:
#                     department_search = str(input("Department:")).capitalize()
#                     n1 = re.findall("(\d+)", department_search)
#                     if n1:
#                         print("Enter Char only")
#                         flag = True
#                     else:
#                         flag = False
#                 for i in range(len(student_list)):
#                     if department_search in student_list[i]["department"]:
#                         print(student_list[i])
#             else:
#                 continue
#
#     elif select == 4:
#         for i in range(len(student_list)):
#             flag = True
#             while flag:
#                 try:
#                     delete_data = int(input("Roll Number:"))
#                     if delete_data > 0:
#                         flag = False
#                     else:
#                         print("Enter Number greater than zero")
#                 except ValueError:
#                     print("Enter integer value")
#                     flag = True
#             if delete_data == student_list[i]["roll_num"]:
#                 del student_list[i]
#                 for i in student_list:
#                     for j in i.items():
#                         if j[0] == 'subject':
#                             print(j[0], ':')
#                             for subject in j[1]:
#                                 print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-',
#                                       subject['sub_name'])
#                             print('-' * 80)
#                         else:
#                             print(j[0], ':', j[1])
#                 break
#
#     elif select == 5:
#         try:
#             roll_num_updt = int(input('Which Roll Number data you want to update: '))
#             result = [s for s in student_list if s.get('roll_num') == roll_num_updt]
#             for update_result in result:
#                 rollno = int(input("Enter Your New Roll Number: "))
#                 update_result['roll_num'] = rollno
#                 name = input("Enter Your Name: ")
#                 update_result['name'] = name
#                 gender = input("Enter Your gender: ")
#                 update_result['gender'] = gender
#                 age = int(input("Enter Your age Number: "))
#                 update_result['age'] = age
#                 department = input("Enter Your Department: ")
#                 update_result['department'] = department
#                 semester = input("Enter Your Semester: ")
#                 update_result['semester'] = semester
#                 my_update_lst = []
#                 for sub_update in update_result['subject']:
#                     sub_code = input("Enter subject code: ")
#                     sub_name = input("Enter subject name: ")
#                     if sub_code and sub_name:
#                         my_update_lst.append({sub_code: sub_name})
#                 update_result['subject'] = my_update_lst
#             print(student_list)
#
#         except ValueError:
#             print('Only integers values')
#             continue
#
#     elif select == 6:
#         while True:
#             print("Sorting options: \n 1.rollnum \n 2.Name "
#                   "\n 3.department \n 4.semester \n 5.Age \n 0.Exit")
#             sort_input = int(input("Enter your sorting option:"))
#             if sort_input == 0:
#                 break
#
#             if sort_input == 1:
#                 s1 = sorted(student_list, key=lambda i: i["roll_num"])
#                 for i in s1:
#                     for j in i.items():
#                         if j[0] == 'subject':
#                             print(j[0], ':')
#                             for subject in j[1]:
#                                 print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-',
#                                       subject['sub_name'])
#                             print('-' * 80)
#                         else:
#                             print(j[0], ':', j[1])
#             elif sort_input == 2:
#                 s2 = sorted(student_list, key=lambda i: i["name"])
#                 for i in s2:
#                     for j in i.items():
#                         if j[0] == 'subject':
#                             print(j[0], ':')
#                             for subject in j[1]:
#                                 print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-',
#                                       subject['sub_name'])
#                             print('-' * 80)
#                         else:
#                             print(j[0], ':', j[1])
#             elif sort_input == 3:
#                 s3 = sorted(student_list, key=lambda i: i["department"])
#                 for i in s3:
#                     for j in i.items():
#                         if j[0] == 'subject':
#                             print(j[0], ':')
#                             for subject in j[1]:
#                                 print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-',
#                                       subject['sub_name'])
#                             print('-' * 80)
#                         else:
#                             print(j[0], ':', j[1])
#             elif sort_input == 4:
#                 s4 = sorted(student_list, key=lambda i: i["semester"])
#                 for i in s4:
#                     for j in i.items():
#                         if j[0] == 'subject':
#                             print(j[0], ':')
#                             for subject in j[1]:
#                                 print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-',
#                                       subject['sub_name'])
#                             print('-' * 80)
#                         else:
#                             print(j[0], ':', j[1])
#             elif sort_input == 5:
#                 s5 = sorted(student_list, key=lambda i: i["age"])
#                 for i in s5:
#                     for j in i.items():
#                         if j[0] == 'subject':
#                             print(j[0], ':')
#                             for subject in j[1]:
#                                 print('\t', 'sub_code', '-', subject['sub_code'], '\t', 'sub_name', '-',
#                                       subject['sub_name'])
#                             print('-' * 80)
#                         else:
#                             print(j[0], ':', j[1])
#             else:
#                 continue
#
#     else:
#         print("Enter valid input")
#         continue