"""
python task (23 Feb, 2022):

Menu Driven task
----------------------------------------------
Task 1: Create calculator ( +, -, /, *, %)
"""

def add(x, y):
    return x + y

def subtract(x, y):
    return x - y

def multiply(x, y):
    return x * y

def divide(x, y):
    return x / y

def mod(x,y):
    return x % y

# creating options
while True:
    print("\nMAIN MENU")
    print("calculator ( +, -, /, *, %)")
    print("1. Addition")
    print("2. Subtraction")
    print("3. Multiplication")
    print("4. Division")
    print("5. Mode")
    print("0. Exit")
    choice1 = int(input("Enter the Choice:"))

    try:

        if choice1 in (1,2,3,4,5):

            num1 = float(input("Enter first number: "))
            num2 = float(input("Enter second number: "))

            if choice1 == 1:
                print(num1, "+", num2, "=", add(num1, num2))
            elif choice1 == 2:
                print(num1, "-", num2, "=", subtract(num1, num2))
            elif choice1 == 3:
                print(num1, "*", num2, "=", multiply(num1, num2))
            elif choice1 == 4:
                print(num1, "/", num2, "=", divide(num1, num2))
            elif choice1 == 5:
                print(num1, "%", num2, "=", mod(num1, num2))
            # elif choice1 == 0:
            #     break
            else:
                print("Incorrect choice")
        else:
            break
    except ValueError:
        print("Please enter valid number")
    except ZeroDivisionError:
        print("You can't divide by zero")
    except KeyboardInterrupt:
        print("Press ctrl+c")
    finally:
        print("Thank you..")





"""
2nd way
"""
# print("#"*50)
# print("calculatore")
# print("#"*50)
#
# def cases(num):
#
#     if num==5:
#         exit()
#
#     num1=float(input("Enter the 1st number"))
#     num2=float(input("Enter the 2nd number"))
#     match num:
#         case 1:
#             print("#" * 50)
#             print("Addition :",num1+num2)
#             print("#" * 50)
#             choicefuc()
#         case 2:
#             print("#" * 50)
#             print("subtraction :",num1-num2)
#             print("#" * 50)
#             choicefuc()
#         case 3:
#             print("#" * 50)
#             print("multipication :",num1*num2)
#             print("#" * 50)
#             choicefuc()
#         case 4:
#             print("#" * 50)
#             print("division",num1/num2)
#             print("#" * 50)
#             choicefuc()
#
#
# def choicefuc():
#     print("menu choice for calculation")
#     print("1.addition")
#     print("2.subtraction")
#     print("3.multipication")
#     print("4.division")
#     print("5.exit")
#     choice = int(input("Enter your choice : "))
#     cases(choice)
#
# choicefuc()
