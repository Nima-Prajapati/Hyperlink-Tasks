"""
Today's python task (24 Feb, 2022)

Menu driven task with CSV File Handling
------------------------------------------------

Task 1: Build a simple Student Management System With File Handling (CSV File)
    - Display all student list
    - Add student detail (Rollno, Name, Gender, Age, department, semester, subjects)
        a. subjects : subject_code and subject_name
    - Search student by rollno, name, department
    - Delete student detail
    - Update student detail
    - Sorting (Rollno, Name, department, semester, Age)
"""
# roll, name, age, semester, subject
# 1, vishals, 24, 8, [(1, DBMS), (2, DS)]

# roll, name, age, semester, subject[(code, name)]
# 1, vishals, 24, 8, [(1, DBMS), (2, DS)]

# {1:'python', 2:'c++'}

import csv
import json
import os
student = {}
subdict = {}
field_names= ['roll_no', 'name','gender', 'age','department','semester','subjects']
student_csv = 'student.csv'
# student.update({roll: {"Roll_no": r_no, "Name": name, "Gender": gender, "Age": age,
#                                            "Department": department, "Semester": semester, "Subjects": a}})

while True:
    print("Simple Student Management System\n"
          "1. Display all student list\n"
          "2. Add student detail (Rollno, Name, Gender, Age, department, semester, subjects)\n"
          "3. Search student by rollno, name, department\n"
          "4. Delete student detail\n"
          "5. Update student detail\n"
          "6. Sorting (Rollno, Name, department, semester, Age)\n"
          "0. Exit\n")
    try:
        select = int(input("Select operations between 1, 2, 3, 4, 5, 6, 0 :"))
        if select == 0:
            break

        elif select == 1:
            if not os.path.isfile(student_csv):
                print("File not exists.")
                # Creates a new file, because file not exists.
                with open(student_csv, 'w') as fp:
                    pass
            elif os.stat('student.csv').st_size == 0:
                print("Student data not found.")
            else:
                with open('student.csv', newline='') as f:
                    reader = csv.DictReader(f)

                    for row in reader:
                        subjects = json.loads(row.get('subjects').replace("'", '"'))

                        print("-" * 50)
                        print(f"Sudent Roll no is: {row.get('roll_no')}")
                        print(f"Sudent name is: {row.get('name')}")
                        print(f"Sudent Gender is: {row.get('gender')}")
                        print(f"Sudent Age is: {row.get('age')}")
                        print(f"Sudent Department is: {row.get('department')}")
                        print(f"Sudent Semester is: {row.get('semester')}")
                        print("Subject details: ")
                        for key, value in subjects.items():
                            print(f"\tCode: {key} - Name: {value}")

            # with open(student_csv,'r') as file:
            #     reader = [row for row in csv.DictReader(file)]
            #     if len(reader) == 0:
            #         print("Student data not found.")
            #     else:
            #         print("----Display Student----")
            #         with open(student_csv, 'r') as f:
            #             reader = csv.DictReader(f)
            #             for row in reader:
            #                 print(row)


            # if not os.path.isfile('student.csv'):
            #     print("File not exists.")
            #     # Creates a new file, because file not exists.
            #     with open('student.csv', 'w') as fp:
            #         pass
            # if os.stat('student.csv').st_size == 0:
            #     print("Student data not found.")
            # else:
            #     with open('student.csv', 'r', encoding='UTF8') as f:
            #         reader = csv.reader(f)
            #         header = next(reader, None)
            #         #print(header)
            #         for row in reader:
            #             for item in row:
            #                 print(item)
            #             # print("\n")
                print("#" * 50)

            # if student == {}:
            #     print("Student data not found.")
            # else:
            #     print("----Display All Students-----")
            #     print("*" * 20)
            #     for i, j in student.items():
            #         print("\nStudent ID:", i)
            #
            #         for key in j:
            #             print(key + ':', j[key])

        elif select == 2:
            print("----Add Student-----")
            print("*" * 20)
            header = ['roll_no', 'name', 'gender', 'age', 'department', 'semester', 'subjects']
            with open(student_csv) as file:
                reader = [row for row in csv.DictReader(file)]
                if len(reader) == 0:
                    with open(student_csv, 'w', newline='') as file:
                        writer = csv.DictWriter(file, fieldnames=header)
                        writer.writeheader()

            r_no = int(input('Enter Roll Number: '))
            # while True:
            #     f = True
            #     try:
            #         r_no = int(input('Enter Roll Number: '))
            #     except ValueError:
            #         print("Enter roll no (Only numeric value): ")
            #         f = False
            #         pass
            #     # else:
            #         # for i in student:
            #         #     if student[i]['Roll_no'] == r_no and r_no != 0:
            #         #         print("Entered roll number is exists please enter another roll number")
            #         #         f = False
            #         #         break
            #         #     else:
            #         #         f = True
            #     if f:
            #         break

            for i in range(1,len(student)+1):
                if student[i]['Roll_no'] == r_no and r_no != 0:
                    print("Entered roll number is exists please enter another roll number")
                    r_no = int(input('Enter Roll Number: '))
                    break

            else:
            # name validation
                name = input('Enter Name : ')
                punc = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
                while True:
                    if name.isalpha() and len(name) <= 5 and len(name) >= 1:
                        break
                    elif name == punc and name == " ":
                        print("Name only contain characters")
                        name = input('Enter Name : ')
                    else:
                        print("Name only contain characters")
                        name = input('Enter Name : ')
                        # continue
                # gender validation
                gender = input('Enter Gender : ')
                while True:
                    if gender.isalpha() and gender == 'male' or gender == 'female':
                        break
                    elif gender == " ":
                        print("Enter gender")
                        gender = input('Enter Gender : ')
                    else:
                        print("Enter male or female only")
                        gender = input('Enter Gender : ')

                # age validation
                age = input('Enter Age : ')
                while True:
                    if age.isdigit() and len(age) > 0 and len(age) < 4:
                        break
                    elif age == " ":
                        print("Please Enter age")
                        age = input('Enter Age : ')
                    else:
                        print("Enter Numeric value only")
                        age = input('Enter Age : ')

                # department validation
                department = input('Enter Department : ')
                while True:
                    if department.isalpha():
                        break
                    elif department == " ":
                        print("Please enter department")
                        department = input('Enter Department : ')
                    else:
                        print("Enter character only")
                        department = input('Enter Department : ')

                # sem validation
                semester = input('Enter Semester : ')
                while True:
                    if semester.isdigit() and len(semester) > 0:
                        break
                    elif semester == " ":
                        print("Please enter semester")
                        semester = input('Enter Semester : ')
                    else:
                        print("Enter Numeric value only")
                        semester = input('Enter Semester : ')

                # a = {}
                subj = int(input("How Many Subject Add : "))

                for i in range(subj):
                    scode = input("Enter Subject code : ")
                    while True:
                        if scode.isdigit():
                            break
                        elif scode == " ":
                            print("Enter Numeric Subject code")
                            scode = input("Enter Subject code : ")
                        else:
                            print("Enter Numeric Subject code")
                            scode = input("Enter Subject code : ")
                    sub = input("Enter Subject : ")
                    while True:
                        if sub.isalpha():
                            break
                        elif sub == " ":
                            print("Enter Numeric Subject code")
                            sub = input("Enter Subject : ")
                        else:
                            print("Enter Numeric Subject code")
                            sub = input("Enter Subject : ")
                    subdict.update({scode: sub})

                if r_no == 0:
                    print("*" * 20)
                    print("Enter Valid Number which is greater than zero")

                elif r_no == " " or name == " " or gender == " " or age == " " or department == " " or semester == " ":
                    print("Please Enter Valid Input")

                else:
                    # roll = len(student) + 1
                    # student.update({roll: {"Roll_no": r_no, "Name": name, "Gender": gender, "Age": age,
                    #                        "Department": department, "Semester": semester, "Subjects": a}})
                    # print("Record inserted...")
                    student.update({'roll_no': r_no, 'name': name, 'gender': gender, 'age': age, 'department': department, 'semester': semester,
                         'subjects': subdict})

                    with open(student_csv, "a", encoding="UTF8", newline='') as f:
                        writer = csv.DictWriter(f, fieldnames=header)
                        writer.writerow(student)


                    # for i, j in student[roll].items():
                    #     print(i + ':', j)
            # r_no = int(input('Enter Roll Number: '))
            # for i in range(1 ,len(student)+1):
            #     if student[i]['Roll_no'] == r_no and r_no != 0:
            #         print("Entered roll number is exists please enter another roll number")
            #         break
            #
            # # while True:
            # #     for i in range(student):
            # #         if student[i]['Roll_no'] == r_no and r_no != 0:
            # #             print("Entered roll number is exists please enter another roll number")
            # #             r_no = input('Enter Roll Number: ')
            # #             # break
            # #         elif r_no.isalpha():
            # #             print("Enter numeric only")
            # #             r_no = input('Enter Roll Number: ')
            # #         else:
            # #             break
            # else:
            # #name validation
            #     name = input('Enter Name : ')
            #     punc = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
            #     while True:
            #         if name.isalpha() and len(name) <= 5 and len(name) >= 1:
            #             break
            #         elif name == punc:
            #             print("Name only contain characters")
            #             name = input('Enter Name : ')
            #         else:
            #             print("Name only contain characters")
            #             name = input('Enter Name : ')
            #             # continue
            #     # gender validation
            #     gender = input('Enter Gender : ')
            #     while True:
            #         if gender.isalpha() and gender == 'male' or gender == 'female':
            #             break
            #         else:
            #             print("Enter male or female only")
            #             gender = input('Enter Gender : ')
            #
            #     #age validation
            #     age = input('Enter Age : ')
            #     while True:
            #         if age.isdigit() and len(age) > 0 and len(age) < 4:
            #             break
            #         else:
            #             print("Enter Numeric value only")
            #             age = input('Enter Age : ')
            #
            #     #department validation
            #     department = input('Enter Department : ')
            #     while True:
            #         if department.isalpha():
            #             break
            #         else:
            #             print("Enter character only")
            #             department = input('Enter Department : ')
            #
            #     # sem validation
            #     semester = input('Enter Semester : ')
            #     while True:
            #         if semester.isdigit() and len(semester) > 0:
            #             break
            #         else:
            #             print("Enter Numeric value only")
            #             semester = input('Enter Semester : ')
            #
            #     a = {}
            #     subj = int(input("How Many Subject Add : "))
            #
            #     for i in range(subj):
            #         scode = input("Enter Subject code : ")
            #         while True:
            #             if scode.isdigit():
            #                 break
            #             else:
            #                 print("Enter Numeric Subject code")
            #                 scode = input("Enter Subject code : ")
            #         sub = input("Enter Subject : ")
            #         while True:
            #             if sub.isalpha():
            #                 break
            #             else:
            #                 print("Enter Numeric Subject code")
            #                 sub = input("Enter Subject : ")
            #         a.update({scode: sub})
            #
            #     if r_no == 0:
            #         print("*" * 20)
            #         print("Enter Valid Number which is greater than zero")
            #
            #     elif r_no == " " or name == " " or gender == " " or age == " " or department == " " or semester == " ":
            #         print("Please Enter Valid Input")
            #
            #     else:
            #         roll = len(student) + 1
            #         student.update({roll: {"Roll_no": r_no, "Name": name, "Gender": gender, "Age": age,
            #                                "Department": department, "Semester": semester, "Subjects": a}})
            #         print("Record inserted...")
            #         for i, j in student[roll].items():
            #             print(i + ':', j)

        elif select == 3:
            while (True):
                print("1.Search Roll No")
                print("2.Search Name")
                print("3.Search Department")
                print("0.Exit\n")
                print("*" * 20)

                try:
                    numb1 = int(input("Enter Your Choice : "))
                    if numb1 < 0:
                        raise ValueError
                    elif numb1 == 0:
                        break
                        # exit()

                    with open(student_csv) as file:
                        reader = [row for row in csv.DictReader(file)]
                        if len(reader) == 0:
                            print("Student Details Not Found")
                        else:
                            if numb1 == 1:
                                print("Search By Roll No")
                                rlno = int(input("Enter Roll No : "))
                                # while True:
                                if rlno == 0 or rlno == " ":
                                    print("Please enter valid roll no")
                                    rlno = int(input("Enter Roll No : "))
                                else:
                                    with open(student_csv, 'r') as f:
                                        reader = csv.DictReader(f)
                                        for row in reader:
                                            if int(row['roll_no']) == int(rlno):
                                                print(row)
                                                # break

                                # for m,j in student.items():
                                #     if student[m]["Roll_no"] == rlno:
                                #         print(student[m])
                                #     else:
                                #         print("Student not found")
                            elif numb1 == 2:
                                print("Search BY Name Student")
                                nam = input("Enter Name : ")
                                if nam == " " or not(nam.isalpha()):
                                    print("*" * 20)
                                    print("Please Enter Valid Input")
                                    # nam = input("Enter Name : ")
                                else:
                                    with open(student_csv, 'r') as f:
                                        reader = csv.DictReader(f)
                                        for row in reader:
                                            if nam == row['name']:
                                                print(row)
                                # for m,j in student.items():
                                #     if student[m]["Name"] == nam:
                                #         print(student[m])
                                #     else:
                                #         print("Student not found")
                            elif numb1 == 3:
                                print("Search By Department Student")
                                dep = input("Enter Department : ")
                                if dep == " " or not (dep.isalpha()):
                                    print("*" * 20)
                                    print("Please Enter Valid Input")
                                else:
                                    with open(student_csv, 'r') as f:
                                        reader = csv.DictReader(f)
                                        for row in reader:
                                            if dep == row['department']:
                                                print(row)
                                # for m,j in student.items():
                                #     if student[m]["Department"] == dep:
                                #         print(student[m])
                                #     else:
                                #         print("Student not found")

                            # if numb1 == 1:
                            #     print("Search By Roll No")
                            #     rlno = int(input("Enter Roll No : "))
                            #     for m,j in student.items():
                            #         if student[m]["Roll_no"] == rlno:
                            #             print(student[m])
                            #         else:
                            #             print("Student not found")
                            # elif numb1 == 2:
                            #     print("Search BY Name Student")
                            #     nam = input("Enter Name : ")
                            #     for m,j in student.items():
                            #         if student[m]["Name"] == nam:
                            #             print(student[m])
                            #         else:
                            #             print("Student not found")
                            # elif numb1 == 3:
                            #     print("Search By Department Student")
                            #     dep = input("Enter Department : ")
                            #     for m,j in student.items():
                            #         if student[m]["Department"] == dep:
                            #             print(student[m])
                            #         else:
                            #             print("Student not found")
                            #     # for i in student:
                            #     #     if student[i]["Department"] == dep:
                            #     #         print(m + ':', j)

                        if numb1 >= 4:
                            print("Please Enter Valid Choice Number")
                except ValueError as v:
                    print("Error : Please Enter Valid Number Input")
                except KeyboardInterrupt as k:
                    print(k)

        elif select == 4:
            print("Delete Student")
            print("*" * 20)
            with open(student_csv) as file:
                reader = [row for row in csv.DictReader(file)]
                if len(reader) == 0:
                    print("Student Details Not Found")
                else:
                    roll = int(input("Enter Roll Number for Delete : "))
                    li = []
                    with open(student_csv, 'r') as file:
                        l = [row for row in csv.DictReader(file)]

                    with open(student_csv, 'r') as file:
                        reader = csv.DictReader(file)
                        for row in reader:
                            if int(row['roll_no']) != roll:
                                li.append(row)

                        if len(l) == len(li):
                            print("\t\tRoll number not found please try again")
                        else:
                            with open(student_csv, 'w', newline='') as file:
                                header = ['roll_no', 'name', 'gender', 'age', 'department', 'semester', 'subjects']
                                writer = csv.DictWriter(file, fieldnames=header)
                                writer.writeheader()
                                writer.writerows(li)
                                print("Record deleted...")


            # if student == {}:
            #     print("*" * 20)
            #     print("---Student Details Not Found---- ")
            # else:
            #     d_no = int(input("Enter student roll number that you want to delete:"))
            #     del student[d_no]

        elif select == 5:

            while (True):
                print("Update Students")
                print("1.Update Roll No")
                print("2.Update Name")
                print("3.Update Gender")
                print("4.Update Age")
                print("5.Update Department")
                print("6.Update Semester")
                print("7.Update Subject")
                print("0.Exit")
                try:
                    numb3 = int(input("Enter Your Choice for update : "))
                    if numb3 < 0:
                        raise ValueError
                    elif numb3 == 0:
                        break

                    with open(student_csv) as file:
                        reader = [row for row in csv.DictReader(file)]
                        if len(reader) == 0:
                            print("\t\tStudent Details Not Found---")
                        else:
                            if numb3 == 1:
                                print("Update Student Roll No")
                                print("*" * 20)
                                oldroll = int(input("Enter roll no : "))
                                # if oldroll == 0 or oldroll == " " or oldroll.isalpha():
                                #     print("*" * 20)
                                #     print("Please Enter Valid Number")
                                #     oldroll = input("Enter roll no : ")
                                # else:

                                newroll = int(input("Enter roll no. for update: "))
                                if newroll == 0 or newroll == " ":
                                    print("*" * 20)
                                    print("Please Enter Valid Number ")
                                    newroll = int(input("Enter roll no. for update: "))

                                else:
                                    li = []
                                    with open(student_csv, 'r') as file:
                                        reader = csv.DictReader(file)
                                        for row in reader:
                                            if int(row['roll_no']) == int(oldroll):
                                                row['roll_no'] = int(newroll)
                                                oldroll = int(newroll)
                                                li.append(row)
                                            else:
                                                li.append(row)
                                    print(li)

                                    with open(student_csv, 'w', newline='') as file:
                                        header = ['roll_no', 'name', 'gender', 'age', 'department', 'semester', 'subjects']
                                        writer = csv.DictWriter(file, fieldnames=header)
                                        writer.writeheader()
                                        writer.writerows(li)
                                        print("\nStudent details updated...")

                    # else:
                    #     if student == {}:
                    #         print("Student Details Not Found")
                    #     else:
                    #         if numb3 == 1:
                    #             print("---Update Student Roll No---")
                    #             print("*" * 20)
                    #             l = input("Enter Student Id :")
                    #             while True:
                    #                 if l in student:
                    #                     break
                    #                 elif not l.isdigit():
                    #                     print("Please enter correct id")
                    #                     l = input("Enter Student Id :")
                    #                 elif not int(l) in student:
                    #                     print("Student id not found")
                    #                     l = input("Enter Student Id :")
                    #                 else:
                    #                     break
                    #             ra_no = int(input("Enter New Roll Number : "))
                    #             for m in student:
                    #                 student[l].update({"Roll_no": ra_no})
                    #                 print("\nRecord Updated...\n")
                    #
                    #                 for i, j in student[l].items():
                    #                     print(i + ':', j)

                            elif numb3 == 2:
                                print("Update Student Name")
                                print("*" * 20)
                                oldroll = input("Enter roll no : ")
                                if oldroll == 0 or oldroll == " " or oldroll.isalpha():
                                    print("*" * 20)
                                    print("Please Enter Valid Number")
                                    oldroll = input("Enter roll no : ")
                                # elif oldroll == "":
                                #     print("*" * 20)
                                #     print("Please Enter Valid Input")

                                newname = input("Enter New Name for update: ")
                                punc = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
                                if newname == " " or len(newname) < 2 or newname.isdigit() or newname == punc:
                                    print("*" * 20)
                                    print("Please Enter Valid Input")
                                # elif len(newname) < 2:
                                #     print("*" * 20)
                                #     print("Please Enter Name Minimum 3 Character")
                                else:
                                    li = []
                                    with open(student_csv, 'r') as file:
                                        reader = csv.DictReader(file)
                                        for row in reader:
                                            if int(row['roll_no']) == int(oldroll):
                                                row['name'] = newname
                                                li.append(row)
                                            else:
                                                li.append(row)
                                    print(li)

                                    with open(student_csv, 'w', newline='') as file:
                                        header = ['roll_no', 'name', 'gender', 'age', 'department', 'semester',
                                                  'subjects']
                                        writer = csv.DictWriter(file, fieldnames=header)
                                        writer.writeheader()
                                        writer.writerows(li)
                                        print("\nStudent details updated...")

                                # l = int(input("Enter Student Id :"))
                                # while True:
                                #     if l in student:
                                #         break
                                #     elif not l.isdigit():
                                #         print("Please enter correct id")
                                #         l = input("Enter Student Id :")
                                #     elif not int(l) in student:
                                #         print("Student id not found")
                                #         l = input("Enter Student Id :")
                                #     else:
                                #         break
                                # nam = input("Enter New Name : ")
                                # punc = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
                                # while True:
                                #     if nam.isalpha():
                                #         for m in student:
                                #             student[l].update({"Name": nam})
                                #             print("Record Updated...")
                                #             for i, j in student[l].items():
                                #                 print(i + ':', j)
                                #         break
                                #     elif nam == punc:
                                #         print("Name only contains character")
                                #         nam = input("Enter New Name : ")
                                #     else:
                                #         print("Name only contains character")
                                #         nam = input("Enter New Name : ")
                            elif numb3 == 3:
                                print("Update Student Gender")
                                print("*" * 20)
                                oldroll = input("Enter old roll no : ")
                                if oldroll == 0 or oldroll == " " or oldroll.isalpha():
                                    print("*" * 20)
                                    print("Please Enter Valid Number")
                                    oldroll = input("Enter old roll no : ")

                                newgender = input("Enter New Gender for update: ")
                                if newgender == " ":
                                    print("*" * 20)
                                    print("Please Enter Valid Input")
                                    newgender = input("Enter New Gender. to update: ")
                                # elif not newgender == "male":
                                #     print("Please Enter male or female only")
                                #     newgender = input("Enter New Gender. to update: ")
                                # elif not newgender == "female":
                                #     print("Please Enter male or female only")
                                #     newgender = input("Enter New Gender. to update: ")
                                else:
                                    li = []
                                    with open(student_csv, 'r') as file:
                                        reader = csv.DictReader(file)
                                        for row in reader:
                                            if int(row['roll_no']) == int(oldroll):
                                                row['gender'] = newgender
                                                li.append(row)
                                            else:
                                                li.append(row)
                                    print(li)

                                    with open(student_csv, 'w', newline='') as file:
                                        header = ['roll_no', 'name', 'gender', 'age', 'department', 'semester', 'subjects']
                                        writer = csv.DictWriter(file, fieldnames=header)
                                        writer.writeheader()
                                        writer.writerows(li)
                                        print("\nStudent details updated...")


                            # elif numb3 == 3:
                            #     print("Update Student Gender")
                            #     print("*" * 20)
                            #     l = int(input("Enter Student Id :"))
                            #     while True:
                            #         if l in student:
                            #             break
                            #         elif not l.isdigit():
                            #             print("Please enter correct id")
                            #             l = input("Enter Student Id :")
                            #         elif not int(l) in student:
                            #             print("Student id not found")
                            #             l = input("Enter Student Id :")
                            #         else:
                            #             break
                            #     print("*" * 20)
                            #     gen = input("Enter New Gender : ")
                            #     while True:
                            #         if gen.isalpha() and gender == 'male' or gender == 'female':
                            #             for m in student:
                            #                 student[l].update({"Gender": gen})
                            #                 print("Record Updated...")
                            #                 for i, j in student[l].items():
                            #                     print(i + ':', j)
                            #             break
                            #         else:
                            #             print("Enter male or female only")
                            #             gen = input("Enter Update Gender : ")

                            elif numb3 == 4:
                                print("Update Student Age")
                                print("*" * 20)
                                oldroll = input("Enter old roll no : ")
                                if oldroll == 0 or oldroll == " " or oldroll.isalpha():
                                    print("*" * 20)
                                    print("Please Enter Valid Number")
                                    oldroll = input("Enter old roll no : ")

                                newage = input("Enter New Age. to update: ")
                                if newage == " " or newage.isalpha():
                                    print("*" * 20)
                                    print("Please Enter Valid Input")
                                else:
                                    li = []
                                    with open(student_csv, 'r') as file:
                                        reader = csv.DictReader(file)
                                        for row in reader:
                                            if int(row['roll_no']) == int(oldroll):
                                                row['age'] = newage
                                                li.append(row)
                                            else:
                                                li.append(row)
                                    print(li)

                                    with open(student_csv, 'w', newline='') as file:
                                        header = ['roll_no', 'name', 'gender', 'age', 'department', 'semester',
                                                  'subjects']
                                        writer = csv.DictWriter(file, fieldnames=header)
                                        writer.writeheader()
                                        writer.writerows(li)
                                        print("\nStudent details updated...")
                            # l = int(input("Enter Student Id :"))
                            #     while True:
                            #         if l in student:
                            #             break
                            #         elif not l.isdigit():
                            #             print("Please enter correct id")
                            #             l = input("Enter Student Id :")
                            #         elif not int(l) in student:
                            #             print("Student id not found")
                            #             l = input("Enter Student Id :")
                            #         else:
                            #             break
                            #     print("*" * 20)
                            #     ag = input("Enter New Age : ")
                            #     while True:
                            #         if ag.isdigit() and len(age) > 0 and len(age) < 4:
                            #             for m in student:
                            #                 student[l].update({"Age": ag})
                            #                 print("Record Updated...")
                            #                 for i, j in student[l].items():
                            #                     print(i + ':', j)
                            #             break
                            #         else:
                            #             print("Enter Numeric value only")
                            #             ag = input("Enter New Age : ")

                            elif numb3 == 5:
                                print("Update Student Department")
                                print("*" * 20)
                                oldroll = input("Enter old roll no : ")
                                if oldroll == 0 or oldroll == " " or oldroll.isalpha():
                                    print("*" * 20)
                                    print("Please Enter Valid Number")

                                newdepartment = input("Enter New Department. to update: ")
                                if newdepartment == " " or newdepartment.isdigit():
                                    print("*" * 20)
                                    print("Please Enter Valid Input")
                                    newdepartment = input("Enter New Department. to update: ")
                                else:
                                    li = []
                                    with open(student_csv, 'r') as file:
                                        reader = csv.DictReader(file)
                                        for row in reader:
                                            if int(row['roll_no']) == int(oldroll):
                                                row['department'] = newdepartment
                                                li.append(row)
                                            else:
                                                li.append(row)
                                    print(li)

                                    with open(student_csv, 'w', newline='') as file:
                                        header = ['roll_no', 'name', 'gender', 'age', 'department', 'semester',
                                                  'subjects']
                                        writer = csv.DictWriter(file, fieldnames=header)
                                        writer.writeheader()
                                        writer.writerows(li)
                                        print("\nStudent details updated...")


                                        # l = int(input("Enter Student Id :"))
                                # while True:
                                #     if l in student:
                                #         break
                                #     elif not l.isdigit():
                                #         print("Please enter correct id")
                                #         l = input("Enter Student Id :")
                                #     elif not int(l) in student:
                                #         print("Student id not found")
                                #         l = input("Enter Student Id :")
                                #     else:
                                #         break
                                # print("*" * 20)
                                # dep = input("Enter New Department : ")
                                # while True:
                                #     if dep.isalpha():
                                #         for m in student:
                                #             student[l].update({"Department": dep})
                                #             print("Record Updated...")
                                #             for i, j in student[l].items():
                                #                 print(i + ':', j)
                                #         break
                                #     else:
                                #         print("Enter character only")
                                #         dep = input("Enter New Department : ")

                            elif numb3 == 6:
                                print("Update Student Semester")
                                print("*" * 20)
                                oldroll = int(input("Enter old roll no : "))
                                if oldroll == 0 or oldroll == " ":
                                    print("*" * 20)
                                    print("Please Enter Valid Number")
                                    oldroll = int(input("Enter old roll no : "))

                                newsem = input("Enter New Semester for update: ")
                                if newsem == " ":
                                    print("*" * 20)
                                    print("Please Enter Valid Input")
                                    newsem = int(input("Enter New Semester for update: "))
                                else:
                                    li = []
                                    with open(student_csv, 'r') as file:
                                        reader = csv.DictReader(file)
                                        for row in reader:
                                            if int(row['roll_no']) == int(oldroll):
                                                row['semester'] = newsem
                                                li.append(row)
                                            else:
                                                li.append(row)
                                    print(li)

                                    with open(student_csv, 'w', newline='') as file:
                                        header = ['roll_no', 'name', 'gender', 'age', 'department', 'semester',
                                                  'subjects']
                                        writer = csv.DictWriter(file, fieldnames=header)
                                        writer.writeheader()
                                        writer.writerows(li)
                                        print("\nStudent details updated...")


                                        # l = int(input("Enter Student Id :"))
                                # while True:
                                #     if l in student:
                                #         break
                                #     elif not l.isdigit():
                                #         print("Please enter correct id")
                                #         l = input("Enter Student Id :")
                                #     elif not int(l) in student:
                                #         print("Student id not found")
                                #         l = input("Enter Student Id :")
                                #     else:
                                #         break
                                # print("*" * 20)
                                # sem = input("Enter New Semester : ")
                                # while True:
                                #     if sem.isdigit() and len(sem) > 0:
                                #         for m in student:
                                #             student[l].update({"Semester": sem})
                                #             print("\nRecord Updated...\n")
                                #             for i, j in student[l].items():
                                #                 print(i + ':', j)
                                #         break
                                #     else:
                                #         print("Enter Numeric value only")
                                #         sem = input("Enter New Semester : ")

                            elif numb3 == 7:
                                print("Update Student Subject ")
                                print("*" * 20)
                                oldroll = int(input("Enter old roll no : "))
                                if oldroll == 0 or oldroll == " ":
                                    print("*" * 20)
                                    print("Please Enter Valid Number")
                                    oldroll = int(input("Enter old roll no : "))

                                else:
                                    with open(student_csv, 'r') as file:
                                        reader = csv.DictReader(file)


                                # subdict = {}
                                # l = int(input("Enter Student Id :"))
                                # while True:
                                #     if l in student:
                                #         break
                                #     elif not l.isdigit():
                                #         print("Please enter correct id")
                                #         l = input("Enter Student Id :")
                                #     elif not int(l) in student:
                                #         print("Student id not found")
                                #         l = input("Enter Student Id :")
                                #     else:
                                #         break
                                # subj = int(input("How Many Subjects Update : "))
                                #
                                # for i in range(subj):
                                #     scode = int(input("Enter Subject code : "))
                                #     # while True:
                                #     #     if scode.isdigit():
                                #     #         break
                                #     #     else:
                                #     #         print("Enter Numeric Subject code")
                                #     #         scode = input("Enter Subject code : ")
                                #
                                #     sub = input("Enter Subject Name : ")
                                #     # while True:
                                #     #     if sub.isalpha():
                                #     #         break
                                #     #     else:
                                #     #         print("Enter Numeric Subject code")
                                #     #         sub = input("Enter Subject : ")
                                #
                                #     subdict.update({scode: sub})
                                #
                                # student[l].update({"subjects":subdict})
                                # print("Record Updated...")
                                # for i, j in student[l].items():
                                #     print(i + ':', j)

                        if numb3 > 7:
                            print("Please Enter Valid Choice Number")

                except ValueError as v:
                    print("Please Enter Valid Number Input")
                    # numb3 = int(input("Enter Your Choice : "))
                except KeyboardInterrupt as k:
                    print(k)


        elif select == 6:
            while (True):
                print("----Sorting Students----")
                print("1.Sorting Roll No")
                print("2.Sorting Name")
                print("3.Sorting Department")
                print("4.Sorting Semester")
                print("5.Sorting Age")
                print("0.Exit")
                print("*" * 20)

                try:
                    numb2 = int(input("Enter Your Choice : "))
                    print("*" * 20)
                    if numb2 < 0:
                        raise ValueError
                    elif numb2 == 0:
                        break

                    with open(student_csv) as file:
                        reader = [row for row in csv.DictReader(file)]
                        if len(reader) == 0:
                            print("Student Details Not Found")
                        else:
                            if numb2 == 1:
                                print("----Sorting Student Roll No Wise----- ")
                                print("*" * 20)
                                with open(student_csv) as file:
                                    data = csv.DictReader(file)
                                    data = sorted(data, key=lambda x: x['roll_no'])
                                    for row in data:
                                        print(row)

                            elif numb2 == 2:
                                print("---Sorting Name Wise Student---")
                                with open(student_csv) as file:
                                    data = csv.DictReader(file)
                                    data = sorted(data, key=lambda x: x['name'])
                                    for row in data:
                                        print(row)
                                # name = dict(sorted(student.items(), key=lambda x: x[1]['Name']))
                                # for i, j in name.items():
                                #     print("Person ID:", i)
                                #
                                #     for key in j:
                                #         print(key + ':', j[key])

                            elif numb2 == 3:
                                print("---Sorting Department Wise Student---")
                                with open(student_csv) as file:
                                    data = csv.DictReader(file)
                                    data = sorted(data, key=lambda x: x['department'])
                                    for row in data:
                                        print(row)

                                # department = dict(sorted(student.items(), key=lambda x: x[1]['Department']))
                                # for i, j in department.items():
                                #     print("Person ID:", i)
                                #     for key in j:
                                #         print(key + ':', j[key])

                            elif numb2 == 4:
                                print("---Sorting Semester Wise Student---")
                                with open(student_csv) as file:
                                    data = csv.DictReader(file)
                                    data = sorted(data, key=lambda x: x['semester'])
                                    for row in data:
                                        print(row)

                                # semester = dict(sorted(student.items(), key=lambda x: x[1]['Semester']))
                                # for i, j in semester.items():
                                #     print("\nPerson ID:", i)
                                #     for key in j:
                                #         print(key + ':', j[key])

                            elif numb2 == 5:
                                print("---Search Age Wise Student---")

                                with open(student_csv) as file:
                                    data = csv.DictReader(file)
                                    data = sorted(data, key=lambda x: x['age'])
                                    for row in data:
                                        print(row)

                                # Age = dict(sorted(student.items(), key=lambda x: x[1]['Age']))
                                # for i, j in Age.items():
                                #     print("Person ID:", i)
                                #     for key in j:
                                #         print(key + ':', j[key])

                    if numb2 >= 6:
                        print("*" * 20)
                        print("---Please Enter Valid Choice Number---")

                    # numb2 = int(input("Enter Your Choice : "))
                    # print("*" * 20)
                    # if numb2 < 0:
                    #     raise ValueError
                    # elif numb2 == 0:
                    #     break
                    # else:
                    #     if student == {}:
                    #         print("---Student Details Not Found---")
                    #     else:
                    #         if numb2 == 1:
                    #             print("---Sorting Roll No Wise Student---")
                    #             Roll_no = dict(sorted(student.items(), key=lambda x: x[1]['Roll_no']))
                    #             for i, j in Roll_no.items():
                    #                 print("Person ID:", i)
                    #                 for key in j:
                    #                     print(key + ':', j[key])
                    #
                    #         elif numb2 == 2:
                    #             print("---Sorting Name Wise Student---")
                    #             name = dict(sorted(student.items(), key=lambda x: x[1]['Name']))
                    #             for i, j in name.items():
                    #                 print("Person ID:", i)
                    #
                    #                 for key in j:
                    #                     print(key + ':', j[key])
                    #
                    #         elif numb2 == 3:
                    #             print("---Sorting Department Wise Student---")
                    #
                    #             department = dict(sorted(student.items(), key=lambda x: x[1]['Department']))
                    #             for i, j in department.items():
                    #                 print("Person ID:", i)
                    #                 for key in j:
                    #                     print(key + ':', j[key])
                    #
                    #         elif numb2 == 4:
                    #             print("---Sorting Semester Wise Student---")
                    #
                    #             semester = dict(sorted(student.items(), key=lambda x: x[1]['Semester']))
                    #             for i, j in semester.items():
                    #                 print("\nPerson ID:", i)
                    #                 for key in j:
                    #                     print(key + ':', j[key])
                    #
                    #         elif numb2 == 5:
                    #             print("---Search Age Wise Student---")
                    #
                    #             Age = dict(sorted(student.items(), key=lambda x: x[1]['Age']))
                    #             for i, j in Age.items():
                    #                 print("Person ID:", i)
                    #                 for key in j:
                    #                     print(key + ':', j[key])
                    #
                    # if numb2 >= 6:
                    #     print("*" * 20)
                    #     print("---Please Enter Valid Choice Number---")

                except ValueError as v:
                    print("Error : Please Enter Valid Number Input")
                except KeyboardInterrupt as k:
                    print(k)

        else:
            print("Enter valid input")
            continue

    except ValueError:
        print("Please enter only numeric")
        print("#"*50)
    except AttributeError:
        print("attribute assignment or reference fails")
    except ImportError:
        print("Import module properly")
    except IndexError:
        print("list index out of range")
    except KeyError:
        print("Key not found")
    except NameError:
        print("variable is not found in local or global scope")
    except SyntaxError:
        print("Invalid syntax")
    except IndentationError:
        print("Give proper indentation")
    except TypeError:
        print("function or operation is applied to an object of incorrect type")
    except EOFError:
        print("End of line")
    except FileNotFoundError:
        print("File not created..")
        print()








