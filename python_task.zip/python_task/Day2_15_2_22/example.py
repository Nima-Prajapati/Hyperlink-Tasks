Python Task (15 Feb, 2022):

Task 1:

- 1.if...else
- 2.for Loop
- 3.while Loop
- 4.break and continue
- 5.Pass
- 6.Function
- 7.Function Argument
- 8.Recursion
- 9.Anonymous Function
- 10.Global, Local and Nonlocal
- 11.Global Keyword


1.if
x = 5
if x > 3:
  print("YES")
op:YES

# if--else
num = int(input("Enter a number: "))
# i=5
if (num > 0):
	print("greater")
elif num < 0:
	print("less")
else:
	print("equal")


# nested if else
num = int(input("Enter a number: "))
# i=5
if (num > 0):
	if (num % 2) == 0:
   		print("{0} is Even".format(num))
	else:
   		print("{0} is Odd".format(num))
elif num < 0:
	print("less")
else:
	print("equal")




2.for Loop
for t in range(1, 4):
  # print one of t ==1
    if t == 1:
        print('One')
   # print two if t ==2
    elif t == 2:
        print('Two')
    else:
        print('else block execute')
op:One
Two
else block execute


# num = int(input(" Please Enter any Maximum Number : "))
# for number in range(1, num + 1):
#     if(number % 2 != 0):
#         print("{0}".format(number))
# op:Please Enter any Maximum Number : 10
# 1
# 3
# 5
# 7
# 9



3.while Loop

a = [1, 2, 3, 4]
while a:
    print(a.pop())
op:4
3
2
1


counter = 0
while counter < 3:
    print("Inside loop")
    counter = counter + 1
else:
    print("else")
op:Inside loop
Inside loop
Inside loop
Inside else



4.break and continue
# execute for loop
for i in range(1, 11):
     
    print(i)
     
    # if i lessthen 5 then continue loop
    if i < 5: 
        continue
         
    # if i greater then 5 then break loop
    else: 
        break
op:1
2
3
4
5


5.Pass
li =['a', 'b', 'c', 'd']
for i in li:
    if(i =='a'):
        pass
    else:
        print(i)
op:b
c
d


6.Function
def my_function():
  print("Hello from a function")

my_function()
op:Hello from a function                  


7.Function Argument
def my_function(fname):
  print(fname + " Refsnes")

my_function("Emil")
op:Emil Refsnes

def my_function(fname, lname):
  print(fname + " " + lname)

my_function("Emil", "Refsnes")
op:Emil Refsnes



8.Recursion :Recursion is the process of defining something in terms of itself.
"""This is a recursive function
    to find the factorial of an integer"""
def factorial(x):
	if x == 1:
    		return 1
    else:
        return (x * factorial(x-1))
num = 3
print("The factorial of", num, "is", factorial(num))

op:The factorial of 3 is 6


9.Anonymous Function : In Python, an anonymous function is a function that is defined without a name.
 						While normal functions are defined using the def keyword in Python, anonymous functions are defined using the lambda keyword.
						Hence, anonymous functions are also called lambda functions. return only one variable.
# define a anonymous using lambda keyword
# this lambda function increment the value of b
a = lambda b: b+1
 
# run a for loop
for i in range(1, 6):
    print(a(i))
op:2
3
4
5
6

li = [2,4,6,5,7,8]
a = list(filter(lambda x : (x%2 == 0),li))
print("Filter : ",a)

squares = list(map(lambda n: n ** 2, range(1,10,2)))
print("square = ",squares)
square2 = list(filter(lambda n: n ** 2, range(1,10,2)))
print("square2 = ",square2)


10.Global, Local and Nonlocal

x = "global "
def g():
    global x
    y = "local"
    x = x * 2
    print(x)
    print(y)

g()
op:global global 
local

def myfunc1():
  x = "John"
  def myfunc2():
    nonlocal x
    x = "hello"
  myfunc2() 
  return x

print(myfunc1())
op:hello


11.Global Keyword
# declare a variable
gvar = 10

def fun1():
    print(gvar)
 
def fun2():
  # declare global value gvar
    global gvar
    gvar = 100
 
fun1()
 
fun2()
op:10




12.yield keyword
def Generator():
    for i in range(6):
        yield i+1
 
t = Generator()
for i in t:
    print(i)
op:1
2
3
4
5
6

13.assert keyword
def sumOfMoney(money):
    assert len(money) != 0,"List is empty."
    return sum(money)
 
money = []
print("sum of money:",sumOfMoney(money))



# reduce
from functools import reduce
li = [2,4,6,5,7,8]
sum = reduce(lambda x,y:x+y,li)
print("sum = ",sum)


# arbitary
Sometimes, we do not know in advance the number of arguments that will be passed into a function. 
Python allows us to handle this kind of situation through function calls with an arbitrary number of arguments.
In the function definition, we use an asterisk (*) before the parameter name to denote this kind of argument. Here is an example.
Eg.
def greet(*names):
    """This function greets all
    the person in the names tuple."""
    # names is a tuple with arguments
    for name in names:
   			print("Hello", name)


greet("Monica", "Jasmin", "Steve", "John")
op:Hello Monica
Hello Jasmin
Hello Steve
Hello John


# docstring
Python documentation strings (or docstrings) provide a convenient way of associating documentation with Python modules, functions, classes,
and methods.
What should a docstring look like?

1.The doc string line should begin with a capital letter and end with a period.
2.The first line should be a short description.
3.If there are more lines in the documentation string, the second line should be blank, visually separating the summary from the rest of the description.
4.The following lines should be one or more paragraphs describing the object’s calling conventions, its side effects, etc.

Declaring Docstrings:
	 The docstrings are declared using ”’triple single quotes”’ or “””triple double quotes””” just below the class, method or
	  function declaration. All functions should have a docstring.

Accessing Docstrings:
		 The docstrings can be accessed using the __doc__ method of the object or using the help function.

Eg.
def my_function():
    """Demonstrates triple double quotes
    docstrings and does nothing really."""
   
    return None
  
print("Using __doc__:")
print(my_function.__doc__)
op:Demonstrates triple double quotes
    docstrings and does nothing really.
