"""
Student Managmeent using if--else - DK
"""




import csv,operator
id = 0
sub_c=6
sub_n=7
up_sub_c=6
up_sub_n=7
count=0
#student=[{}]
student=[]

def savefile(student):
    s_file = open("sample.csv", "w")
    writer = csv.writer(s_file)
    # writer.writerow(header)
    writer.writerows(student)
    print("Single data write successfully...")
    s_file.close()


def cases(num):

    if num==0:
        exit()
    match num:
        case 1:
            f = open('sample.csv', 'r')
            reader = csv.reader(f)
            global id
            id = id + 1
            print(id)
            # id = int(input("enter the id:"))
            name = input("enter the student name:")
            rollno = input("enter the student rollno:")

            for row in reader:
                if len(row)!=0:
                    if row[1]==rollno:
                        print('#'*50)
                        print("this roll no ",rollno,"is already used please enter unique")
                        print('#' * 50)
                        choicefuc()
                        break

            gender = input("enter the student gender:")
            age = input("enter the student age:")
            department = input("enter the studnet depart:")
            sem = input("enter the student semester:")
            sub_count = int(input("enter the subject you want to add:"))
            data = [
                id, rollno, name, gender, age, department,
                sem]
            for i in range(sub_count):
                sub_code = input("subject code")
                sub_name = input("subject name:")
                d = [sub_code,sub_name]
                data.extend(d)
                print(data[6])

            student.append(data)
            header = ['id', 'Roll no', 'Name', 'Gender', 'Age', 'department', 'semester', 'subjects code',
                      'subject name']
            s_file = open("sample.csv", "w")
            writer = csv.writer(s_file)
            #writer.writerow(header)
            writer.writerows(student)
            print("Single data write successfully...")

            s_file.close()
            choicefuc()


        case 2:

                f = open('sample.csv', 'r')
                reader = csv.reader(f)
                #headers = next(reader, None)
                #print(headers)
                data1 = [row for row in reader]
                print("*#" * 100)
                print(data1)
                print("*#" * 100)

                choicefuc()

        case 3:

            print("1.serach by name")
            print("2.serach by rollno")
            print("3.sercah by department")
            print("0.exit")
            serach=int(input("enter yor choice for search :"))
            if serach>3:
                print("pelease enter the 1 to 3 number")
                choicefuc()
            else:

                match serach:
                    case 0:
                        choicefuc()
                    case 1:
                        names=input("enter the name")
                        f = open('sample.csv', 'r')
                        reader = csv.reader(f)

                        for row in reader:
                            rang=len(row)
                            c=rang-1
                            #print('forloop')
                            if row[2]==names:
                                cou=-1
                                for i in range(int(c)):
                                    cou=cou+1
                                    print(row[cou],end='   ')
                                choicefuc()
                    case 2:
                        rollno = input("enter the rollno")
                        f = open('sample.csv', 'r')
                        reader = csv.reader(f)

                        for row in reader:
                            rang = len(row)
                            c = rang - 1
                            # print('forloop')
                            if row[1] == rollno:
                                cou = -1
                                for i in range(int(rang)):
                                    cou = cou + 1
                                    print(row[cou], end='   ')
                                choicefuc()
                    case 3:
                        depart = input("enter the department")
                        f = open('sample.csv', 'r')
                        reader = csv.reader(f)

                        # for row in reader:
                        #     for row[5] in row:
                        #         if row[5]==depart:
                        #             print("roll :",row[1])
                        for row in reader:
                            rang = len(row)
                            c = rang - 1
                            # print('forloop')
                            if row[5] == depart:
                                cou = -1
                                data1=[]
                                for i in range(int(rang)):
                                    cou = cou + 1
                                    data1.append(row[cou])

                                print(data1)
                                choicefuc()


        case 4:
            if len(student)==0:
                print("no data found")
                choicefuc()
            else:
                f = open('sample.csv', 'r')
                reader = csv.reader(f)
                print("--- Delete Student ---")
                roll = input("Enter roll no. to delete: ")
                for row in reader:
                    if roll in row[1]:

                        student_found = False
                        updated_data = []
                        with open('sample.csv', "r", encoding="utf-8") as f:
                            reader = csv.reader(f)
                            counter = 0
                            for row in reader:
                                if len(row) > 0:
                                    if roll != row[0]:
                                        updated_data.append(row)
                                        counter += 1
                                    else:
                                        student_found = True

                            if student_found is True:
                                with open('sample.csv', "w", encoding="utf-8") as f:
                                    writer = csv.writer(f)
                                    writer.writerows(updated_data)
                                print("Roll no. ", roll, "deleted successfully")
                            else:
                                print("student not found")

                        choicefuc()
                    else:
                        print("roll no not found")
                        choicefuc()

        case 5:
            roll_id=input("enter the roll no:")
            print(roll_id)
            f = open('sample.csv', 'r')
            reader = csv.reader(f)

            for roll in student:

                print("1.update name")
                print("2.update age")
                print("3.update gender")
                print("4.update department")
                print("5.update semester")
                print("6.update subject info")


                ch=int(input("enter the "))

                match ch:
                        case 1:
                            print(student)
                            up_name=input('enter the updated name')
                            for i in student:
                                if i[1]==roll_id:
                                    i[2]=up_name
                                    print("updated")
                                    savefile(student)

                            choicefuc()
                        case 2:
                            up_gender=input('enter the updated gender')
                            for i in student:
                                if i[1] == roll_id:
                                    i[3] = up_gender
                                    print("updated")
                                    savefile(student)

                        case 3:
                            try:
                                up_age = int(input('enter the updated age'))
                                for i in student:
                                    if i[1] == roll_id:
                                        i[4] = up_age
                                        print("updated")
                                        savefile(student)
                                        choicefuc()
                            except:
                                print("#"*40)
                                print("please enter the numeric value")
                                print("#"*40)
                                choicefuc()
                        case 4:
                            up_depart = input('enter the updated department')
                            for i in student:
                                if i[1] == roll_id:
                                        i[5] = up_depart
                                        print("updated")
                                        savefile(student)
                                        choicefuc()
                        case 5:
                            up_sem = input('enter the updated sem')
                            for i in student:
                                if i[1] == roll_id:
                                    i[6] = up_sem
                                    print("updated")
                                    savefile(student)
                                    choicefuc()
                        case 6:
                            # print(student[id][7])
                            roll_id=input("enter you want update which id subject")
                            f = open('sample.csv', 'r')
                            reader = csv.reader(f)
                            for row in student:
                                if row[1]==roll_id:
                                    lenghth=len(row)

                                    print("value count", lenghth)
                                    up = lenghth - 6
                                    print("seprate sub", up)
                                    for i in range(lenghth):
                                        if i>5:
                                            reng1=up/2
                                            print("rang subject pair",reng1)
                                            global sub_c,sub_n,count
                                            for j in range(int(reng1)):
                                                sub_c=sub_c+1#7
                                                sub_n=sub_n+1#8
                                                count=count+1

                                                try:
                                                    print(count,'subject code:',row[sub_c],'subject name:',row[sub_n])
                                                    sub_c = sub_c + 1
                                                    sub_n = sub_n + 1
                                                except:
                                                    pass

                                    chose=int(input("enter which subject you want to update"))
                                    global up_sub_c,up_sub_n

                                    up_code = input("enter updated code")
                                    up_name = input("enter updated name")
                                    print(roll_id)
                                    if chose==1:
                                        up_sub_c = up_sub_c + 1#7
                                        up_sub_n = up_sub_n + 1#8
                                        row[up_sub_c]=up_code
                                        row[up_sub_n]=up_name
                                        print(up_sub_c,up_sub_n)
                                        print(student)
                                        savefile(student)
                                        choicefuc()
                                    if chose==2:
                                        up_sub_c = up_sub_c + 3#9
                                        up_sub_n = up_sub_n + 3#10
                                        row[up_sub_c] = up_code
                                        row[up_sub_n] = up_name
                                        print(up_sub_c, up_sub_n)
                                        print(student)
                                        savefile(student)
                                        choicefuc()
                                    if chose == 3:
                                        up_sub_c = up_sub_c + 5#11
                                        up_sub_n = up_sub_n + 5#12
                                        row[up_sub_c] = up_code
                                        row[up_sub_n] = up_name
                                        print(up_sub_c, up_sub_n)
                                        print(student)
                                        savefile(student)
                                        choicefuc()
                                    if chose == 4:
                                        up_sub_c = up_sub_c + 4
                                        up_sub_n = up_sub_n + 4
                                        row[up_sub_c] = up_code
                                        row[up_sub_n] = up_name
                                        print(student)
                                        savefile(student)
                                        choicefuc()
                                else:
                                    print("roll number not found")




        case 6:
                    print("1.sort by roll no")
                    print("2.sort by name")
                    print("3.sort by department")
                    print("0.exit")
                    n=int(input("enter sort choice"))
                    match n:
                        case 0:
                            choicefuc()
                        case 1:
                            data = csv.reader(open('sample.csv'), delimiter=',')

                            # sort data on the basis of age
                            dat = sorted(data, key=operator.itemgetter(1))
                            print('After sorting:')
                            print(dat)
                            choicefuc()
                        case 2:
                            data = csv.reader(open('sample.csv'), delimiter=',')

                            # sort data on the basis of age
                            data1 = sorted(data, key=operator.itemgetter(2))

                            # displaying sorted data
                            print('After sorting:')
                            print(data1)
                        case 3:
                            data = csv.reader(open('sample.csv'), delimiter=',')

                            # sort data on the basis of age
                            data2 = sorted(data, key=operator.itemgetter(2))

                            # displaying sorted data
                            print('After sorting:')
                            print(data2)
        case 0:
            exit()



def choicefuc():

    print("menu choice for calculation")
    print("1,Display all student list")
    print("2,Add student detail")
    print("3,Search student by rollno")
    print("4.Delete student detail")
    print("5.Update student detail")
    print("6.Sorting (Rollno, Name, department, semester, Age)")
    print("0.exit")
    try:
        choice = int(input("enter the your choice"))
        if choice<=6:
            cases(choice)


        else:
                print("#"*40)
                print("please enter the correct no")
                print("#" * 40)
                choicefuc()

    except ValueError:
        print("#"*40)
        print("enter the num of list")
        print("#"*40)
        choicefuc()


choicefuc()













# def cases(num):
#     try:
#         # creating options
#         while True:
#             choice1 = int(input("Enter the Choice:"))
#
#             if choice1 == 1:
#                 print("\nDisplay all student list")
#                 print("#" * 50)
#                 if len(student)==0:
#                     print("#" * 40)
#                     print("no data found")
#                     print("#" * 40)
#                     choicefuc()
#                 else:
#                     print(student)
#                     print("#" * 50)
#                     choicefuc()
#
#             elif choice1 == 2:
#                 print("\nAdd student detail")
#                 rollno = int(input("Enter Roll number : "))
#                 # for key in student.keys():
#                 #     if key == rollno:
#                 #         print("Please enter different")
#                 name = input("Enter name : ")
#                 gender = input("Enter gender : ")
#                 age = int(input("Enter age : "))
#                 department = input("Enter department : ")
#                 semester = int(input("Enter semester : "))
#                 subjectcode = input("Enter subject code :")
#                 sub_name = input("Enter subject name :")
#                 details = {rollno:[name,gender,age,department,semester],'subject':{'subjectcode':subjectcode,'subjectname':sub_name}}
#                 for key in student.keys():
#                     if key == rollno:
#                         print("Please enter another roll no, it already exists")
#                     else:
#                         student.update(details)
#
#             elif choice1 == 3:
#                 search_roll = input("Enter roll number for search :")
#                 if search_roll in student:
#                     print("#" * 50)
#                     print(student[search_roll])
#                     print("#" *50)
#                 else:
#                     print("Roll number not found")
#
#             elif choice1 == 4:
#                 del_roll = input("Enter roll no for delete student :")
#
#
#
#
#
#
# def choiceFunction():
#     print("#" * 50)
#     print("Welcome to Student Management System")
#     print("#" * 50)
#     print("1.Display all student list")
#     print("2.Add student detail")
#     print("3.Search student by rollno")
#     print("4.Delete student detail")
#     print("5.Update student detail")
#     print("6.Sorting (Rollno, Name, department, semester, Age)")
#     print("0.Exit")
#     print("#" * 50)
#     try:
#         choice = int(input("Enter your choice:"))
#         cases(choice)
#     except ValueError:
#         print("#" * 40)
#         print("Enter the number only for choice")
#         print("#" * 40)
#         choiceFunction()
#
#









# import csv
# id = 0
# sub_c=5
# sub_n=6
# up_sub_c=5
# up_sub_n=6
# count=0
# student={}
# def cases(num):
#
#     if num==0:
#         exit()
#     match num:
#         case 1:
#             print("#" * 50)
#             if len(student)==0:
#                 print("#" * 40)
#                 print("no data found")
#                 print("#" * 40)
#                 choicefuc()
#             else:
#                 print(student)
#                 print("#" * 50)
#             choicefuc()
#         case 2:
#             global id
#             id = id + 1
#             print(id)
#             # id = int(input("enter the id:"))
#             name=input("enter the student name:")
#             rollno=input("enter the student rollno:")
#             for key,val in student.items():
#                 if len(val)!=0:
#                     if val[0]==rollno:
#                         print("#"*40)
#                         print("please enter uniqe roll number this no already asign")
#                         print("#" * 40)
#                         choicefuc()
#             gender=input("enter the student gender:")
#             age=input("enter the student age:")
#             department=input("enter the studnet depart:")
#             sem=input("enter the student semester:")
#             sub_count = int(input("enter the subject you want to add:"))
#             data = [rollno, name, gender, age, department, sem]
#             #details = {id: [rollno, name, gender, age, department, sem]}
#             for i in range(sub_count):
#                 sub_code = input("subject code")
#                 sub_name = input("subject name:")
#                 d = [sub_code,sub_name]
#                 data.extend(d)
#                 print(data[6])
#                 # print("index:",ans)
#             student.update({id:data})
#             s_file = open("sample.csv", "w")
#             writer = csv.writer(s_file)
#             for key, value in student.items():
#                 writer.writerow([key, value])
#
#             s_file.close()
#             choicefuc()
#
#         case 3:
#
#             print("1.serach by name")
#             print("2.serach by rollno")
#             print("3.sercah by department")
#             serach=int(input("enter yor choice for search :"))
#             # import pdb;
#             # pdb.set_trace()
#             match serach:
#                 case 1:
#                     sub_val=''
#                     name = input("enter the name for find")
#                     #search_name=name.split(
#
#                     if len(name)==1:
#
#                         for key, val in student.items():
#                                 value=str(val[1])
#                                 s=value[0]
#                                 s.split()
#                                 if s == name:
#                                     print("#" * 40)
#                                     print(student[key])
#                                     print("#" * 40)
#                                     choicefuc()
#                                 else:
#                                     print("student not found")
#                     elif len(name)>1:
#
#                             for key, val in student.items():
#                                 try:
#                                     if val == name:
#                                         print("#" * 40)
#                                         print(student[key])
#                                         print("#" * 40)
#                                         choicefuc()
#                                         choicefuc()
#                                     else:
#                                         print("data not found")
#                                 except IndexError:
#
#                                     print("enter the proper name")
#                                     choicefuc()
#                     #elif len(name)>2:
#
#
#                 case 2:
#
#                     find_stu = input("enter the rollno:")
#                     if find_stu in student:
#                         print("#" * 50)
#                         print(student[find_stu])
#                         print("#" * 50)
#                         choicefuc()
#                     else:
#                         print("roll no not found")
#                         choicefuc()
#                 case 3:
#                     depart = input("enter the department for find")
#                     for key, val in student.items():
#                         if val[4] == depart:
#                             print("#" * 40)
#                             print(student[key])
#                             print("#" * 40)
#                             choicefuc()
#
#         case 4:
#             if len(student)==0:
#                 print("no data found")
#                 choicefuc()
#             else:
#                 roll=input("enter enter the roll ")
#                 try:
#                     for key,val in student.items():
#                         if val[0]==roll:
#
#                                 student.pop(key)
#                                 print("student deleted")
#                                 choicefuc()
#
#                         else:
#                             print("roll no not found")
#                 except RuntimeError:
#                     pass
#                 choicefuc()
#         case 5:
#             roll_id=input("enter the roll no:")
#
#             for roll_id in student:
#
#                 print("1.update name")
#                 print("2.update age")
#                 print("3.update gender")
#                 print("4.update department")
#                 print("5.update semester")
#                 print("6.update subject info")
#
#
#                 ch=int(input("enter the "))
#
#                 match ch:
#                         case 1:
#                             up_name=input('enter the updated name')
#                             student[roll_id][1]=up_name
#                             print("#" * 50)
#                             print("student name update")
#                             print("#" * 50)
#                             choicefuc()
#                         case 2:
#                             up_gender=input('enter the updated gender')
#                             student[roll_id][2]=up_gender
#                             print("#" * 50)
#                             print("student gender updated")
#                             print("#" * 50)
#                             choicefuc()
#
#                         case 3:
#                             try:
#                                 up_age = int(input('enter the updated age'))
#                                 student[roll_id][3] = up_age
#                                 print("#" * 50)
#                                 print("student age update")
#                                 print("#" * 50)
#                                 choicefuc()
#                             except:
#                                 print("#"*40)
#                                 print("please enter the numeric value")
#                                 print("#"*40)
#                                 choicefuc()
#                         case 4:
#                             up_depart = input('enter the updated department')
#                             student[roll_id][4] = up_depart
#                             print("#" * 50)
#                             print("student department update")
#                             print("#" * 50)
#                             choicefuc()
#                         case 5:
#                             up_sem = input('enter the updated sem')
#                             student[roll_id][5] = up_sem
#                             print("#" * 50)
#                             print("student semester update")
#                             print("#" * 50)
#                             choicefuc()
#                         case 6:
#                             # print(student[id][7])
#
#                             reng=len(student[roll_id])
#                             print("value count",reng)
#                             up=reng-6
#                             print("seprate sub",up)
#                             for i in range(reng):
#                                 if i>5:
#                                     reng1=up/2
#                                     print("rang subject pair",reng1)
#                                     global sub_c,sub_n,count
#                                     for i in range(int(reng1)):
#                                         sub_c=sub_c+1
#                                         sub_n=sub_n+1
#                                         count=count+1
#
#                                         try:
#                                             print(count,'subject code:',student[roll_id][sub_c],'subject name:',student[roll_id][sub_n])
#                                             sub_c = sub_c + 1
#                                             sub_n = sub_n + 1
#                                         except:
#                                             pass
#
#                             chose=int(input("enter which subject you want to update"))
#                             global up_sub_c,up_sub_n
#                             if chose in range(count):
#                                 up_code = input("enter updated code")
#                                 up_name = input("enter updated name")
#                                 if chose==1:
#                                     up_sub_c = up_sub_c + 1
#                                     up_sub_n = up_sub_n + 1
#                                     student[roll_id][up_sub_c]=up_code
#                                     student[roll_id][up_sub_n]=up_name
#                                     up_sub_c = up_sub_c + 1
#                                     up_sub_n = up_sub_n + 1
#                                     print(student)
#                                     choicefuc()
#                                 if chose==2:
#                                     up_sub_c = up_sub_c + 2
#                                     up_sub_n = up_sub_n + 2
#                                     student[roll_id][up_sub_c] = up_code
#                                     student[roll_id][up_sub_n] = up_name
#                                     up_sub_c = up_sub_c + 2
#                                     up_sub_n = up_sub_n + 2
#                                     print(student)
#                                     choicefuc()
#                                 if chose==3:
#                                     up_sub_c = up_sub_c + 3
#                                     up_sub_n = up_sub_n + 3
#                                     student[roll_id][up_sub_c] = up_code
#                                     student[roll_id][up_sub_n] = up_name
#                                     up_sub_c = up_sub_c + 3
#                                     up_sub_n = up_sub_n + 3
#                                     print(student)
#                                     choicefuc()
#                                 if chose==4:
#                                     up_sub_c = up_sub_c + 4
#                                     up_sub_n = up_sub_n + 4
#                                     student[roll_id][up_sub_c] = up_code
#                                     student[roll_id][up_sub_n] = up_name
#                                     up_sub_c = up_sub_c + 4
#                                     up_sub_n = up_sub_n + 4
#                                     print(student)
#                                     choicefuc()
#                             else:
#                                 pass
#
#
#
#         case 6:
#                 print("1.sort by roll no")
#                 print("2.sort by name")
#                 print("3.sort by department")
#                 n=int(input("enter sort choice"))
#                 match n:
#                     case 1:
#                         print(sorted(student.items(), key=lambda x: x[0],reverse=True))
#                         choicefuc()
#                     case 2:
#                         print(sorted(student.items(), key=lambda x: x[1], reverse=True))
#                         choicefuc()
#                     case 3:
#                         print(sorted(student.items(), key=lambda x: x[4], reverse=True))
#                         choicefuc()
#
#
#
# def choicefuc():
#
#     print("menu choice for calculation")
#     print("1,Display all student list")
#     print("2,Add student detail")
#     print("3,Search student by rollno")
#     print("4.Delete student detail")
#     print("5.Update student detail")
#     print("6.Sorting (Rollno, Name, department, semester, Age)")
#     try:
#         choice = int(input("enter the your choice"))
#         if choice<=6:
#              cases(choice)
#
#
#         else:
#             print("#"*40)
#             print("please enter the correct no")
#             print("#" * 40)
#             choicefuc()
#
#     except ValueError:
#         print("#"*40)
#         print("enter the num of list")
#         print("#"*40)
#         choicefuc()
#
#
# choicefuc()













# student={}
# subject={}
# details={}
# def cases(num):
#     if num==0:
#         exit()
#     match num:
#         case 1:
#             print("#" * 50)
#             if len(student)==0:
#                 print("#" * 40)
#                 print("no data found")
#                 print("#" * 40)
#                 choicefuc()
#             else:
#                 print(student)
#                 print("#" * 50)
#             choicefuc()
#         case 2:
#
#             id = int(input("enter the id:"))
#             name=input("enter the student name:")
#             rollno=input("enter the student rollno:")
#             for key,val in student.items():
#                 if len(val)!=0:
#                     if val[0]==rollno:
#                         print("#"*40)
#                         print("please enter uniqe roll number this no already asign")
#                         print("#" * 40)
#                         choicefuc()
#             gender=input("enter the student gender:")
#             age=input("enter the student age:")
#             department=input("enter the studnet depart:")
#             sem=input("enter the student semester:")
#             sub_count = int(input("enter the subject you want to add:"))
#             data = [rollno, name, gender, age, department, sem]
#             #details = {id: [rollno, name, gender, age, department, sem]}
#             for i in range(sub_count):
#                 sub_name = input("subject name:")
#                 sub_code = input("subject code")
#                 d = [{sub_code: sub_name}]
#                 data.append(d)
#             student.update({id:data})
#             choicefuc()
#         case 3:
#             var=''
#             print("1.serach by name")
#             print("2.serach by rollno")
#             print("3.sercah by department")
#             serach=int(input("enter yor choice for search :"))
#             # import pdb;
#             # pdb.set_trace()
#             match serach:
#                 case 1:
#                     sub_val=''
#                     name = input("enter the name for find")
#                     #search_name=name.split(
#
#                     if len(name)==1:
#                         for key, val in student.items():
#                                 value=str(val[1])
#                                 s=value[0]
#                                 s.split()
#                                 if s == name:
#                                     print("#" * 40)
#                                     print(student[key])
#                                     print("#" * 40)
#                                     choicefuc()
#                                 else:
#                                     print("student not found")
#                     elif len(name)>1:
#                             for key, val in student.items():
#                                 try:
#                                     if val[1] == name:
#                                         print("#" * 40)
#                                         print(student[key])
#                                         print("#" * 40)
#                                         choicefuc()
#                                     else:
#                                         print("data not found")
#                                 except IndexError:
#                                     print("enter the proper name")
#                                     choicefuc()
#                     #elif len(name)>2:
#
#
#                     else:
#                         print("data not found please enter proper name")
#
#                 case 2:
#
#                     find_stu = input("enter the rollno:")
#                     if find_stu in student:
#                         print("#" * 50)
#                         print(student[find_stu])
#                         print("#" * 50)
#                         choicefuc()
#                     else:
#                         print("roll no not found")
#                         choicefuc()
#                 case 3:
#                     depart = input("enter the department for find")
#                     for key, val in student.items():
#                         if val[4] == depart:
#                             print("#" * 40)
#                             print(student[key])
#                             print("#" * 40)
#                             choicefuc()
#
#         case 4:
#             roll=input("enter enter the roll ")
#             try:
#                 for key,val in student.items():
#                     if val[0]==roll:
#
#                             student.pop(key)
#                             print("student deleted")
#
#                     else:
#                         print("roll no not found")
#             except RuntimeError:
#                 pass
#             choicefuc()
#         case 5:
#             id=input("enter the roll no:")
#             if id in student:
#
#                 print("1.update name")
#                 print("2.update age")
#                 print("3.update gender")
#                 print("4.update department")
#                 print("5.update semester")
#                 # print("6.update subject code")
#                 # print("7.update subject name:")
#
#                 ch=int(input("enter the "))
#                 match ch:
#                     case 1:
#                         up_name=input('enter the updated name')
#                         student[id][0]=up_name
#                         print("#" * 50)
#                         print("student name update")
#                         print("#" * 50)
#                         choicefuc()
#                     case 2:
#                         up_gender=input('enter the updated gender')
#                         student[id][1]=up_gender
#                         print("#" * 50)
#                         print("student gender updated")
#                         print("#" * 50)
#                         choicefuc()
#
#                     case 3:
#                         try:
#                             up_age = int(input('enter the updated age'))
#                             student[id][2] = up_age
#                             print("#" * 50)
#                             print("student age update")
#                             print("#" * 50)
#                             choicefuc()
#                         except:
#                             print("#"*40)
#                             print("please enter the numeric value")
#                             print("#"*40)
#                             choicefuc()
#                     case 4:
#                         up_depart = input('enter the updated department')
#                         student[id][3] = up_depart
#                         print("#" * 50)
#                         print("student department update")
#                         print("#" * 50)
#                         choicefuc()
#                     case 5:
#                         up_sem = input('enter the updated sem')
#                         student[id][4] = up_sem
#                         print("#" * 50)
#                         print("student semester update")
#                         print("#" * 50)
#                         choicefuc()
#                     case 6:
#                         up_sub_code = input('enter the updated subject code')
#                         student[id][5] = up_sub_code
#                         print("#" * 50)
#                         print("student subject code update")
#                         print("#" * 50)
#                         choicefuc()
#                     case 7:
#                         up_sub_name = input('enter the updated subject name')
#                         student[id][6] = up_sub_name
#                         print("#" * 50)
#                         print("student subject name update")
#                         print("#" * 50)
#                         choicefuc()
#             else:
#                 print("rollno not found")
#                 choicefuc()
#         case 6:
#             print("1.sort by roll no")
#             print("2.sort by name")
#             print("3.sort by department")
#             n=int(input("enter sort choice"))
#             match n:
#                 case 1:
#                     for i in sorted(student.keys()):
#                         print(student[i])
#                         choicefuc()
#                 case 2:
#                     for key,val in student.items():
#                         print(val[0])
#                         if sorted(val[1]):
#                             print(student[key])
#                             choicefuc()
#
#
# def choicefuc():
#     print("menu choice for calculation")
#     print("1,Display all student list")
#     print("2,Add student detail")
#     print("3,Search student by rollno")
#     print("4.Delete student detail")
#     print("5.Update student detail")
#     print("6.Sorting (Rollno, Name, department, semester, Age)")
#     try:
#         choice = int(input("enter the your choice"))
#         if choice<=6:
#              cases(choice)
#
#         else:
#             print("#"*40)
#             print("please enter the correct no")
#             print("#" * 40)
#             choicefuc()
#
#     except ValueError:
#         print("#"*40)
#         print("enter the num of list")
#         print("#"*40)
#         choicefuc()
#
#
# choicefuc()







"""
# def sorting_student():
#     global student_fields
#     global student_database
#
#     print("--- Sorting by Roll no ---")
#
#     # load csv file
#     data = csv.reader(open('students.csv'), delimiter=',')
#
#     print("sort data on the basis of roll no")
#     data = sorted(data, key=operator.itemgetter(0))
#
#     # displaying sorted data
#     print('After sorting:')
#     print(data)
#     print("-" * 200)
#
#     print("sort data on the basis of name")
#     data = sorted(data, key=operator.itemgetter(1))
#
#     # displaying sorted data
#     print('After sorting:')
#     print(data)
#     print("-" * 200)
#
#     print("sort data on the basis of semester")
#     data = sorted(data, key=operator.itemgetter(5))
#
#     # displaying sorted data
#     print('After sorting:')
#     print(data)
#     print("-" * 200)
#
#     print("sort data on the basis of age")
#     data = sorted(data, key=operator.itemgetter(2))
#
#     # displaying sorted data
#     print('After sorting:')
#     print(data)
#     print("-" * 200)

"""