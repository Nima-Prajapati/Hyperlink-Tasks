"""
Today's python task (4 Mar, 2022)

Task 1 : Iterator
Task 2 : Generator
Task 3 : Closure
"""

"""
Task 1 : Iterator
An iterator is an object that contains a countable number of values.
An iterator is an object that can be iterated upon, meaning that you can traverse through all the values.
Technically, in Python, an iterator is an object which implements the iterator protocol, which consist of the methods __iter__() and __next__().
Lists, tuples, dictionaries, and sets are all iterable objects. They are iterable containers which you can get an iterator from.
All these objects have a iter() method which is used to get an iterator:
"""
# 1
# mylist = [1,2,3,4]
# my_iter = iter(mylist)
# print(my_iter) #<list_iterator object at 0x7efc63fe7ca0>
# print(next(my_iter))
# print(next(my_iter))
# print(my_iter.__next__())
# print(next(my_iter))
# # print(next(my_iter)) #Error :StopIteration
# print("-"*30)

# for element in mylist:
#     print(element)


# 2 iter use in while loop because we can write True
# iter_obj = iter(mylist)
# while True:
#     try:
#         element = next(iter_obj)
#         print(element)
#     except StopIteration:
#         break
# print("-"*30)


# 3 create custom Iterators
# class MyIter:
#     def __init__(self,number = 0):
#         self.number = number
#
#     def __iter__(self):
#         self.n = 0
#         return self
#
#     def __next__(self):
#         if self.n <= self.number: # 0<=5,1<=5,
#             result = 2 + self.n # 2+0=2,2+1=3,
#             self.n += 1
#             return result
#         else:
#             raise StopIteration

# numbers = MyIter(5)
# i = iter(numbers)
# print(next(i))
# print(next(i))
# print(next(i))
# print(next(i))
# print(next(i))
# print(next(i))
# # print(next(i)) #raise StopIteration
# print("-"*30)


# for i in MyIter(5):
#     print(i)
# print("-"*30)



# 4 Python Infinite Iterators
# class InfIter:
#     """Infinite iterator to return all
#         odd numbers"""
#     def __iter__(self):
#         self.num = 1
#         return self
#
#     def __next__(self):
#         num = self.num
#         self.num += 2
#         return num
#
# a = iter(InfIter())
# # for x in a:
# #     print(x)
# print(next(a))
# print(next(a))
# print(next(a))
# print(next(a))


"""
Task 2 : Generator
Python generators are a simple way of creating iterators. All the work we mentioned above(iter,next,StopIteration) are automatically handled by generators in Python.
Simply speaking, a generator is a function that returns an object (iterator) which we can iterate over (one value at a time).
It is as easy as defining a normal function, but with a yield statement instead of a return statement.
If a function contains at least one yield statement (it may contain other yield or return statements), it becomes a generator function. 
Both yield and return will return some value from a function.
The difference is that while a return statement terminates a function entirely, yield statement pauses the function saving all its states and later continues 
    from there on successive calls.
    
---Here is how a generator function differs from a normal function.
1. Generator function contains one or more yield statements.
2. When called, it returns an object (iterator) but does not start execution immediately.
3. Methods like __iter__() and __next__() are implemented automatically. So we can iterate through the items using next().
4. Once the function yields, the function is paused and the control is transferred to the caller.
5. Local variables and their states are remembered between successive calls.
6. Finally, when the function terminates, StopIteration is raised automatically on further calls.
"""

def my_gen():
    n=1
    print("This is First Called")
    yield n

    n+=1
    print("This is Second Called")
    yield n

    n+=1
    print("This is Third Called")
    yield n

a = my_gen()
# next(a)
# next(a)
# next(a)
# # next(a) #StopIteration

for i in my_gen():
    print(i)
print("-"*50)


def rev_str(my_str):
    length = len(my_str)
    for i in range(length - 1, -1, -1):
        yield my_str[i]

# For loop to reverse the string
for char in rev_str("HELLO"):
    print(char)
print("-"*50)

# Generator Expression
my_list = [1,2,3,4,5]
pow_ = [i ** 2 for i in my_list]
print(pow_)  # [1, 4, 9, 16]

gen = (i ** 2 for i in my_list)
print(gen) # <generator object <genexpr> at 0x7f6b60459d20>
print(next(gen)) # 1
print(next(gen)) # 4
print(next(gen)) # 9

print("Sum of Gen : ",sum(gen))
print(max(i ** 2 for i in my_list))
print("Max Power : ",max(pow_))
print("-"*50)


#
def PowTwoGen(max=0):
    n = 0
    while n < max:
        yield 2 ** n
        n += 1

for i in PowTwoGen(7):
    print(i)
print("-"*50)


# Pipelining Generators
"""
If we want to find out the sum of squares of numbers in the Fibonacci series, we can do it in the following way by pipelining the output of generator functions together.
"""
def fibonacci_numbers(nums):
    x, y = 0, 1
    for _ in range(nums):
        x, y = y, x+y
        yield x

def square(nums):
    for num in nums:
        yield num**2

print(sum(square(fibonacci_numbers(3)))) #6
print("-"*50)



"""
Task 3 : Closure
A function defined inside another function is called a nested function. Nested functions can access variables of the enclosing scope.
In Python, these non-local variables are read-only by default and we must declare them explicitly as non-local (using nonlocal keyword) in order to modify them.
"""

def display_message(msg):
    # This is the outer enclosing function

    def print_message():
        # This is the nested function
        print(msg)

    print_message()

# We execute the function
# Output: Hello
display_message("Hello")


# 2 Closure Function
def display_message(msg):
    def print_message():
        print(msg)

    def print_message2():
        print(msg + " World")

    return print_message,print_message2

a,b = display_message("Hello")
a()
b()
print("-"*50)


def func1(n):
    def multiplication(x):
        return x * n
    return multiplication

a = func1(3)
# print(a)
# print(a(5)) #15

b = func1(5)
# print(b)
# print(b(4)) #20

print(a(2))
print(b(a(2))) #30
print("-"*50)

print(func1.__closure__) # None
print(a.__closure__)  #
print(a.__closure__[0].cell_contents) #3
print(b.__closure__[0].cell_contents) #5


"""
The display_message() function was called with the string "Hello" and the returned function was bound to the name another. 
On calling another(), the message was still remembered although we had already finished executing the display_message() function.
This technique by which some data ("Hello in this case) gets attached to the code is called closure in Python.
"""
"""
=>When do we have closures?
------------------------------
The criteria that must be met to create closure in Python are summarized in the following points.
1.We must have a nested function (function inside a function).
2.The nested function must refer to a value defined in the enclosing function.
3.The enclosing function must return the nested function.

=>When to use closures?
-------------------------
When there are few methods (one method in most cases) to be implemented in a class, closures can provide an alternate and more elegant solution. 
But when the number of attributes and methods get larger, it's better to implement a class.
"""