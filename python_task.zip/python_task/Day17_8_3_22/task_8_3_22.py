"""
Today's python task (8 Mar, 2022)

Task 1: RegEX

Regular Expression, is a sequence of characters that forms a search pattern.
RegEx can be used to check if a string contains the specified search pattern.
Methods:
    - match(): match() searches only from the beginning of the string
    - findall(): Returns a list containing all matches
    - split(): Returns a list where the string has been split at each match
    - sub(): Replaces one or many matches with a string
    - subn():
    - search(): Returns a Match object if there is a match anywhere in the string

- "^The.*Spain$" : it starts with "The" and ends with "Spain"
"""

import re

"""
Metacharacters
Metacharacters are characters with a special meaning:
"""
# 1. []	A set of characters
txt = "John is a data scientist who knows Python. John works at google last 5 years."
# Find all lower case characters alphabetically between "a" and "m":
x = re.findall("[a-m]", txt)
print(x)

# 2. \	Signals a special sequence (can also be used to escape special characters)
# Find all digit characters:
x = re.findall("\d", txt)
print(x)

# 3. .	Any character (except newline character)
# Search for a sequence that starts with "he", followed by two (any) characters, and an "o":
x = re.findall("kn..s", txt)
print(x)

# 4. ^	Starts with
# Check if the string starts with 'hello':
x = re.findall("^John", txt)
if x:
    print("Yes, the string starts with 'John'")
else:
    print("No match")

# 5. $	Ends with
# Check if the string ends with 'Python':
x = re.findall("Python$", txt)
if x:
    print("Yes, the string ends with 'Python'")
else:
    print("No match Ends with $")

# 6. *	Zero or more occurrences
txt = "hello planet"
# Search for a sequence that starts with "he", followed by 0 or more  (any) characters, and an "o":
x = re.findall("he.*o", txt)
print(x)

# 7. +	One or more occurrences
txt = "hello planet"
# Search for a sequence that starts with "he", followed by 1 or more  (any) characters, and an "o":
x = re.findall("he.+o", txt)
print(x)

# 8. ?	Zero or one occurrences
txt = "hello planet"
# Search for a sequence that starts with "he", followed by 0 or 1  (any) character, and an "o":
x = re.findall("he.?o", txt)
print(x)
# This time we got no match, because there were not zero, not one, but two characters between "he" and the "o"


# 9. {}	Exactly the specified number of occurrences
txt = "hello planet"
# Search for a sequence that starts with "he", followed excactly 2 (any) characters, and an "o":
x = re.findall("he.{2}o", txt)
print(x)

# 10. |	Either or
txt = "The rain in Spain falls mainly in the plain!"
# Check if the string contains either "falls" or "stays":
x = re.findall("falls|stays", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 11. () Capture and group


# 12. *?, +?, ?? The '*', '+', and '?' qualifiers are all greedy; they match as much text as possible. Sometimes this
# behaviour isn’t desired; if the RE <.*> is matched against '<a> b <c>', it will match the entire string,
# and not just '<a>'. Adding ? after the qualifier makes it perform the match in non-greedy or minimal fashion; as
# few characters as possible will be matched. Using the RE <.*?> will match only '<a>'.


"""
Special Sequences
"""
# 1. \A	Returns a match if the specified characters are at the beginning of the string
txt = "The rain in Spain"
# Check if the string starts with "The":
x = re.findall("\AThe", txt)
print(x)
if x:
    print("Yes, there is a match!")
else:
    print("No match")

# 2. \b	Returns a match where the specified characters are at the beginning or at the end of a word
# (the "r" in the beginning is making sure that the string is being treated as a "raw string")
txt = "The rain in Spain"
# Check if "ain" is present at the end of a WORD:
x = re.findall(r"ain\b", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# Check if "ain" is present at the beginning of a WORD:
x = re.findall(r"\bain", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 3. \B	Returns a match where the specified characters are present, but NOT at the beginning (or at the end) of a word
# (the "r" in the beginning is making sure that the string is being treated as a "raw string")
# Check if "ain" is present, but NOT at the beginning of a word:
x = re.findall(r"\Bain", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# Check if "ain" is present, but NOT at the end of a word:
x = re.findall(r"ain\B", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 4. \d	Returns a match where the string contains digits (numbers from 0-9)
# Check if the string contains any digits (numbers from 0-9):
x = re.findall("\d", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 5. \D	Returns a match where the string DOES NOT contain digits
# Return a match at every no-digit character:
x = re.findall("\D", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 6. \s	Returns a match where the string contains a white space character
# Return a match at every white-space character:
x = re.findall("\s", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 7. \S	Returns a match where the string DOES NOT contain a white space character
# Return a match at every NON white-space character:
x = re.findall("\S", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 8. \w	Returns a match where the string contains any word characters (characters from a to Z, digits from 0-9,
#  and the underscore _ character)
# Return a match at every word character (characters from a to Z, digits from 0-9, and the underscore _ character):
x = re.findall("\w", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 9. \W	Returns a match where the string DOES NOT contain any word characters
# Return a match at every NON word character (characters NOT between a and Z. Like "!", "?" white-space etc.):
x = re.findall("\W", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 10. \Z  Returns a match if the specified characters are at the end of the string
# Check if the string ends with "Spain":
x = re.findall("Spain\Z", txt)
print(x)
if x:
    print("Yes, there is a match!")
else:
    print("No match")

"""
Sets
A set is a set of characters inside a pair of square brackets [] with a special meaning
"""
# 1. [arn]	Returns a match where one of the specified characters (a, r, or n) are present
# Check if the string has any a, r, or n characters:
x = re.findall("[arn]", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 2.[a-n]	Returns a match for any lower case character, alphabetically between a and n
# Check if the string has any characters between a and n:
x = re.findall("[a-n]", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 3. [^arn]	Returns a match for any character EXCEPT a, r, and n
# C heck if the string has other characters than a, r, or n:
x = re.findall("[^arn]", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 4. [0123]	Returns a match where any of the specified digits (0, 1, 2, or 3) are present
# Check if the string has any 0, 1, 2, or 3 digits:
x = re.findall("[0123]", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 5. [0-9]	Returns a match for any digit between 0 and 9
# Check if the string has any digits:
x = re.findall("[0-9]", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 6. [0-5][0-9]	Returns a match for any two-digit numbers from 00 and 59
# Check if the string has any two-digit numbers, from 00 to 59:
x = re.findall("[0-5][0-9]", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 7. [a-zA-Z]	Returns a match for any character alphabetically between a and z, lower case OR upper case
# Check if the string has any characters from a to z lower case, and A to Z upper case:
x = re.findall("[a-zA-Z]", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

# 8. [+] In sets, +, *, ., |, (), $,{} has no special meaning, so [+] means: return a match for any + character in
#     the string
# Check if the string has any + characters:
x = re.findall("[+]", txt)
print(x)
if x:
    print("Yes, there is at least one match!")
else:
    print("No match")

import re

name=input("Enter the name : ")
patn1 = re.match("[a-zA-Z]",name)  # must be use capitacl and small alfabate

if patn1:
    print(name," is right formate")
else:
    print("use only capital or small char")
    name = input("Enter the name : ")

email=input("Enter the email :")
patn2=re.match("[a-z]+[0-9]*[@][a-z]+[.][a-z]*[.]*[a-z]{2,2}",email)  # email pattern
# regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
# [A-Za-z0-9-_]+(.[A-Za-z0-9-_]+)*@[A-Za-z0-9-]+(.[A-Za-z0-9]+)*(.[A-Za-z]{2,})
# if re.match("\A(?P<name>[\w\-_]+)@(?P<domain>[\w\-_]+).(?P<toplevel>[\w]+)\Z",email,re.IGNORECASE):
#     print("email is valid")
# else:
#     print("email is invalid")

if patn2:
    print(email," is right formate")
else:
    print("please enter proper email id")
    email = input("Enter the email :")

# username=input("Enter the user name :")
# pate3=re.match("[_@.a-zA-Z0-9]",username)  #u ser can use only this char
#
# if pate3:
#     print(username," is right formate")
# else:
#     print("please enter proper username ˳")

# phone=input("Enter the phone number with indian country code")
# #re.compile("(0/91)?[7-9][0-9]{9}")
# patt4=re.match("^[+][91][0-9]{10}",phone)
#
# if patt4:
#     print(phone," is right formate")
# else:
#     print("please enter proper phone number ")

password = input("Enter the pass word:")
# At least a letter between[a-z]
# At least a letter between[A-Z]
# At least a number between[0-9]
# At least a character from[$#@]
x = True
while x:
    if len(password) < 6 or len(password) > 11:
        break
    elif not re.search("[a-z]", password):
        break
    elif not re.search("[0-9]", password):
        break
    elif not re.search("[A-Z]", password):
        break
    elif not re.search("[$#@]", password):
        break
    elif re.search("\s", a):
        break
    else:
        print("Valid Password")
        x = False
        break

if x:
    print("Not a Valid Password")

# patt5 = re.match("[a-zA-Z]+[0-9]+[@._]",password)
#
# if patt5:
#     print("its done")
# else:
#     print("not done")

# text = input("Enter the text:")
# patt6 = re.match("^a....s$",text)#start with a and how many(.)s are here that count you can use char and end with s
#
# if patt6:
#     print("its done")
# else:
#     print("not done")

# text1 = input("enter the text:")
# patt7 = re.match("^aa+d$",text1)#start with a and how many(.)s are here that count you can use char and end with s
#
# if patt7:
#     print("its done")
# else:
#     print("not done")

# tex3 = input("enter the tex")
#
# patte9 = re.match(r"\A([A-Z].*?)\s", tex3)
#
# if patte9:
#     print("done")
# else:
#     print("not done")
