# 14-2-22
$ python3
import keyword
print(keyword.kwlist)
op:['False', 'None', 'True', 'and', 'as', 'assert', 'async', 'await', 'break', 'class', 'continue', 'def', 'del', 'elif', 'else', 'except', 'finally', 'for', 
'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'try', 'while', 'with', 'yield']

a=10
type(a)

a=10.2
type(a)

a = "string"
type(a)
op:str

a = True
op:bool

a = None
op:NoneType

print("string")
print(True)

str1 = "Hello everyone"
len(str1)
op:14

str1.split()
op:['Hello','everyone']

str1.join('')
op:''

''.join(str1)
op:'Hello everyone'

''.join.str1.split()
op:Helloeveryone

status = True
status == True op:True
1 == 1 op:True
1 == 0.2 op:False
True or False op:True
True and False op:False
6>9 op:False
True == 1 op:True
False == 1 op:False
False == 0 op:True
True + True + True + True op:4

str = None
str1 = ''
len(str1) op:0
None == 0 op:False
None == [] op :False

def add(x):
	if(x % 2)== 0:
			return True

print(add(2))
op:True
print(add(0.2))  op:None

a = None
a is not None op:False
a = "str"
a is not None op:True




