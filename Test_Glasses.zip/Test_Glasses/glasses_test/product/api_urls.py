from django.urls import include, path
from rest_framework import routers

from glasses_test.product import views

router = routers.SimpleRouter()
router.register('product', views.ProductViewSet, basename='product')

app_name = 'product'
urlpatterns = [
    path('', include(router.urls))
]
