from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response

from glasses_test.product.models import Product
from glasses_test.product.serializers import ProductSerializer, ProductColorSerializer, ProductImageSerializer
from glasses_test.utils.permissions import IsReadAction


class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [permissions.IsAuthenticated, IsReadAction | permissions.IsAdminUser]
    lookup_field = 'slug'

    @action(methods=['post'], detail=False, permission_classes=[permissions.IsAuthenticated, permissions.IsAdminUser],
            url_path='add-product', url_name='add-product')
    def add_product(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(methods=['post'], detail=False, permission_classes=[permissions.IsAuthenticated, permissions.IsAdminUser],
            url_path='add-product-color', url_name='add-product-color')
    def add_product_color(self, request, *args, **kwargs):
        serializer = ProductColorSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(methods=['post'], detail=True, permission_classes=[permissions.IsAuthenticated, permissions.IsAdminUser],
            url_path='add-product-image', url_name='add-product-image')
    def add_product_image(self, request, *args, **kwargs):
        product = self.get_object()
        serializer = ProductImageSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        data.update({'product': product})
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

