from django.contrib.auth import get_user_model
from django.db import models

# Create your models here.
from django.utils.text import slugify
from model_utils.models import TimeStampedModel

from glasses_test.category.models import SubCategory
from django.utils.translation import ugettext_lazy as _

from glasses_test.utils.utils import get_product_photo_path

User = get_user_model()


class Product(TimeStampedModel):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    subcategory = models.ForeignKey(SubCategory, on_delete=models.CASCADE, related_name='product_subcategory')
    name = models.CharField(_('name'), max_length=30, unique=True,
                            error_messages={'unique': _('Enter unique product name')})
    price = models.DecimalField(decimal_places=2, max_digits=6, null=True, blank=True)
    slug = models.SlugField(_('slug'), max_length=100, null=True, blank=True)
    # sku = models.CharField(max_length=30)
    # rating = models.FloatField(null=True, blank=True)
    frame_size = models.CharField(max_length=40, null=True, blank=True)
    frame_width = models.CharField(max_length=20, null=True, blank=True)
    # color =
    description = models.TextField(null=True, blank=True)
    stock = models.PositiveSmallIntegerField()

    class Meta:
        verbose_name = _('Product')
        verbose_name_plural = _('Products')

    def __str__(self):
        return self.name or self.user

    def save(self, *args, **kwargs):
        self.slug = slugify(self.name)
        super().save(*args, **kwargs)


class ProductPhoto(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='photo_product')
    image = models.ImageField(
        upload_to=get_product_photo_path,
        height_field='height',
        width_field='width',
        null=True,
        blank=True
    )
    width = models.PositiveSmallIntegerField(blank=True, null=True)
    height = models.PositiveSmallIntegerField(blank=True, null=True)

    def save(self, *args, **kwargs):
        if self.image and (not self.width or not self.height):
            self.width = self.image.width
            self.height = self.image.height

        super().save(*args, **kwargs)


class ProductColor(TimeStampedModel):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='color_product')
    name = models.CharField(max_length=20)

    class Meta:
        verbose_name = _('Color')
        verbose_name_plural = _('Colors')

    def __str__(self):
        return self.name or self.product


class ProductRatings(TimeStampedModel):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='rating_product')
    rating = models.FloatField(null=True, blank=True)

    class Meta:
        verbose_name = _('Rating')
        verbose_name_plural = _('Ratings')
