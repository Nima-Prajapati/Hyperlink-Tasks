from django.contrib import admin

# Register your models here.
from glasses_test.category.models import Category

# admin.site.register(Category)
