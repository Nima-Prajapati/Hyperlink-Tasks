from rest_framework import serializers
from rest_framework.exceptions import ValidationError

from glasses_test.category.serializers import SubCategorySerializer
from glasses_test.product.models import ProductRatings, ProductPhoto, ProductColor, Product


class ProductRatingSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductRatings
        fields = ('user', 'product', 'rating')


class ProductImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductPhoto
        fields = ('image', 'width', 'height')


class ProductColorSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductColor
        fields = ('product', 'name',)

    def create(self, validated_data):
        data = ProductColor.objects.filter(product=validated_data['product'], name=validated_data['name'])
        if data:
            raise ValidationError('Please enter unique color')

        return super().create(validated_data)


class ProductSerializer(serializers.ModelSerializer):
    product_ratings = ProductRatingSerializer(read_only=True, many=True)
    photo_product = ProductImageSerializer(read_only=True, many=True)
    color_product = ProductColorSerializer(read_only=True, many=True)
    product_subcategory = SubCategorySerializer(source='subcategory', read_only=True)

    class Meta:
        model = Product
        fields = ('user', 'subcategory', 'name', 'price', 'slug', 'frame_size', 'frame_width', 'description', 'stock',
                  'product_subcategory', 'product_ratings', 'photo_product', 'color_product')
        read_only_fields = ('slug', 'user')

    def create(self, validated_data):
        validated_data.update({'user': self.context['request'].user})
        return super().create(validated_data)
