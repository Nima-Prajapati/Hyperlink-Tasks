from django.shortcuts import render

# Create your views here.
from rest_framework.decorators import action
from rest_framework.exceptions import ValidationError
from rest_framework.mixins import CreateModelMixin
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.viewsets import GenericViewSet
from unicef_restlib.views import MultiSerializerViewSetMixin

from glasses_test.custom_auth.models import ApplicationUser
from glasses_test.registration.serializers import CheckUserDataSerializer, RegistrationSerializer, CheckPhoneSerializer, \
    CheckOTPSerializer


class RegistrationViewSet(MultiSerializerViewSetMixin, CreateModelMixin, GenericViewSet):
    queryset = ApplicationUser.objects.all()
    serializer_class = RegistrationSerializer
    print("serializer_class:", serializer_class)
    serializer_action_classes = {
        'check_user_data': CheckUserDataSerializer,
        'send_sms': CheckPhoneSerializer,
        'check_otp': CheckOTPSerializer,

    }
    permission_classes = (AllowAny,)


    @action(methods=['post'], permission_classes=(AllowAny,), url_name='check', url_path='check', detail=False)
    def check_user_data(self, *args, **kwargs):
        serializer = self.get_serializer(data=self.request.data)
        serializer.is_valid(raise_exception=True)
        return Response(serializer.data)

    @action(methods=['post'], permission_classes=(AllowAny,), url_path='send-sms-code', url_name='send-sms-code', detail=False)
    def send_sms(self, *args, **kwargs):
        serializer = self.get_serializer(data=self.request.data)
        serializer.is_valid(raise_exception=True)
        return Response({'otp': 1234})

    @action(methods=['post'], permission_classes=(AllowAny,), url_path='otp_verify', url_name='otp_verify', detail=False)
    def check_otp(self, *args, **kwargs):
        otp = '1234'
        serializer = self.get_serializer(data=self.request.data)
        serializer.is_valid(raise_exception=True)
        if otp != serializer.data['otp']:
            raise ValidationError('Enter valid otp')

        return Response('OTP Verified')
