import phonenumbers
from django.contrib.auth.password_validation import validate_password
from phonenumber_field.serializerfields import PhoneNumberField
from rest_framework import serializers
from rest_framework.serializers import Serializer
import re

from glasses_test.custom_auth.models import ApplicationUser


class CheckUserDataSerializer(serializers.ModelSerializer):
    phone = PhoneNumberField()
    country_code = serializers.SerializerMethodField()
    phone_number = serializers.SerializerMethodField()
    class Meta:
        model = ApplicationUser
        # fields = ('username', 'password',)
        fields = ('email', 'phone', 'password', 'country_code', 'phone_number')

        extra_kwargs = {
            'password': {'validators': [validate_password]},
            'email': {'required': True},
            # 'username': {'required': True}
        }

    # def validate(self, attrs):
    #     regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9._]+\.[A-Z|a-z]{2,}\b'
    #     if re.fullmatch(regex, attrs['username']):
    #         # if '@' in attrs['username']:
    #         email = super().validate(attrs)
    #         print("validated_data", email)
    #         email.update({'email': email['username']})
    #         return email
    #     else:
    #         validated_data = super().validate(attrs)
    #         validated_data.update({'phone': validated_data['username']})
    #         return validated_data

    def get_country_code(self, obj):
        try:
            phone = phonenumbers.parse(str(obj['phone']))
            return f'+{phone.country_code}'
        except phonenumbers.NumberParseException:
            return None

    # national phone number
    def get_phone_number(self, obj):
        try:
            phone = phonenumbers.parse(str(obj['phone']))
            return str(phone.national_number)
        except phonenumbers.NumberParseException:
            return None


class CheckPhoneSerializer(Serializer):
    phone = PhoneNumberField(required=True)


class RegistrationSerializer(serializers.ModelSerializer):
    phone = PhoneNumberField(write_only=True)

    class Meta:
        model = ApplicationUser
        # fields = ('uuid', 'username', 'password',)
        fields = ('email', 'phone', 'password', 'uuid',)
        extra_kwargs = {
            'password': {'write_only': True,
            'validators': [validate_password]},
        }
        read_only_fields = ('uuid',)

    def create(self, validated_data):
        print("validated_data : ", validated_data)
        password = validated_data.pop('password', None)
        user = super().create(validated_data)
        user.set_password(password)
        user.save(update_fields=['password'])

        return user


class CheckOTPSerializer(Serializer):
    phone = PhoneNumberField()
    otp = serializers.CharField(max_length=4, required=True)
