from django.urls import path, include
from rest_framework import routers

from glasses_test.registration import views

router = routers.SimpleRouter()
router.register('', views.RegistrationViewSet, basename='registration')


app_name = 'glasses_test'

urlpatterns = [
    path('', include(router.urls))
]
