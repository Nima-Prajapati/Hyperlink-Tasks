from django.shortcuts import render
from rest_framework import viewsets, permissions, status

# Create your views here.
from rest_framework.decorators import action
from rest_framework.response import Response

from glasses_test.category.models import Category, SubCategory
from glasses_test.category.serializers import CategorySerializer, SubCategorySerializer, SubCategoryPhotoSerializer
from glasses_test.utils.permissions import IsReadAction


class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [permissions.IsAuthenticated, IsReadAction]

    @action(methods=['post'], detail=False, permission_classes=[permissions.IsAuthenticated, permissions.IsAdminUser],
            url_path='add-category')
    def add_category(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        print("category serializer:", serializer)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(data=serializer.data, status=status.HTTP_201_CREATED)


class SubCategoryViewSet(viewsets.ModelViewSet):
    queryset = SubCategory.objects.all()
    serializer_class = SubCategorySerializer
    permission_classes = [permissions.IsAuthenticated, IsReadAction]

    # lookup_field = ''

    @action(methods=['post'], detail=False, permission_classes=[permissions.IsAuthenticated, permissions.IsAdminUser],
            url_path='add-subcategory')
    def add_category(self, request, *args, **kwargs):
        # user = self.get_object()  # login user
        # self.check_object_permissions(request, user)
        serializer = self.get_serializer(data=request.data)
        print("serializer :", serializer)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(data=serializer.data, status=status.HTTP_201_CREATED)

    @action(methods=['post'], detail=True, permission_classes=[permissions.AllowAny],
            url_path='photos/update_or_create', url_name='set_photo')
    def set_photo(self, request, *args, **kwargs):
        serializer = SubCategoryPhotoSerializer(request.user, data=request.data)

        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        serializer.save()

        return Response(serializer.data, status=status.HTTP_201_CREATED)
