from django.contrib.auth import get_user_model
from django.db import models

# Create your models here.
from django.utils.text import slugify
from model_utils.models import TimeStampedModel
from django.utils.translation import ugettext_lazy as _

from glasses_test.category.mixins import CategoryImageMixin

User = get_user_model()


class Category(TimeStampedModel):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    name = models.CharField(_('name'), max_length=150, unique=True,
                            error_messages={'unique': _('A category with that name already exists')})
    slug = models.SlugField(max_length=200, null=True, blank=True)

    class Meta:
        verbose_name = _('Category')
        verbose_name_plural = _('Categories')

    def __str__(self):
        return f'{self.name}'

    def save(self, *args, **kwargs):
        self.slug = slugify(self.name)
        super().save(*args, **kwargs)


class SubCategory(TimeStampedModel, CategoryImageMixin):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    name = models.CharField(_('name'), max_length=150, unique=True,
                            error_messages={'unique': _('A subcategory with that name already exists')})
    slug = models.SlugField(max_length=200, null=True, blank=True)

    def __str__(self):
        return f'{self.name}'

    def save(self, *args, **kwargs):
        if self.photo and (not self.width_photo or not self.height_photo):
            self.width_photo = self.photo.width
            self.height_photo = self.photo.height

        return super(SubCategory, self).save(*args, **kwargs)
