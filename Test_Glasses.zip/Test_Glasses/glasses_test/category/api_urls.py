from django.urls import path, include
from rest_framework import routers

from glasses_test.category import views

router = routers.SimpleRouter()
router.register('category', views.CategoryViewSet, basename='category'),
router.register('subcategory', views.SubCategoryViewSet, basename='subcategory'),

app_name = 'category'

urlpatterns = [
    path('', include(router.urls)),
]
