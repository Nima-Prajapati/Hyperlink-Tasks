from rest_framework import serializers
from rest_framework.exceptions import ValidationError

from glasses_test.category.models import Category, SubCategory


class CategorySerializer(serializers.ModelSerializer):
    name = serializers.CharField(required=True)

    class Meta:
        model = Category
        fields = ('id', 'user', 'name', 'slug',)
        read_only_fields = ('slug',)

    def create(self, validated_data):
        category = Category.objects.filter(name=validated_data['name'])
        if category:
            raise ValidationError('Product name is duplicate')

        validated_data.update({'user': self.context['request'].user})
        return super().create(validated_data)


class SubCategoryPhotoSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    image = serializers.ImageField(source='photo', allow_null=True)
    width = serializers.ReadOnlyField(source='width_photo', allow_null=True)
    height = serializers.ReadOnlyField(source='height_photo', allow_null=True)

    class Meta:
        model = SubCategory
        fields = ('id', 'image', 'width', 'height')


class SubCategorySerializer(serializers.ModelSerializer):
    name = serializers.CharField(required=True)
    category_details = CategorySerializer(source='category', read_only=True)

    # subcategory_photo = SubCategoryPhotoSerializer(,read_only=True)

    class Meta:
        model = SubCategory
        fields = ('id', 'name', 'category', 'slug', 'photo', 'category_details')
        read_only_fields = ('id', 'slug',)

    def create(self, validated_data):
        subcategory = SubCategory.objects.filter(name=validated_data['name'])
        if subcategory:
            raise ValidationError('Product name is duplicate')

        validated_data.update({'user': self.context['request'].user})
        return super().create(validated_data)
