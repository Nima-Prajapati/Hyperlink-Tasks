import phonenumbers
from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers
from rest_framework.exceptions import ValidationError as DjangoValidationError
from rest_framework.exceptions import ValidationError

User = get_user_model()


class UserAuthSerializer(serializers.Serializer):
    email = serializers.CharField(required=False)
    phone = serializers.CharField(required=False)
    password = serializers.CharField()

    def validate(self, attrs):
        validated_data = super().validate(attrs)
        if 'email' not in validated_data and 'phone' not in validated_data:
            raise ValidationError('email or phone should be provided')

        return validated_data


class BaseUserSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    country_code = serializers.SerializerMethodField()
    phone_number = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ('id', 'uuid', 'email', 'phone', 'password', 'country_code', 'phone_number',)
        read_only_fields = ('uuid',)

    def get_country_code(self, obj):
        try:
            phone = phonenumbers.parse(str(obj.phone))
            return f'+{phone.country_code}'
        except phonenumbers.NumberParseException:
            return None

    def get_phone_number(self, obj):
        try:
            phone = phonenumbers.parse(str(obj.phone))
            return str(phone.country_code)
        except phonenumbers.NumberParseException:
            return None

    def create(self, validated_data):
        user = self.get_user()
        validated_data['user'] = user

        return super().create(validated_data)

class PasswordValidationSerializer(serializers.Serializer):
    password = serializers.CharField()

    def validate_password(self, password):
        try:
            validate_password(password)
        except DjangoValidationError as ex:
            raise ValidationError(ex.messages)
        return password