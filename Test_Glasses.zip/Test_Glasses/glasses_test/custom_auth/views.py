from django.contrib.auth import get_user_model, authenticate
from django.contrib.sites.shortcuts import get_current_site
from django.shortcuts import render, get_object_or_404
from django.utils import timezone
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import viewsets, permissions, status

# Create your views here.
from rest_framework.decorators import action
from rest_framework.exceptions import ValidationError, NotFound
from rest_framework.filters import SearchFilter
from rest_framework.response import Response
from unicef_restlib.pagination import DynamicPageNumberPagination

from glasses_test.custom_auth.models import PasswordResetId
from glasses_test.custom_auth.permissions import IsSelf
from glasses_test.custom_auth.serializers import UserAuthSerializer, BaseUserSerializer, PasswordValidationSerializer
from glasses_test.utils.permissions import IsReadAction
from django.utils.translation import ugettext_lazy as _

User = get_user_model()


class UserAuthViewSet(viewsets.ViewSet):
    NEW_TOKEN_HEADER = 'X-Token'
    permission_classes = (permissions.IsAuthenticated,)

    @classmethod
    def get_success_headers(cls, user):
        return {cls.NEW_TOKEN_HEADER: user.user_auth_tokens.create().key}

    def _auth(self, request, *args, **kwargs):
        auth_serializer = UserAuthSerializer(data=request.data, context={'request': request, 'view': self})
        # print("auth serializer : ", auth_serializer)
        auth_serializer.is_valid(raise_exception=True)

        user = authenticate(request, **auth_serializer.data)
        # print("User : ", user)
        if not user:
            raise ValidationError('Invalid credentials')

        user_details = BaseUserSerializer(
            instance=user, context={'request': request, 'view': self}
        ).data
        user_details.update(self.get_success_headers(user))

        return Response(data=user_details, status=status.HTTP_201_CREATED)

    @action(methods=['post'], permission_classes=[permissions.AllowAny], url_path='classic', url_name='classic',
            detail=False)
    def classic_path(self, request, *args, **kwargs):
        return self._auth(request, *args, **kwargs)

    @action(methods=['delete'], detail=False)
    def logout(self, request, *args, **kwargs):
        # print("Logout")
        if request.user.user_auth_tokens.count() > 1:
            self.request.auth.delete()
        else:
            request.user.user_auth_tokens.all().delete()
        return Response(None, status=status.HTTP_204_NO_CONTENT)


class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    permission_classes = [permissions.IsAuthenticated, IsReadAction | IsSelf]
    lookup_field = 'uuid'
    pagination_class = DynamicPageNumberPagination

    # filter_backends = (DjangoFilterBackend, SearchFilter)

    # search_fields = ('fullname', 'last_name', 'first_name')
    # ordering = ('fullname',)

    def get_object(self):
        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field
        if self.kwargs[lookup_url_kwarg] == 'me':
            return self.request.user

        return super().get_object()

    def _get_base_serializer_class(self):

        if self.get_object() == self.request.user:
            return BaseUserSerializer

        return BaseUserSerializer

    @action(methods=['post'], detail=False, permission_classes=[permissions.AllowAny],
            url_path='reset-password-email', url_name='reset_password_email')
    def reset_password_email(self, request, *args, **kwargs):
        user_email = request.data.get('phone')
        if not user_email:
            raise ValidationError(_("Phone field is required."))

        user_model = User
        user = user_model.objects.filter(phone__iexact=user_email).first()
        if not user:
            raise NotFound(_("User doesn't exists"))

        password_reset_obj = PasswordResetId.objects.create(user=user)
        site = get_current_site(request)  # site store domain,url
        print("Site : ", site)
        print("password_reset_obj : ", password_reset_obj)
        return Response(data={'password_reset_token': password_reset_obj.id})
        # return Response(_("Email has been sent."))

    @action(methods=['post'], detail=False, permission_classes=[permissions.AllowAny],
            url_path='reset-change-password/(?P<password_reset_id>.*)', url_name='reset_change_password')
    def password_reset_change_password(self, request, *args, **kwargs):
        password_reset_obj = get_object_or_404(
            PasswordResetId,
            pk=self.kwargs.get('password_reset_id'),
            expiration_time__gt=timezone.now()
        )
        serializer = PasswordValidationSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        user = User.objects.get(pk=password_reset_obj.user.id)

        user.set_password(serializer.data['password'])
        user.save()

        PasswordResetId.objects.filter(pk=password_reset_obj.pk).delete()

        return Response(_("Password reset successfully!"))
