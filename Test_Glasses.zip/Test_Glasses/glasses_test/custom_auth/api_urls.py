from django.urls import path, include
from rest_framework import routers

from glasses_test.custom_auth import views

router = routers.SimpleRouter()
router.register('auth', views.UserAuthViewSet, basename='users'),
router.register('users', views.UserViewSet, basename='users'),

app_name = 'glasses_test'

urlpatterns = [
    path('', include(router.urls))
]

