from django.contrib import admin

# Register your models here.
from glasses_test.category.models import Category
from glasses_test.product.models import Product

admin.site.register(Category)
admin.site.register(Product)
