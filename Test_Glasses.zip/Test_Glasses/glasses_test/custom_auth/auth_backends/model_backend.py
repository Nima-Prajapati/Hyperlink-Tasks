from django.contrib.auth import get_user_model
from django.contrib.auth.backends import ModelBackend
from django.db.models import Q
from rest_framework.exceptions import PermissionDenied


class CustomModelBackend(ModelBackend):

    def authenticate(self, request, username=None, email=None, phone=None, password=None, **kwargs):
        if username:
            email = username

        # print("email authenticate:", email)
        if not email and not phone:
            return None

        UserModel = get_user_model()

        # username_query_dict = {'username__iexact': username}
        email_query_dict = {'email__iexact': email}
        # print("email_query_dict: ",email_query_dict)
        phone_query_dict = {'phone': phone}

        try:
            query_filter = Q()
            # if username:
            #     query_filter |= Q(**username_query_dict)
            if email:
                query_filter |= Q(**email_query_dict)
            if phone:
                query_filter |= Q(**phone_query_dict)

            print(query_filter)

            user = UserModel.objects.get(query_filter)

            if not user.is_active:
                raise PermissionDenied("User is not active.")

        except UserModel.DoesNotExist:
            return None
        # except Exception:
        #     return None
        else:
            if user.check_password(password):
                return user

        return None

    # def authenticate(self, request, username=None, password=None, **kwargs):
    #     if '@' in username:
    #         email = username
    #         # kwargs = {'email': username}
    #     else:
    #         phone = username
    #         # kwargs = {'mobile_phone': username}
    #
    #     UserModel = get_user_model()
    #     username_query_dict = {'username__iexact': username}
    #     try:
    #         query_filter = Q()
    #         if username:
    #             query_filter |= Q(**username_query_dict)
    #
    #         print(query_filter)
    #         user = UserModel.objects.get(query_filter)
    #         if not user.is_active:
    #             raise PermissionDenied("User is not active.")
    #
    #     except UserModel.DoesNotExist:
    #         return None
    #     else:
    #         if user.check_password(password):
    #             return user
    #
    #     return None
