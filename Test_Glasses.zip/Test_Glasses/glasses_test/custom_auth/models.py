import uuid as uuid

from django.conf import settings
from django.contrib.auth.base_user import AbstractBaseUser
from django.contrib.auth.models import PermissionsMixin
from django.contrib.auth.validators import UnicodeUsernameValidator
from django.db import models
from phonenumber_field.modelfields import PhoneNumberField
# Create your models here.
from django.utils import timezone

from glasses_test.custom_auth.manager import ApplicationUserManager
from glasses_test.custom_auth.utils import set_password_reset_expiration_time


class ApplicationUser(AbstractBaseUser, PermissionsMixin):
    uuid = models.UUIDField(
        unique=True,
        error_messages={'unique': 'A user with this uuid is already exists'},
        default=uuid.uuid4,
    )
    username_validator = UnicodeUsernameValidator()
    username = models.CharField(max_length=150, unique=True, blank=True, null=True, validators=[username_validator],
                                error_messages={'unique': 'A user with this name is already exists'}, )
    email = models.EmailField(null=True, blank=True, unique=True,
                              error_messages={'unique': 'A user with that email already exists.'}, )
    is_email_verified = models.BooleanField(default=True)
    phone = PhoneNumberField(null=True, blank=True, unique=True)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    last_modified = models.DateTimeField(auto_now=True)
    last_user_activity = models.DateTimeField(default=timezone.now)

    objects = ApplicationUserManager()
    # print("objects:", objects)

    # USERNAME_FIELD = 'username'
    EMAIL_FIELD = 'email'
    USERNAME_FIELD = 'email'

    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'

    def __str__(self):
        return self.username

    def save(self, *args, **kwargs):
        if self.email:
            self.email = self.__class__.objects.normalize_email(self.email)

        if not self.username:
            new_username = self.email.split('@')[0] if self.email else ''

            if self._meta.model._default_manager.filter(username=new_username).exists() or new_username == '':
                postfix = timezone.now().strftime('%Y%m%d%H%M%S')

                while self._meta.model._default_manager(username=new_username + postfix).exists():
                    postfix = timezone.now().strftime('%Y%m%d%H%M%S')

                new_username += postfix

            self.username = new_username

        return super(ApplicationUser, self).save(*args, **kwargs)


class PasswordResetId(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, db_index=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    expiration_time = models.DateTimeField(default=set_password_reset_expiration_time)

    class Meta:
        verbose_name = 'Password reset id'
